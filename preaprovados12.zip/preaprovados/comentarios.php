<?php
header('Content-Type: application/json; charset=utf-8');

$host = 'localhost';
$db   = 'PreAprovados';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$mysqli = new mysqli($host, $user, $pass, $db);
if ($mysqli->connect_errno) {
    http_response_code(500);
    echo json_encode(['erro' => 'Erro de conexão com o banco.']);
    exit;
}
$mysqli->set_charset($charset);

function limparCnpj($cnpj)
{
    return preg_replace('/\D/', '', $cnpj ?? '');
}

function carregarMarcadores(mysqli $db): array
{
    $result = $db->query('SELECT id_marcador, marcador FROM d_marcadores ORDER BY id_marcador');
    if (!$result instanceof mysqli_result) {
        return [];
    }

    $map = [];
    while ($row = $result->fetch_assoc()) {
        $id = (int) $row['id_marcador'];
        $map[$id] = [
            'id_marcador' => $id,
            'marcador' => $row['marcador'],
        ];
    }
    $result->free();

    return $map;
}

function normalizarIdsMarcadores($valor, array $marcadoresDisponiveis): array
{
    if (!is_array($valor)) {
        return [];
    }

    $ids = [];
    foreach ($valor as $item) {
        $id = (int) $item;
        if ($id > 0 && isset($marcadoresDisponiveis[$id])) {
            $ids[$id] = $id;
        }
    }

    return array_values($ids);
}

$marcadoresDisponiveis = carregarMarcadores($mysqli);
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $cnpj = limparCnpj($_GET['cnpj'] ?? '');
    if (strlen($cnpj) !== 14) {
        http_response_code(400);
        echo json_encode(['erro' => 'CNPJ inválido.']);
        exit;
    }

    $sql = "
        SELECT
          id_registro,
          nome,
          juncao,
          MAX(data) AS data,
          GROUP_CONCAT(marcador ORDER BY id SEPARATOR '||') AS marcadores
        FROM f_marcadores
        WHERE cnpj = ?
        GROUP BY id_registro, nome, juncao
        ORDER BY MAX(data) DESC, id_registro DESC
    ";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param('s', $cnpj);
    $stmt->execute();
    $res = $stmt->get_result();

    $comentarios = [];
    while ($row = $res->fetch_assoc()) {
        $comentarios[] = [
            'id' => (string) $row['id_registro'],
            'nome' => $row['nome'],
            'juncao' => $row['juncao'],
            'data' => $row['data'],
            'marcadores' => array_values(array_filter(explode('||', (string) $row['marcadores']))),
        ];
    }

    $stmt->close();
    $mysqli->close();

    echo json_encode(['comentarios' => $comentarios]);
    exit;
}

if ($method === 'POST') {
    $payload = json_decode(file_get_contents('php://input'), true);
    if (!is_array($payload)) {
        $payload = $_POST;
    }

    $cnpj = limparCnpj($payload['cnpj'] ?? '');
    $nome = trim($payload['nome'] ?? '');
    $juncao = trim($payload['juncao'] ?? '');
    $marcadoresSelecionados = normalizarIdsMarcadores($payload['marcadores'] ?? [], $marcadoresDisponiveis);

    if (strlen($cnpj) !== 14 || $nome === '' || empty($marcadoresSelecionados)) {
        http_response_code(400);
        echo json_encode(['erro' => 'CNPJ, nome e ao menos um marcador são obrigatórios.']);
        exit;
    }

    $idRegistro = date('YmdHis') . str_pad((string) mt_rand(0, 9999), 4, '0', STR_PAD_LEFT);

    $mysqli->begin_transaction();

    try {
        $stmt = $mysqli->prepare(
            'INSERT INTO f_marcadores (id_registro, cnpj, id_marcador, nome, juncao, marcador) VALUES (?, ?, ?, ?, ?, ?)'
        );
        if (!$stmt) {
            throw new RuntimeException('Não foi possível preparar a gravação do histórico.');
        }

        foreach ($marcadoresSelecionados as $idMarcador) {
            $marcador = $marcadoresDisponiveis[$idMarcador]['marcador'];
            $stmt->bind_param('ssisss', $idRegistro, $cnpj, $idMarcador, $nome, $juncao, $marcador);
            if (!$stmt->execute()) {
                throw new RuntimeException('Não foi possível salvar o histórico.');
            }
        }

        $stmt->close();
        $mysqli->commit();
        $mysqli->close();

        echo json_encode(['sucesso' => true, 'id' => $idRegistro]);
        exit;
    } catch (Throwable $e) {
        $mysqli->rollback();
        http_response_code(500);
        echo json_encode(['erro' => $e->getMessage()]);
        $mysqli->close();
        exit;
    }
}

if ($method === 'DELETE') {
    parse_str(file_get_contents('php://input'), $payload);
    $idRegistro = trim((string) ($payload['id'] ?? ''));
    $cnpj = limparCnpj($payload['cnpj'] ?? '');

    if ($idRegistro === '' || strlen($cnpj) !== 14) {
        http_response_code(400);
        echo json_encode(['erro' => 'Parâmetros inválidos para excluir.']);
        exit;
    }

    $stmt = $mysqli->prepare('DELETE FROM f_marcadores WHERE id_registro = ? AND cnpj = ?');
    $stmt->bind_param('ss', $idRegistro, $cnpj);
    $stmt->execute();

    if ($stmt->affected_rows === 0) {
        http_response_code(404);
        echo json_encode(['erro' => 'Registro não encontrado.']);
        $stmt->close();
        $mysqli->close();
        exit;
    }

    $stmt->close();
    $mysqli->close();

    echo json_encode(['sucesso' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['erro' => 'Método não suportado.']);
$mysqli->close();
