const campoBusca = document.getElementById("campo-busca");
const listaAutocomplete = document.getElementById("autocomplete-list");
const listaResultados = document.getElementById("lista-resultados");
const resultCount = document.getElementById("result-count");
const filtroEstado = document.getElementById("filtro-estado");
const filtroCidade = document.getElementById("filtro-cidade");
const filtroBairro = document.getElementById("filtro-bairro");
const filtroProduto = document.getElementById("filtro-produto");
const legendContainer = document.getElementById("legend-produtos");
const btnLimparFiltros = document.getElementById("btn-limpar-filtros");
const btnAplicarFiltros = document.getElementById("btn-aplicar-filtros");
const btnPaginaAnterior = document.getElementById("btn-pagina-anterior");
const btnPaginaProxima = document.getElementById("btn-pagina-proxima");
const paginationInfo = document.getElementById("pagination-info");
const loadingOverlay = document.getElementById("loading-overlay");
const inlineSpinner = document.getElementById("inline-spinner");
const filtrosColapsaveis = document.getElementById("filtros-colapsaveis");
const btnToggleFiltros = document.getElementById("btn-toggle-filtros");

let empresasCache = [];
let chartProdutos = null;
let autocompleteAbortController = null;
let buscaEmpresasAbortController = null;
let resumoEmpresasAbortController = null;
let autocompleteRequestSeq = 0;
let inlineSpinnerTimer = null;
let paginaAtual = 1;
let totalPaginas = null;
let totalResultados = null;
let temProximaPagina = false;
let modoListaInicial = false;
const porPagina = 10;
const STORAGE_KEY = "preaprovados-filtros";
let loadingCount = 0;
let contextoFiltrosAtual = "";

const PRODUCT_COLORS = [
  "#cc092f",
  "#1b2563",
  "#10b981",
  "#fbbf24",
  "#6366f1",
  "#ec4899",
  "#14b8a6",
  "#f97316",
  "#4b5563"
];

const productColorMap = new Map();

function formatarMoeda(valor) {
  return valor.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
    maximumFractionDigits: 2
  });
}

function startLoading() {
  loadingCount += 1;
  if (loadingOverlay) {
    loadingOverlay.classList.add("is-visible");
  }
}

function stopLoading() {
  loadingCount = Math.max(0, loadingCount - 1);
  if (loadingCount === 0 && loadingOverlay) {
    loadingOverlay.classList.remove("is-visible");
  }
}

function salvarFiltrosEstado(estado) {
  try {
    const payload = {
      estado: estado?.estado || "",
      cidade: estado?.cidade || "",
      bairro: estado?.bairro || "",
      produto: estado?.produto || "",
      pagina: Number(estado?.pagina || 1),
      filtrosFechados: Boolean(estado?.filtrosFechados)
    };

    if (!temFiltrosAtivos(payload) && !payload.filtrosFechados) {
      sessionStorage.removeItem(STORAGE_KEY);
      return;
    }

    if (!temFiltrosAtivos(payload)) {
      payload.pagina = 1;
    }

    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  } catch (err) {
    console.warn("Nao foi possivel salvar filtros", err);
  }
}

function recuperarFiltrosEstado() {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch (err) {
    console.warn("Nao foi possivel carregar filtros", err);
    return {};
  }
}

function mostrarInlineSpinner(mostrar) {
  if (!inlineSpinner) return;
  if (inlineSpinnerTimer) {
    clearTimeout(inlineSpinnerTimer);
    inlineSpinnerTimer = null;
  }

  if (mostrar) {
    inlineSpinnerTimer = window.setTimeout(() => {
      inlineSpinner.classList.add("is-visible");
      inlineSpinner.setAttribute("aria-hidden", "false");
    }, 120);
    return;
  }

  inlineSpinner.classList.remove("is-visible");
  inlineSpinner.setAttribute("aria-hidden", "true");
}

function getProductColor(nome) {
  if (!nome) return PRODUCT_COLORS[0];
  if (productColorMap.has(nome)) {
    return productColorMap.get(nome);
  }

  const color = PRODUCT_COLORS[productColorMap.size % PRODUCT_COLORS.length];
  productColorMap.set(nome, color);
  return color;
}

function getContrastTextColor(backgroundColor) {
  if (typeof backgroundColor !== "string") {
    return "#0f172a";
  }

  let color = backgroundColor.trim().replace("#", "");
  if (color.length === 3) {
    color = color
      .split("")
      .map((char) => char + char)
      .join("");
  }

  if (!/^[0-9a-fA-F]{6}$/.test(color)) {
    return "#0f172a";
  }

  const r = parseInt(color.slice(0, 2), 16);
  const g = parseInt(color.slice(2, 4), 16);
  const b = parseInt(color.slice(4, 6), 16);
  const luminancia = (0.299 * r + 0.587 * g + 0.114 * b) / 255;

  return luminancia < 0.58 ? "#ffffff" : "#0f172a";
}

function obterFiltrosAtuais() {
  return {
    estado: filtroEstado ? filtroEstado.value : "",
    cidade: filtroCidade ? filtroCidade.value : "",
    bairro: filtroBairro ? filtroBairro.value : "",
    produto: filtroProduto ? filtroProduto.value : ""
  };
}

function temFiltrosAtivos(filtros = {}) {
  return Boolean(
    (filtros.estado || "").trim() ||
      (filtros.cidade || "").trim() ||
      (filtros.bairro || "").trim() ||
      String(filtros.produto || "").trim()
  );
}

function gerarContextoFiltros(filtros) {
  return JSON.stringify(filtros || {});
}

function montarParamsBusca(pagina = 1, extras = {}) {
  const filtros = obterFiltrosAtuais();
  const params = new URLSearchParams();

  if (filtros.estado) params.append("estado", filtros.estado);
  if (filtros.cidade) params.append("cidade", filtros.cidade);
  if (filtros.bairro) params.append("bairro", filtros.bairro);
  if (filtros.produto) params.append("produto", filtros.produto);

  params.append("pagina", pagina.toString());
  params.append("por_pagina", porPagina.toString());

  if (extras.incluirResumo === false) {
    params.append("incluir_resumo", "0");
  }

  if (extras.somenteResumo) {
    params.append("somente_resumo", "1");
  }

  if (extras.inicial) {
    params.append("inicial", "1");
  }

  return { filtros, params };
}

function limparResumoPendente() {
  totalResultados = null;
  totalPaginas = null;
  temProximaPagina = false;
}

async function requisitarEmpresas(pagina = 1, options = {}) {
  const {
    incluirResumo = true,
    somenteResumo = false,
    inicial = false,
    mostrarOverlay = true,
    tipo = "lista"
  } = options;
  const { filtros, params } = montarParamsBusca(pagina, {
    incluirResumo,
    somenteResumo,
    inicial
  });
  const url =
    "buscar_empresas.php" + (params.toString() ? `?${params.toString()}` : "");

  if (tipo === "resumo") {
    if (resumoEmpresasAbortController) {
      resumoEmpresasAbortController.abort();
    }
    resumoEmpresasAbortController = new AbortController();
  } else {
    if (buscaEmpresasAbortController) {
      buscaEmpresasAbortController.abort();
    }
    buscaEmpresasAbortController = new AbortController();
  }

  const controller =
    tipo === "resumo"
      ? resumoEmpresasAbortController
      : buscaEmpresasAbortController;

  if (mostrarOverlay) {
    startLoading();
  }

  try {
    const resp = await fetch(url, { signal: controller.signal });
    const raw = await resp.text();
    let data = {};

    try {
      data = raw ? JSON.parse(raw) : {};
    } catch (parseErr) {
      console.error("Resposta de buscar_empresas.php nao e JSON valido:", raw);
      alert("A busca retornou um erro no servidor.");
      return null;
    }

    if (!resp.ok) {
      console.error(data);
      alert("Erro ao buscar empresas.");
      return null;
    }

    return { data, filtros };
  } catch (err) {
    if (err.name === "AbortError") {
      return null;
    }

    console.error(err);
    alert("Falha na comunicacao com o servidor.");
    return null;
  } finally {
    if (mostrarOverlay) {
      stopLoading();
    }
  }
}

async function carregarResumoEmpresas(contexto) {
  const response = await requisitarEmpresas(paginaAtual, {
    somenteResumo: true,
    mostrarOverlay: false,
    tipo: "resumo"
  });

  if (!response) {
    return;
  }

  const { data, filtros } = response;
  if (contexto !== contextoFiltrosAtual) {
    return;
  }

  if (gerarContextoFiltros(filtros) !== contexto) {
    return;
  }

  totalPaginas =
    typeof data.total_paginas === "number" ? data.total_paginas : totalPaginas;
  totalResultados =
    typeof data.total === "number" ? data.total : totalResultados;

  if (typeof totalPaginas === "number") {
    temProximaPagina = paginaAtual < totalPaginas;
  }

  atualizarResultados(empresasCache, {
    total: totalResultados,
    pagina: paginaAtual,
    totalPaginas
  });
  atualizarGrafico(
    Array.isArray(data.totais_produtos) && data.totais_produtos.length
      ? data.totais_produtos
      : empresasCache
  );
  atualizarPaginacao();
}

async function buscarEmpresasApi(pagina = 1, options = {}) {
  const {
    mostrarOverlay = true,
    recarregarResumo = false,
    inicial = false
  } = options;
  const filtrosAtuais = obterFiltrosAtuais();
  const possuiFiltrosAtivos = temFiltrosAtivos(filtrosAtuais);
  const usarCargaInicial = inicial || !possuiFiltrosAtivos;
  const contexto = gerarContextoFiltros(filtrosAtuais);

  if (recarregarResumo) {
    contextoFiltrosAtual = contexto;
    if (resumoEmpresasAbortController) {
      resumoEmpresasAbortController.abort();
    }
    limparResumoPendente();
  }

  const paginaSolicitada = usarCargaInicial ? 1 : pagina;
  const response = await requisitarEmpresas(paginaSolicitada, {
    incluirResumo: false,
    inicial: usarCargaInicial,
    mostrarOverlay,
    tipo: "lista"
  });

  if (!response) {
    return;
  }

  const { data, filtros } = response;
  const contextoResposta = gerarContextoFiltros(filtros);

  if (recarregarResumo) {
    contextoFiltrosAtual = contextoResposta;
  }

  empresasCache = data.empresas || [];
  paginaAtual = usarCargaInicial ? 1 : data.pagina || 1;
  temProximaPagina = usarCargaInicial ? false : Boolean(data.tem_proxima_pagina);
  modoListaInicial = usarCargaInicial;

  salvarFiltrosEstado({
    ...filtros,
    pagina: paginaAtual,
    filtrosFechados: filtrosColapsaveis?.classList.contains("is-collapsed")
  });

  atualizarResultados(empresasCache, {
    total: totalResultados,
    pagina: paginaAtual,
    totalPaginas
  });
  atualizarGrafico(
    data.resumo_incluido && Array.isArray(data.totais_produtos)
      ? data.totais_produtos
      : empresasCache
  );
  atualizarPaginacao();

  if (recarregarResumo && possuiFiltrosAtivos) {
    carregarResumoEmpresas(contextoResposta);
  }
}

function atualizarResultados(lista, meta = {}) {
  if (!listaResultados || !resultCount) return;

  listaResultados.innerHTML = "";

  const listaExibir = Array.isArray(lista) ? lista.slice(0, porPagina) : [];
  const total = meta.total;
  const pagina = meta.pagina ?? 1;
  const totalMeta = meta.totalPaginas;

  if (!listaExibir.length) {
    resultCount.textContent =
      typeof total === "number" ? `0 de ${total} resultados` : "0 resultados";
    return;
  }

  if (typeof total === "number") {
    resultCount.textContent = `${listaExibir.length} de ${total} resultado${
      total !== 1 ? "s" : ""
    } | Pagina ${pagina} de ${totalMeta || 1}`;
  } else if (modoListaInicial) {
    resultCount.textContent = `${listaExibir.length} resultado${
      listaExibir.length !== 1 ? "s" : ""
    } exibido${listaExibir.length !== 1 ? "s" : ""} | Lista inicial`;
  } else {
    resultCount.textContent = `${listaExibir.length} resultado${
      listaExibir.length !== 1 ? "s" : ""
    } exibido${listaExibir.length !== 1 ? "s" : ""} | Pagina ${pagina} | Total calculando...`;
  }

  listaExibir.forEach((empresa) => {
    const card = document.createElement("a");
    card.className = "result-card";
    card.href = `detalhes.php?cnpj=${encodeURIComponent(empresa.cnpj)}`;

    const chipsHtml = (empresa.produtos || [])
      .map((produto) => {
        const color = getProductColor(produto.nome);
        return `
        <span class="chip" style="--chip-color:${color}">
          <span class="chip-dot"></span>
          ${produto.nome}
          <span class="chip-value">${formatarMoeda(produto.valor)}</span>
        </span>`;
      })
      .join("");

    card.innerHTML = `
      <div class="result-top-row">
        <div>
          <div class="result-name">${empresa.razao_social}</div>
          <div class="result-cnpj">CNPJ: ${empresa.cnpj}</div>
        </div>
        <div class="result-location">
          ${empresa.cidade || ""} - ${empresa.estado || ""}<br/>
          ${empresa.bairro || ""}
        </div>
      </div>
      <div class="product-chips">
        ${chipsHtml}
      </div>
    `;

    listaResultados.appendChild(card);
  });
}

function preencherAutocomplete(lista) {
  if (!listaAutocomplete || !campoBusca) return;

  listaAutocomplete.innerHTML = "";

  if (!campoBusca.value.trim() || !lista.length) {
    listaAutocomplete.style.display = "none";
    return;
  }

  listaAutocomplete.style.display = "block";

  lista.forEach((empresa) => {
    const item = document.createElement("div");
    item.className = "autocomplete-item";
    item.innerHTML = `
      <span>${empresa.razao_social}</span>
      <span>${empresa.cnpj} | ${empresa.cidade || ""} - ${empresa.estado || ""}</span>
    `;
    item.addEventListener("click", () => {
      window.location.href = `detalhes.php?cnpj=${encodeURIComponent(
        empresa.cnpj
      )}`;
    });
    listaAutocomplete.appendChild(item);
  });
}

async function buscarSugestoes(query) {
  const q = query.trim();
  const requestSeq = ++autocompleteRequestSeq;

  if (!q || q.length < 2) {
    if (autocompleteAbortController) {
      autocompleteAbortController.abort();
      autocompleteAbortController = null;
    }
    if (listaAutocomplete) {
      listaAutocomplete.style.display = "none";
    }
    mostrarInlineSpinner(false);
    return;
  }

  if (autocompleteAbortController) {
    autocompleteAbortController.abort();
  }
  autocompleteAbortController = new AbortController();

  mostrarInlineSpinner(true);

  try {
    const resp = await fetch(
      "autocomplete.php?q=" + encodeURIComponent(q),
      { signal: autocompleteAbortController.signal }
    );
    const data = await resp.json();

    if (requestSeq !== autocompleteRequestSeq) {
      return;
    }

    if (!resp.ok) {
      console.error(data);
      return;
    }

    preencherAutocomplete(data.empresas || []);
  } catch (err) {
    if (err.name === "AbortError") {
      return;
    }
    console.error("Erro no autocomplete", err);
  } finally {
    if (requestSeq === autocompleteRequestSeq) {
      mostrarInlineSpinner(false);
    }
  }
}

if (campoBusca) {
  campoBusca.addEventListener("input", (event) => {
    buscarSugestoes(event.target.value);
  });
}

document.addEventListener("click", (event) => {
  if (listaAutocomplete && !event.target.closest(".search-input-wrapper")) {
    listaAutocomplete.style.display = "none";
  }
});

function calcularQuantidadePorProduto(lista) {
  const contagem = {};

  (lista || []).forEach((empresa) => {
    (empresa.produtos || []).forEach((produto) => {
      if (produto.valor > 0) {
        contagem[produto.nome] = (contagem[produto.nome] || 0) + 1;
      }
    });
  });

  return contagem;
}

function normalizarTotaisProdutos(fonte) {
  if (
    Array.isArray(fonte) &&
    fonte.length > 0 &&
    typeof fonte[0] === "object" &&
    Object.prototype.hasOwnProperty.call(fonte[0], "quantidade")
  ) {
    return fonte
      .map((item) => ({
        nome: item?.nome || "",
        quantidade: Number(item?.quantidade || 0)
      }))
      .filter((item) => item.nome && item.quantidade > 0);
  }

  const contagem = calcularQuantidadePorProduto(fonte);
  return Object.keys(contagem)
    .sort()
    .map((nome) => ({
      nome,
      quantidade: contagem[nome]
    }));
}

const donutDataLabels = {
  id: "donutDataLabels",
  afterDatasetDraw(chart) {
    const {
      ctx,
      data: { datasets }
    } = chart;
    const meta = chart.getDatasetMeta(0);
    if (!meta || !datasets[0]) return;

    const backgroundColors = datasets[0].backgroundColor || [];

    ctx.save();
    ctx.font = "600 12px 'Inter', 'Segoe UI', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    meta.data.forEach((arc, idx) => {
      const value = Number(datasets[0].data[idx]);
      if (!value) return;

      const props = arc.getProps(
        ["x", "y", "startAngle", "endAngle", "innerRadius", "outerRadius"],
        true
      );
      const angle = (props.startAngle + props.endAngle) / 2;
      const radius =
        props.innerRadius + (props.outerRadius - props.innerRadius) * 0.55;
      const x = props.x + Math.cos(angle) * radius;
      const y = props.y + Math.sin(angle) * radius;
      const backgroundColor = Array.isArray(backgroundColors)
        ? backgroundColors[idx]
        : backgroundColors;
      const textColor = getContrastTextColor(backgroundColor);

      ctx.fillStyle = textColor;
      ctx.lineWidth = 3;
      ctx.strokeStyle =
        textColor === "#ffffff"
          ? "rgba(15, 23, 42, 0.35)"
          : "rgba(255, 255, 255, 0.85)";
      ctx.strokeText(String(value), x, y);
      ctx.fillText(value, x, y);
    });

    ctx.restore();
  }
};

function atualizarGrafico(fonte) {
  const canvas = document.getElementById("chart-produtos");
  if (!canvas || typeof Chart === "undefined") return;

  if (legendContainer) {
    legendContainer.innerHTML = "";
  }

  const totaisProdutos = normalizarTotaisProdutos(fonte);
  const labels = totaisProdutos.map((item) => item.nome);
  const valores = totaisProdutos.map((item) => item.quantidade);

  labels.forEach((label) => getProductColor(label));

  if (!labels.length) {
    if (chartProdutos) {
      chartProdutos.destroy();
      chartProdutos = null;
    }
    return;
  }

  if (chartProdutos) {
    chartProdutos.destroy();
  }

  chartProdutos = new Chart(canvas, {
    type: "doughnut",
    data: {
      labels,
      datasets: [
        {
          data: valores,
          backgroundColor: labels.map((label) => getProductColor(label)),
          borderWidth: 1,
          borderColor: "#ffffff"
        }
      ]
    },
    options: {
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx) => `${ctx.label}: ${ctx.raw}`
          }
        }
      },
      cutout: "72%"
    },
    plugins: [donutDataLabels]
  });

  if (legendContainer) {
    labels.forEach((label) => {
      const item = document.createElement("div");
      item.className = "chart-legend-item";
      item.innerHTML = `
        <span class="chart-legend-dot" style="background-color:${getProductColor(
          label
        )}"></span>
        <span class="chart-legend-label">${label}</span>
      `;
      legendContainer.appendChild(item);
    });
  }
}

async function carregarEstados() {
  if (!filtroEstado) return;

  try {
    const resp = await fetch("filtros.php?tipo=estados");
    const data = await resp.json();

    filtroEstado.innerHTML = '<option value="">Todos</option>';

    (data.estados || []).forEach((uf) => {
      const opt = document.createElement("option");
      opt.value = uf;
      opt.textContent = uf;
      filtroEstado.appendChild(opt);
    });
  } catch (err) {
    console.error("Erro ao carregar estados", err);
  }
}

async function carregarCidades(estado) {
  if (!filtroCidade || !filtroBairro) return;

  filtroCidade.innerHTML = '<option value="">Todas</option>';
  filtroBairro.innerHTML = '<option value="">Todos</option>';

  if (!estado) return;

  try {
    const resp = await fetch(
      "filtros.php?tipo=cidades&estado=" + encodeURIComponent(estado)
    );
    const data = await resp.json();

    (data.cidades || []).forEach((cidade) => {
      const opt = document.createElement("option");
      opt.value = cidade;
      opt.textContent = cidade;
      filtroCidade.appendChild(opt);
    });
  } catch (err) {
    console.error("Erro ao carregar cidades", err);
  }
}

async function carregarBairros(estado, cidade) {
  if (!filtroBairro) return;

  filtroBairro.innerHTML = '<option value="">Todos</option>';
  if (!estado || !cidade) return;

  try {
    const resp = await fetch(
      "filtros.php?tipo=bairros&estado=" +
        encodeURIComponent(estado) +
        "&cidade=" +
        encodeURIComponent(cidade)
    );
    const data = await resp.json();

    (data.bairros || []).forEach((bairro) => {
      const opt = document.createElement("option");
      opt.value = bairro;
      opt.textContent = bairro;
      filtroBairro.appendChild(opt);
    });
  } catch (err) {
    console.error("Erro ao carregar bairros", err);
  }
}

async function carregarProdutos() {
  if (!filtroProduto) return;

  try {
    const resp = await fetch("filtros.php?tipo=produtos");
    const data = await resp.json();

    filtroProduto.innerHTML = '<option value="">Todos</option>';

    (data.produtos || []).forEach((item) => {
      const opt = document.createElement("option");
      opt.value = item.id;
      opt.textContent = item.nome;
      filtroProduto.appendChild(opt);
    });
  } catch (err) {
    console.error("Erro ao carregar produtos", err);
  }
}

function atualizarToggleEstado(isCollapsed) {
  if (!filtrosColapsaveis || !btnToggleFiltros) return;

  filtrosColapsaveis.classList.toggle("is-collapsed", isCollapsed);
  btnToggleFiltros.classList.toggle("is-collapsed", isCollapsed);

  const icon = btnToggleFiltros.querySelector(".toggle-icon");
  if (icon) {
    icon.textContent = isCollapsed ? ">" : "v";
  }
}

function atualizarPaginacao() {
  if (modoListaInicial) {
    if (paginationInfo) {
      paginationInfo.textContent = "Lista inicial";
    }

    if (btnPaginaAnterior) {
      btnPaginaAnterior.disabled = true;
    }

    if (btnPaginaProxima) {
      btnPaginaProxima.disabled = true;
    }
    return;
  }

  if (paginationInfo) {
    paginationInfo.textContent =
      typeof totalPaginas === "number"
        ? `Pagina ${paginaAtual} de ${totalPaginas}`
        : `Pagina ${paginaAtual}`;
  }

  if (btnPaginaAnterior) {
    btnPaginaAnterior.disabled = paginaAtual <= 1;
  }

  if (btnPaginaProxima) {
    btnPaginaProxima.disabled =
      typeof totalPaginas === "number"
        ? paginaAtual >= totalPaginas
        : !temProximaPagina;
  }
}

async function restaurarFiltros() {
  const salvo = recuperarFiltrosEstado();
  if (!salvo || typeof salvo !== "object") return;

  if (filtroEstado && salvo.estado) {
    filtroEstado.value = salvo.estado;
    await carregarCidades(salvo.estado);
  }

  if (filtroCidade && salvo.cidade) {
    filtroCidade.value = salvo.cidade;
    await carregarBairros(salvo.estado, salvo.cidade);
  }

  if (filtroBairro && salvo.bairro) {
    filtroBairro.value = salvo.bairro;
  }

  if (filtroProduto && salvo.produto) {
    filtroProduto.value = salvo.produto;
  }

  if (typeof salvo.filtrosFechados !== "undefined") {
    atualizarToggleEstado(Boolean(salvo.filtrosFechados));
  }

  if (salvo.pagina && temFiltrosAtivos(salvo)) {
    paginaAtual = salvo.pagina;
  }
}

if (filtroEstado) {
  filtroEstado.addEventListener("change", () => {
    carregarCidades(filtroEstado.value);
  });
}

if (filtroCidade) {
  filtroCidade.addEventListener("change", () => {
    const estado = filtroEstado ? filtroEstado.value : "";
    carregarBairros(estado, filtroCidade.value);
  });
}

if (btnToggleFiltros && filtrosColapsaveis) {
  btnToggleFiltros.addEventListener("click", () => {
    const isCollapsed = !filtrosColapsaveis.classList.contains("is-collapsed");
    atualizarToggleEstado(isCollapsed);

    salvarFiltrosEstado({
      ...obterFiltrosAtuais(),
      pagina: paginaAtual,
      filtrosFechados: isCollapsed
    });
  });
}

if (btnLimparFiltros) {
  btnLimparFiltros.addEventListener("click", () => {
    if (filtroEstado) filtroEstado.value = "";
    if (filtroCidade) filtroCidade.innerHTML = '<option value="">Todas</option>';
    if (filtroBairro) filtroBairro.innerHTML = '<option value="">Todos</option>';
    if (filtroProduto) filtroProduto.value = "";
    if (campoBusca) campoBusca.value = "";
    if (listaAutocomplete) {
      listaAutocomplete.innerHTML = "";
      listaAutocomplete.style.display = "none";
    }

    sessionStorage.removeItem(STORAGE_KEY);
    paginaAtual = 1;
    buscarEmpresasApi(paginaAtual, { recarregarResumo: true });
  });
}

if (btnAplicarFiltros) {
  btnAplicarFiltros.addEventListener("click", () => {
    paginaAtual = 1;
    buscarEmpresasApi(paginaAtual, { recarregarResumo: true });
  });
}

if (btnPaginaAnterior) {
  btnPaginaAnterior.addEventListener("click", () => {
    if (paginaAtual > 1) {
      buscarEmpresasApi(paginaAtual - 1);
    }
  });
}

if (btnPaginaProxima) {
  btnPaginaProxima.addEventListener("click", () => {
    if (
      (typeof totalPaginas === "number" && paginaAtual < totalPaginas) ||
      (typeof totalPaginas !== "number" && temProximaPagina)
    ) {
      buscarEmpresasApi(paginaAtual + 1);
    }
  });
}

window.addEventListener("DOMContentLoaded", async () => {
  if (resultCount) {
    resultCount.textContent = "Carregando resultados...";
  }

  if (paginationInfo) {
    paginationInfo.textContent = "Carregando...";
  }

  const filtrosSalvos = recuperarFiltrosEstado();
  const possuiFiltrosSalvos = temFiltrosAtivos(filtrosSalvos);
  const filtrosBasicosPromise = Promise.all([carregarEstados(), carregarProdutos()]);

  await filtrosBasicosPromise.catch((err) => {
    console.error("Erro ao carregar filtros iniciais", err);
  });
  await restaurarFiltros();

  if (possuiFiltrosSalvos) {
    await buscarEmpresasApi(paginaAtual, {
      mostrarOverlay: false,
      recarregarResumo: true
    });
    return;
  }

  await buscarEmpresasApi(1, {
    mostrarOverlay: false,
    recarregarResumo: false,
    inicial: true
  });
});
