﻿# Backend MVP - Gestao de Visitas e Interacoes

Stack: PHP (mysqli) + MySQL/MariaDB (XAMPP)

## 1) Banco de dados

Execute nesta ordem:

1. `novo_app/sql/01_schema_dashboard_visitas.sql`
2. `novo_app/sql/02_seed_dashboard_visitas.sql`

Banco criado: `dashboard_visitas`

Usuarios iniciais:
- Ademar (`slug`: `ademar`)
- Aline (`slug`: `aline`)

## 2) Configuracao

Arquivo: `novo_app/backend/config/database.php`

Padrao:
- host: `localhost`
- porta: `3306`
- database: `dashboard_visitas`
- user: `root`
- password: `` (vazia)

## 3) Endpoints (backend/api)

- `dimensoes.php`
  - `GET ?tipo=all` (ou `usuarios`, `agencias`, `temas_visita`, `tipos_interacao`, `areas_responsaveis`, `status_demanda`, `tipos_compromisso`)
  - `POST` cria registro de dimensao
  - `PUT` atualiza registro de dimensao
  - `DELETE` faz exclusao logica (`ativo = 0`)

- `visitas.php`
  - `GET` lista visitas com filtros
  - `GET ?id=...` detalhe da visita
  - `POST` cria visita
  - `PUT` atualiza visita
  - `DELETE` remove visita

- `interacoes.php`
  - `GET` lista interacoes com filtros
  - `GET ?id=...` detalhe da interacao
  - `POST` cria interacao
  - `PUT` atualiza interacao
  - `DELETE` remove interacao

- `compromissos.php`
  - `GET` lista compromissos
  - `GET ?id=...` detalhe de compromisso
  - `POST` cria compromisso
  - `PUT` atualiza compromisso
  - `DELETE` remove compromisso

- `dashboard.php`
  - `GET` retorna KPIs e datasets do dashboard
  - filtros: `usuario_id`, `data_inicio`, `data_fim`, `days`

## 4) Exemplos rapidos

### Listar dashboard (ultimos 30 dias)
`GET /novo_app/backend/api/dashboard.php`

### Dashboard filtrado por usuario (Ademar = 1)
`GET /novo_app/backend/api/dashboard.php?usuario_id=1&days=60`

### Criar visita
`POST /novo_app/backend/api/visitas.php`

```json
{
  "usuario_id": 1,
  "agencia_id": 1,
  "tema_visita_id": 1,
  "descricao": "Visita para alinhamento comercial",
  "demandas": "Atualizar carteira",
  "status_demanda_id": 1,
  "data_contato": "2026-02-27 10:00:00",
  "participantes": [
    { "nome": "Joao", "subsecao": "Gerente Agencia" }
  ]
}
```

### Criar interacao
`POST /novo_app/backend/api/interacoes.php`

```json
{
  "usuario_id": 2,
  "tipo_interacao_id": 1,
  "agencia_id": 2,
  "assunto": "Produtividade",
  "descricao": "Rito semanal por Teams",
  "status_demanda_id": 1,
  "data_contato": "2026-02-27 11:00:00"
}
```

### Criar compromisso
`POST /novo_app/backend/api/compromissos.php`

```json
{
  "usuario_id": 1,
  "tipo_compromisso_id": 1,
  "titulo": "Reuniao regional",
  "descricao": "Planejamento semanal",
  "data_inicio": "2026-02-28 09:00:00",
  "data_fim": "2026-02-28 10:00:00"
}
```

## 5) Atualizacao imediata do dashboard

Ao gravar novas visitas/interacoes/compromissos, os dados ficam no banco imediatamente.
O frontend deve chamar `dashboard.php` apos salvar para refletir os novos numeros em tempo real.
