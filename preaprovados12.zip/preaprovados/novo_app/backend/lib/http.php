﻿<?php

function init_api(): void
{
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

function json_response(array $payload, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function json_error(string $message, int $statusCode = 400, array $extra = []): void
{
    json_response(array_merge(['erro' => $message], $extra), $statusCode);
}

function json_input(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        json_error('JSON invalido no corpo da requisicao.', 400);
    }

    return $decoded;
}

function to_int_or_null($value): ?int
{
    if ($value === null || $value === '' || $value === false) {
        return null;
    }

    if (!is_numeric($value)) {
        return null;
    }

    return (int) $value;
}

function to_string_or_null($value): ?string
{
    if ($value === null) {
        return null;
    }

    $text = trim((string) $value);
    return $text === '' ? null : $text;
}

function parse_datetime_or_null($value): ?string
{
    $text = to_string_or_null($value);
    if ($text === null) {
        return null;
    }

    $timestamp = strtotime($text);
    if ($timestamp === false) {
        json_error('Data/hora invalida: ' . $text, 422);
    }

    return date('Y-m-d H:i:s', $timestamp);
}

function require_fields(array $payload, array $required): void
{
    foreach ($required as $field) {
        if (!array_key_exists($field, $payload)) {
            json_error('Campo obrigatorio ausente: ' . $field, 422);
        }

        if (is_string($payload[$field]) && trim($payload[$field]) === '') {
            json_error('Campo obrigatorio vazio: ' . $field, 422);
        }

        if ($payload[$field] === null) {
            json_error('Campo obrigatorio nulo: ' . $field, 422);
        }
    }
}
