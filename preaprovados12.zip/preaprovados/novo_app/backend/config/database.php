﻿<?php

return [
    'host' => 'localhost',
    'port' => 3306,
    'database' => 'dashboard_visitas',
    'user' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
];
