﻿<?php

require_once __DIR__ . '/../lib/http.php';
require_once __DIR__ . '/../lib/db.php';

init_api();

try {
    $db = db_connect();

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
        json_error('Metodo nao permitido.', 405);
    }

    $periodo = resolve_periodo($_GET);
    $usuarioId = to_int_or_null($_GET['usuario_id'] ?? null);

    $visitasFiltro = build_fact_filter('v', 'DATE(COALESCE(v.data_contato, v.criado_em))', $periodo, $usuarioId);
    $interacoesFiltro = build_fact_filter('i', 'DATE(COALESCE(i.data_contato, i.criado_em))', $periodo, $usuarioId);

    $kpis = fetch_kpis($db, $visitasFiltro, $interacoesFiltro, $periodo, $usuarioId);
    $visitasTimeline = fetch_timeline_visitas($db, $visitasFiltro);
    $interacoesTimeline = fetch_timeline_interacoes($db, $interacoesFiltro);
    $interacoesPorTipo = fetch_interacoes_por_tipo($db, $interacoesFiltro);
    $demandasPorStatus = fetch_demandas_por_status($db, $visitasFiltro, $interacoesFiltro);
    $topAgencias = fetch_top_agencias($db, $visitasFiltro, $interacoesFiltro);
    $compromissosPeriodo = fetch_compromissos_periodo($db, $periodo, $usuarioId);
    $compromissosHoje = fetch_compromissos_hoje($db, $usuarioId);

    json_response([
        'periodo' => $periodo,
        'usuario_id' => $usuarioId,
        'kpis' => $kpis,
        'visitas_timeline' => $visitasTimeline,
        'interacoes_timeline' => $interacoesTimeline,
        'interacoes_por_tipo' => $interacoesPorTipo,
        'demandas_por_status' => $demandasPorStatus,
        'top_agencias' => $topAgencias,
        'compromissos_periodo' => $compromissosPeriodo,
        'compromissos_hoje' => $compromissosHoje,
    ]);
} catch (Throwable $e) {
    json_error('Erro interno no servidor.', 500, ['detalhe' => $e->getMessage()]);
}

function resolve_periodo(array $source): array
{
    $days = to_int_or_null($source['days'] ?? 30) ?? 30;
    $days = max(1, min(365, $days));

    $fimInput = to_string_or_null($source['data_fim'] ?? null);
    $inicioInput = to_string_or_null($source['data_inicio'] ?? null);

    $fimTs = $fimInput ? strtotime($fimInput) : strtotime('today');
    if ($fimTs === false) {
        json_error('data_fim invalida.', 422);
    }

    if ($inicioInput) {
        $inicioTs = strtotime($inicioInput);
        if ($inicioTs === false) {
            json_error('data_inicio invalida.', 422);
        }
    } else {
        $inicioTs = strtotime('-' . ($days - 1) . ' days', $fimTs);
    }

    if ($inicioTs > $fimTs) {
        json_error('data_inicio nao pode ser maior que data_fim.', 422);
    }

    return [
        'data_inicio' => date('Y-m-d', $inicioTs),
        'data_fim' => date('Y-m-d', $fimTs),
    ];
}

function build_fact_filter(string $alias, string $dateExpr, array $periodo, ?int $usuarioId): array
{
    $clauses = [];
    $types = '';
    $params = [];

    $clauses[] = $dateExpr . ' BETWEEN ? AND ?';
    $types .= 'ss';
    $params[] = $periodo['data_inicio'];
    $params[] = $periodo['data_fim'];

    if ($usuarioId !== null && $usuarioId > 0) {
        $clauses[] = $alias . '.usuario_id = ?';
        $types .= 'i';
        $params[] = $usuarioId;
    }

    return [
        'where_sql' => implode(' AND ', $clauses),
        'types' => $types,
        'params' => $params,
    ];
}

function fetch_kpis(mysqli $db, array $visitasFiltro, array $interacoesFiltro, array $periodo, ?int $usuarioId): array
{
    $visitasRow = db_query_one(
        $db,
        'SELECT COUNT(*) AS total FROM f_visitas v WHERE ' . $visitasFiltro['where_sql'],
        $visitasFiltro['types'],
        $visitasFiltro['params']
    );

    $interacoesRow = db_query_one(
        $db,
        'SELECT COUNT(*) AS total FROM f_interacoes i WHERE ' . $interacoesFiltro['where_sql'],
        $interacoesFiltro['types'],
        $interacoesFiltro['params']
    );

    $compWhere = ['DATE(c.data_inicio) BETWEEN ? AND ?'];
    $compTypes = 'ss';
    $compParams = [$periodo['data_inicio'], $periodo['data_fim']];
    if ($usuarioId !== null && $usuarioId > 0) {
        $compWhere[] = 'c.usuario_id = ?';
        $compTypes .= 'i';
        $compParams[] = $usuarioId;
    }

    $compRow = db_query_one(
        $db,
        'SELECT COUNT(*) AS total FROM f_compromissos c WHERE ' . implode(' AND ', $compWhere),
        $compTypes,
        $compParams
    );

    $demandasAbertasRow = db_query_one(
        $db,
        '
        SELECT SUM(qtd) AS total_abertas
        FROM (
            SELECT COUNT(*) AS qtd
            FROM f_visitas v
            JOIN d_status_demanda sd ON sd.id = v.status_demanda_id
            WHERE ' . $visitasFiltro['where_sql'] . ' AND sd.nome IN ("Em Andamento", "Nao Iniciado")

            UNION ALL

            SELECT COUNT(*) AS qtd
            FROM f_interacoes i
            JOIN d_status_demanda sd ON sd.id = i.status_demanda_id
            WHERE ' . $interacoesFiltro['where_sql'] . ' AND sd.nome IN ("Em Andamento", "Nao Iniciado")
        ) t
    ',
        $visitasFiltro['types'] . $interacoesFiltro['types'],
        array_merge($visitasFiltro['params'], $interacoesFiltro['params'])
    );

    $totalVisitas = (int) ($visitasRow['total'] ?? 0);
    $totalInteracoes = (int) ($interacoesRow['total'] ?? 0);
    $totalCompromissos = (int) ($compRow['total'] ?? 0);

    return [
        'total_visitas' => $totalVisitas,
        'total_interacoes' => $totalInteracoes,
        'total_registros' => $totalVisitas + $totalInteracoes,
        'total_compromissos_periodo' => $totalCompromissos,
        'demandas_abertas' => (int) ($demandasAbertasRow['total_abertas'] ?? 0),
    ];
}

function fetch_timeline_visitas(mysqli $db, array $filtro): array
{
    return db_query_all(
        $db,
        '
        SELECT
            DATE(COALESCE(v.data_contato, v.criado_em)) AS data,
            COUNT(*) AS quantidade
        FROM f_visitas v
        WHERE ' . $filtro['where_sql'] . '
        GROUP BY DATE(COALESCE(v.data_contato, v.criado_em))
        ORDER BY data ASC
    ',
        $filtro['types'],
        $filtro['params']
    );
}

function fetch_timeline_interacoes(mysqli $db, array $filtro): array
{
    return db_query_all(
        $db,
        '
        SELECT
            DATE(COALESCE(i.data_contato, i.criado_em)) AS data,
            COUNT(*) AS quantidade
        FROM f_interacoes i
        WHERE ' . $filtro['where_sql'] . '
        GROUP BY DATE(COALESCE(i.data_contato, i.criado_em))
        ORDER BY data ASC
    ',
        $filtro['types'],
        $filtro['params']
    );
}

function fetch_interacoes_por_tipo(mysqli $db, array $filtro): array
{
    return db_query_all(
        $db,
        '
        SELECT
            ti.nome AS tipo,
            COUNT(*) AS quantidade
        FROM f_interacoes i
        JOIN d_tipos_interacao ti ON ti.id = i.tipo_interacao_id
        WHERE ' . $filtro['where_sql'] . '
        GROUP BY ti.nome
        ORDER BY quantidade DESC, ti.nome ASC
    ',
        $filtro['types'],
        $filtro['params']
    );
}

function fetch_demandas_por_status(mysqli $db, array $visitasFiltro, array $interacoesFiltro): array
{
    return db_query_all(
        $db,
        '
        SELECT status, SUM(quantidade) AS quantidade
        FROM (
            SELECT
                COALESCE(sd.nome, "Sem Status") AS status,
                COUNT(*) AS quantidade
            FROM f_visitas v
            LEFT JOIN d_status_demanda sd ON sd.id = v.status_demanda_id
            WHERE ' . $visitasFiltro['where_sql'] . '
            GROUP BY COALESCE(sd.nome, "Sem Status")

            UNION ALL

            SELECT
                COALESCE(sd.nome, "Sem Status") AS status,
                COUNT(*) AS quantidade
            FROM f_interacoes i
            LEFT JOIN d_status_demanda sd ON sd.id = i.status_demanda_id
            WHERE ' . $interacoesFiltro['where_sql'] . '
            GROUP BY COALESCE(sd.nome, "Sem Status")
        ) t
        GROUP BY status
        ORDER BY quantidade DESC, status ASC
    ',
        $visitasFiltro['types'] . $interacoesFiltro['types'],
        array_merge($visitasFiltro['params'], $interacoesFiltro['params'])
    );
}

function fetch_top_agencias(mysqli $db, array $visitasFiltro, array $interacoesFiltro): array
{
    return db_query_all(
        $db,
        '
        SELECT
            ag.id AS agencia_id,
            ag.nome AS agencia_nome,
            COALESCE(v.total_visitas, 0) AS total_visitas,
            COALESCE(i.total_interacoes, 0) AS total_interacoes,
            (COALESCE(v.total_visitas, 0) + COALESCE(i.total_interacoes, 0)) AS total
        FROM d_agencias ag
        LEFT JOIN (
            SELECT
                v.agencia_id,
                COUNT(*) AS total_visitas
            FROM f_visitas v
            WHERE ' . $visitasFiltro['where_sql'] . '
            GROUP BY v.agencia_id
        ) v ON v.agencia_id = ag.id
        LEFT JOIN (
            SELECT
                i.agencia_id,
                COUNT(*) AS total_interacoes
            FROM f_interacoes i
            WHERE ' . $interacoesFiltro['where_sql'] . ' AND i.agencia_id IS NOT NULL
            GROUP BY i.agencia_id
        ) i ON i.agencia_id = ag.id
        WHERE (COALESCE(v.total_visitas, 0) + COALESCE(i.total_interacoes, 0)) > 0
        ORDER BY total DESC, ag.nome ASC
        LIMIT 10
    ',
        $visitasFiltro['types'] . $interacoesFiltro['types'],
        array_merge($visitasFiltro['params'], $interacoesFiltro['params'])
    );
}

function fetch_compromissos_periodo(mysqli $db, array $periodo, ?int $usuarioId): array
{
    $where = ['DATE(c.data_inicio) BETWEEN ? AND ?'];
    $types = 'ss';
    $params = [$periodo['data_inicio'], $periodo['data_fim']];

    if ($usuarioId !== null && $usuarioId > 0) {
        $where[] = 'c.usuario_id = ?';
        $types .= 'i';
        $params[] = $usuarioId;
    }

    return db_query_all(
        $db,
        '
        SELECT
            c.id,
            c.titulo,
            c.data_inicio,
            c.data_fim,
            u.nome AS usuario_nome,
            tc.nome AS tipo_compromisso,
            COALESCE(c.cor, tc.cor_padrao) AS cor
        FROM f_compromissos c
        JOIN d_usuarios u ON u.id = c.usuario_id
        JOIN d_tipos_compromisso tc ON tc.id = c.tipo_compromisso_id
        WHERE ' . implode(' AND ', $where) . '
        ORDER BY c.data_inicio ASC
        LIMIT 50
    ',
        $types,
        $params
    );
}

function fetch_compromissos_hoje(mysqli $db, ?int $usuarioId): array
{
    $where = ['DATE(c.data_inicio) = CURDATE()'];
    $types = '';
    $params = [];

    if ($usuarioId !== null && $usuarioId > 0) {
        $where[] = 'c.usuario_id = ?';
        $types .= 'i';
        $params[] = $usuarioId;
    }

    return db_query_all(
        $db,
        '
        SELECT
            c.id,
            c.titulo,
            c.data_inicio,
            c.data_fim,
            u.nome AS usuario_nome,
            tc.nome AS tipo_compromisso,
            COALESCE(c.cor, tc.cor_padrao) AS cor
        FROM f_compromissos c
        JOIN d_usuarios u ON u.id = c.usuario_id
        JOIN d_tipos_compromisso tc ON tc.id = c.tipo_compromisso_id
        WHERE ' . implode(' AND ', $where) . '
        ORDER BY c.data_inicio ASC
    ',
        $types,
        $params
    );
}
