﻿<?php

require_once __DIR__ . '/../lib/http.php';
require_once __DIR__ . '/../lib/db.php';

init_api();

try {
    $db = db_connect();
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($method === 'GET') {
        handle_get($db);
    }
    if ($method === 'POST') {
        handle_post($db);
    }
    if ($method === 'PUT') {
        handle_put($db);
    }
    if ($method === 'DELETE') {
        handle_delete($db);
    }

    json_error('Metodo nao permitido.', 405);
} catch (Throwable $e) {
    json_error('Erro interno no servidor.', 500, ['detalhe' => $e->getMessage()]);
}

function handle_get(mysqli $db): void
{
    $id = to_int_or_null($_GET['id'] ?? null);

    if ($id !== null && $id > 0) {
        $compromisso = get_compromisso($db, $id);
        if (!$compromisso) {
            json_error('Compromisso nao encontrado.', 404);
        }

        json_response(['compromisso' => $compromisso]);
    }

    $filters = build_list_filters($_GET);
    $whereSql = $filters['where_sql'];
    $types = $filters['types'];
    $params = $filters['params'];

    $limit = to_int_or_null($_GET['limit'] ?? 50) ?? 50;
    $limit = max(1, min(200, $limit));

    $offset = to_int_or_null($_GET['offset'] ?? 0) ?? 0;
    $offset = max(0, $offset);

    $sql = '
        SELECT
            c.id,
            c.usuario_id,
            u.nome AS usuario_nome,
            c.tipo_compromisso_id,
            tc.nome AS tipo_compromisso,
            COALESCE(c.cor, tc.cor_padrao) AS cor,
            c.titulo,
            c.descricao,
            c.data_inicio,
            c.data_fim,
            c.criado_em,
            c.atualizado_em
        FROM f_compromissos c
        JOIN d_usuarios u ON u.id = c.usuario_id
        JOIN d_tipos_compromisso tc ON tc.id = c.tipo_compromisso_id
        WHERE 1=1 ' . $whereSql . '
        ORDER BY c.data_inicio ASC, c.id ASC
        LIMIT ? OFFSET ?
    ';

    $listTypes = $types . 'ii';
    $listParams = array_merge($params, [$limit, $offset]);

    $compromissos = db_query_all($db, $sql, $listTypes, $listParams);

    $countSql = 'SELECT COUNT(*) AS total FROM f_compromissos c WHERE 1=1 ' . $whereSql;
    $countRow = db_query_one($db, $countSql, $types, $params);

    json_response([
        'compromissos' => $compromissos,
        'total' => (int) ($countRow['total'] ?? 0),
        'limit' => $limit,
        'offset' => $offset,
    ]);
}

function build_list_filters(array $source): array
{
    $where = [];
    $types = '';
    $params = [];

    $usuarioId = to_int_or_null($source['usuario_id'] ?? null);
    if ($usuarioId !== null && $usuarioId > 0) {
        $where[] = ' AND c.usuario_id = ?';
        $types .= 'i';
        $params[] = $usuarioId;
    }

    $tipoId = to_int_or_null($source['tipo_compromisso_id'] ?? null);
    if ($tipoId !== null && $tipoId > 0) {
        $where[] = ' AND c.tipo_compromisso_id = ?';
        $types .= 'i';
        $params[] = $tipoId;
    }

    $inicio = to_string_or_null($source['data_inicio'] ?? null);
    if ($inicio !== null) {
        $inicioTs = strtotime($inicio);
        if ($inicioTs === false) {
            json_error('data_inicio invalida.', 422);
        }

        $where[] = ' AND DATE(c.data_inicio) >= ?';
        $types .= 's';
        $params[] = date('Y-m-d', $inicioTs);
    }

    $fim = to_string_or_null($source['data_fim'] ?? null);
    if ($fim !== null) {
        $fimTs = strtotime($fim);
        if ($fimTs === false) {
            json_error('data_fim invalida.', 422);
        }

        $where[] = ' AND DATE(c.data_fim) <= ?';
        $types .= 's';
        $params[] = date('Y-m-d', $fimTs);
    }

    $busca = to_string_or_null($source['q'] ?? null);
    if ($busca !== null) {
        $like = '%' . $busca . '%';
        $where[] = ' AND (c.titulo LIKE ? OR c.descricao LIKE ?)';
        $types .= 'ss';
        $params[] = $like;
        $params[] = $like;
    }

    return [
        'where_sql' => implode('', $where),
        'types' => $types,
        'params' => $params,
    ];
}

function handle_post(mysqli $db): void
{
    $payload = json_input();
    require_fields($payload, ['usuario_id', 'tipo_compromisso_id', 'titulo', 'data_inicio', 'data_fim']);

    $usuarioId = to_int_or_null($payload['usuario_id']);
    $tipoId = to_int_or_null($payload['tipo_compromisso_id']);
    $titulo = to_string_or_null($payload['titulo']);
    $descricao = to_string_or_null($payload['descricao'] ?? null);
    $dataInicio = parse_datetime_or_null($payload['data_inicio']);
    $dataFim = parse_datetime_or_null($payload['data_fim']);
    $cor = to_string_or_null($payload['cor'] ?? null);

    if ($usuarioId === null || $usuarioId <= 0 || $tipoId === null || $tipoId <= 0 || $titulo === null) {
        json_error('Campos obrigatorios invalidos para criar compromisso.', 422);
    }

    if (strtotime($dataFim) < strtotime($dataInicio)) {
        json_error('data_fim deve ser maior ou igual a data_inicio.', 422);
    }

    $res = db_execute(
        $db,
        'INSERT INTO f_compromissos (usuario_id, tipo_compromisso_id, titulo, descricao, data_inicio, data_fim, cor) VALUES (?, ?, ?, ?, ?, ?, ?)',
        'iisssss',
        [$usuarioId, $tipoId, $titulo, $descricao, $dataInicio, $dataFim, $cor]
    );

    $compromisso = get_compromisso($db, (int) $res['insert_id']);
    json_response(['sucesso' => true, 'compromisso' => $compromisso], 201);
}

function handle_put(mysqli $db): void
{
    $payload = json_input();
    require_fields($payload, ['id']);

    $id = to_int_or_null($payload['id']);
    if ($id === null || $id <= 0) {
        json_error('ID de compromisso invalido.', 422);
    }

    $atual = get_compromisso($db, $id);
    if (!$atual) {
        json_error('Compromisso nao encontrado.', 404);
    }

    $fields = [];
    $types = '';
    $params = [];

    $map = [
        'usuario_id' => ['usuario_id', 'i'],
        'tipo_compromisso_id' => ['tipo_compromisso_id', 'i'],
        'titulo' => ['titulo', 's'],
        'descricao' => ['descricao', 's'],
        'data_inicio' => ['data_inicio', 's'],
        'data_fim' => ['data_fim', 's'],
        'cor' => ['cor', 's'],
    ];

    foreach ($map as $inputKey => [$column, $type]) {
        if (!array_key_exists($inputKey, $payload)) {
            continue;
        }

        $value = $payload[$inputKey];

        if (in_array($inputKey, ['titulo', 'descricao', 'cor'], true)) {
            $value = to_string_or_null($value);
            if ($inputKey === 'titulo' && $value === null) {
                json_error('titulo nao pode ser vazio.', 422);
            }
        } elseif (in_array($inputKey, ['data_inicio', 'data_fim'], true)) {
            $value = parse_datetime_or_null($value);
            if ($value === null) {
                json_error($inputKey . ' nao pode ser vazio.', 422);
            }
        } else {
            $value = to_int_or_null($value);
            if ($value === null || $value <= 0) {
                json_error('Campo invalido para ' . $inputKey, 422);
            }
        }

        $fields[] = $column . ' = ?';
        $types .= $type;
        $params[] = $value;
    }

    if (count($fields) === 0) {
        json_error('Nenhum campo para atualizar.', 422);
    }

    $futureInicio = $payload['data_inicio'] ?? $atual['data_inicio'];
    $futureFim = $payload['data_fim'] ?? $atual['data_fim'];
    $futureInicioParsed = parse_datetime_or_null($futureInicio);
    $futureFimParsed = parse_datetime_or_null($futureFim);

    if (strtotime($futureFimParsed) < strtotime($futureInicioParsed)) {
        json_error('data_fim deve ser maior ou igual a data_inicio.', 422);
    }

    $params[] = $id;
    $types .= 'i';

    $sql = 'UPDATE f_compromissos SET ' . implode(', ', $fields) . ' WHERE id = ?';
    db_execute($db, $sql, $types, $params);

    $compromisso = get_compromisso($db, $id);
    json_response(['sucesso' => true, 'compromisso' => $compromisso]);
}

function handle_delete(mysqli $db): void
{
    $payload = json_input();
    $id = to_int_or_null($payload['id'] ?? ($_GET['id'] ?? null));

    if ($id === null || $id <= 0) {
        json_error('ID de compromisso invalido para exclusao.', 422);
    }

    $res = db_execute($db, 'DELETE FROM f_compromissos WHERE id = ?', 'i', [$id]);
    if ($res['affected_rows'] < 1) {
        json_error('Compromisso nao encontrado para exclusao.', 404);
    }

    json_response(['sucesso' => true, 'id' => $id]);
}

function get_compromisso(mysqli $db, int $id): ?array
{
    return db_query_one(
        $db,
        '
        SELECT
            c.id,
            c.usuario_id,
            u.nome AS usuario_nome,
            c.tipo_compromisso_id,
            tc.nome AS tipo_compromisso,
            COALESCE(c.cor, tc.cor_padrao) AS cor,
            c.titulo,
            c.descricao,
            c.data_inicio,
            c.data_fim,
            c.criado_em,
            c.atualizado_em
        FROM f_compromissos c
        JOIN d_usuarios u ON u.id = c.usuario_id
        JOIN d_tipos_compromisso tc ON tc.id = c.tipo_compromisso_id
        WHERE c.id = ?
        LIMIT 1
    ',
        'i',
        [$id]
    );
}
