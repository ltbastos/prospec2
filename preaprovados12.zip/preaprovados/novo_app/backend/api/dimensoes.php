﻿<?php

require_once __DIR__ . '/../lib/http.php';
require_once __DIR__ . '/../lib/db.php';

init_api();

try {
    $db = db_connect();
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($method === 'GET') {
        handle_get($db);
    }
    if ($method === 'POST') {
        handle_post($db);
    }
    if ($method === 'PUT') {
        handle_put($db);
    }
    if ($method === 'DELETE') {
        handle_delete($db);
    }

    json_error('Metodo nao permitido.', 405);
} catch (Throwable $e) {
    json_error('Erro interno no servidor.', 500, ['detalhe' => $e->getMessage()]);
}

function dimension_map(): array
{
    return [
        'usuarios' => [
            'table' => 'd_usuarios',
            'default_order' => 'nome ASC',
            'select' => 'id, nome, slug, ativo, criado_em, atualizado_em',
        ],
        'agencias' => [
            'table' => 'd_agencias',
            'default_order' => 'nome ASC',
            'select' => 'id, nome, codigo, cidade, uf, ativo, criado_em, atualizado_em',
        ],
        'temas_visita' => [
            'table' => 'd_temas_visita',
            'default_order' => 'nome ASC',
            'select' => 'id, nome, ativo, criado_em, atualizado_em',
        ],
        'tipos_interacao' => [
            'table' => 'd_tipos_interacao',
            'default_order' => 'nome ASC',
            'select' => 'id, nome, ativo, criado_em, atualizado_em',
        ],
        'areas_responsaveis' => [
            'table' => 'd_areas_responsaveis',
            'default_order' => 'nome ASC',
            'select' => 'id, nome, ativo, criado_em, atualizado_em',
        ],
        'status_demanda' => [
            'table' => 'd_status_demanda',
            'default_order' => 'ordem ASC, nome ASC',
            'select' => 'id, nome, ordem, ativo, criado_em, atualizado_em',
        ],
        'tipos_compromisso' => [
            'table' => 'd_tipos_compromisso',
            'default_order' => 'nome ASC',
            'select' => 'id, nome, cor_padrao, ativo, criado_em, atualizado_em',
        ],
    ];
}

function handle_get(mysqli $db): void
{
    $tipo = to_string_or_null($_GET['tipo'] ?? 'all');
    $apenasAtivos = (($_GET['ativos'] ?? '1') === '1');

    $map = dimension_map();

    if ($tipo === null || $tipo === 'all') {
        $dados = [];
        foreach ($map as $key => $cfg) {
            $dados[$key] = fetch_dimension($db, $cfg, $apenasAtivos);
        }

        json_response(['dados' => $dados]);
    }

    if (!isset($map[$tipo])) {
        json_error('Tipo de dimensao invalido.', 422);
    }

    $rows = fetch_dimension($db, $map[$tipo], $apenasAtivos);
    json_response(['tipo' => $tipo, 'dados' => $rows]);
}

function fetch_dimension(mysqli $db, array $cfg, bool $apenasAtivos): array
{
    $sql = 'SELECT ' . $cfg['select'] . ' FROM ' . $cfg['table'];
    if ($apenasAtivos) {
        $sql .= ' WHERE ativo = 1';
    }
    $sql .= ' ORDER BY ' . $cfg['default_order'];

    return db_query_all($db, $sql);
}

function handle_post(mysqli $db): void
{
    $payload = json_input();
    require_fields($payload, ['tipo']);

    $tipo = (string) $payload['tipo'];

    switch ($tipo) {
        case 'usuarios':
            create_usuario($db, $payload);
            return;
        case 'agencias':
            create_agencia($db, $payload);
            return;
        case 'temas_visita':
            create_simple_nome($db, $payload, 'd_temas_visita');
            return;
        case 'tipos_interacao':
            create_simple_nome($db, $payload, 'd_tipos_interacao');
            return;
        case 'areas_responsaveis':
            create_simple_nome($db, $payload, 'd_areas_responsaveis');
            return;
        case 'status_demanda':
            create_status($db, $payload);
            return;
        case 'tipos_compromisso':
            create_tipo_compromisso($db, $payload);
            return;
        default:
            json_error('Tipo de dimensao invalido para cadastro.', 422);
    }
}

function handle_put(mysqli $db): void
{
    $payload = json_input();
    require_fields($payload, ['tipo', 'id']);

    $tipo = (string) $payload['tipo'];
    $id = to_int_or_null($payload['id']);
    if ($id === null || $id <= 0) {
        json_error('ID invalido.', 422);
    }

    switch ($tipo) {
        case 'usuarios':
            update_usuario($db, $id, $payload);
            return;
        case 'agencias':
            update_agencia($db, $id, $payload);
            return;
        case 'temas_visita':
            update_simple_nome($db, $id, $payload, 'd_temas_visita');
            return;
        case 'tipos_interacao':
            update_simple_nome($db, $id, $payload, 'd_tipos_interacao');
            return;
        case 'areas_responsaveis':
            update_simple_nome($db, $id, $payload, 'd_areas_responsaveis');
            return;
        case 'status_demanda':
            update_status($db, $id, $payload);
            return;
        case 'tipos_compromisso':
            update_tipo_compromisso($db, $id, $payload);
            return;
        default:
            json_error('Tipo de dimensao invalido para atualizacao.', 422);
    }
}

function handle_delete(mysqli $db): void
{
    $payload = json_input();

    $tipo = to_string_or_null($payload['tipo'] ?? ($_GET['tipo'] ?? null));
    $id = to_int_or_null($payload['id'] ?? ($_GET['id'] ?? null));

    if ($tipo === null || $id === null || $id <= 0) {
        json_error('Informe tipo e id para exclusao logica.', 422);
    }

    $map = dimension_map();
    if (!isset($map[$tipo])) {
        json_error('Tipo de dimensao invalido para exclusao.', 422);
    }

    $sql = 'UPDATE ' . $map[$tipo]['table'] . ' SET ativo = 0 WHERE id = ?';
    $res = db_execute($db, $sql, 'i', [$id]);

    if ($res['affected_rows'] < 1) {
        json_error('Registro nao encontrado para exclusao.', 404);
    }

    json_response(['sucesso' => true, 'id' => $id, 'tipo' => $tipo]);
}

function create_usuario(mysqli $db, array $payload): void
{
    require_fields($payload, ['nome', 'slug']);

    $nome = to_string_or_null($payload['nome']);
    $slug = to_string_or_null($payload['slug']);

    $res = db_execute(
        $db,
        'INSERT INTO d_usuarios (nome, slug) VALUES (?, ?)',
        'ss',
        [$nome, $slug]
    );

    $row = db_query_one($db, 'SELECT id, nome, slug, ativo, criado_em, atualizado_em FROM d_usuarios WHERE id = ?', 'i', [$res['insert_id']]);
    json_response(['sucesso' => true, 'dados' => $row], 201);
}

function create_agencia(mysqli $db, array $payload): void
{
    require_fields($payload, ['nome']);

    $nome = to_string_or_null($payload['nome']);
    $codigo = to_string_or_null($payload['codigo'] ?? null);
    $cidade = to_string_or_null($payload['cidade'] ?? null);
    $uf = to_string_or_null($payload['uf'] ?? null);

    if ($uf !== null) {
        $uf = strtoupper($uf);
    }

    $res = db_execute(
        $db,
        'INSERT INTO d_agencias (nome, codigo, cidade, uf) VALUES (?, ?, ?, ?)',
        'ssss',
        [$nome, $codigo, $cidade, $uf]
    );

    $row = db_query_one($db, 'SELECT id, nome, codigo, cidade, uf, ativo, criado_em, atualizado_em FROM d_agencias WHERE id = ?', 'i', [$res['insert_id']]);
    json_response(['sucesso' => true, 'dados' => $row], 201);
}

function create_simple_nome(mysqli $db, array $payload, string $table): void
{
    require_fields($payload, ['nome']);

    $nome = to_string_or_null($payload['nome']);

    $res = db_execute($db, 'INSERT INTO ' . $table . ' (nome) VALUES (?)', 's', [$nome]);
    $row = db_query_one($db, 'SELECT id, nome, ativo, criado_em, atualizado_em FROM ' . $table . ' WHERE id = ?', 'i', [$res['insert_id']]);

    json_response(['sucesso' => true, 'dados' => $row], 201);
}

function create_status(mysqli $db, array $payload): void
{
    require_fields($payload, ['nome']);

    $nome = to_string_or_null($payload['nome']);
    $ordem = to_int_or_null($payload['ordem'] ?? 0) ?? 0;

    $res = db_execute(
        $db,
        'INSERT INTO d_status_demanda (nome, ordem) VALUES (?, ?)',
        'si',
        [$nome, $ordem]
    );

    $row = db_query_one($db, 'SELECT id, nome, ordem, ativo, criado_em, atualizado_em FROM d_status_demanda WHERE id = ?', 'i', [$res['insert_id']]);
    json_response(['sucesso' => true, 'dados' => $row], 201);
}

function create_tipo_compromisso(mysqli $db, array $payload): void
{
    require_fields($payload, ['nome']);

    $nome = to_string_or_null($payload['nome']);
    $cor = to_string_or_null($payload['cor_padrao'] ?? '#2563eb') ?? '#2563eb';

    $res = db_execute(
        $db,
        'INSERT INTO d_tipos_compromisso (nome, cor_padrao) VALUES (?, ?)',
        'ss',
        [$nome, $cor]
    );

    $row = db_query_one($db, 'SELECT id, nome, cor_padrao, ativo, criado_em, atualizado_em FROM d_tipos_compromisso WHERE id = ?', 'i', [$res['insert_id']]);
    json_response(['sucesso' => true, 'dados' => $row], 201);
}

function update_usuario(mysqli $db, int $id, array $payload): void
{
    $fields = [];
    $params = [];
    $types = '';

    if (array_key_exists('nome', $payload)) {
        $fields[] = 'nome = ?';
        $params[] = to_string_or_null($payload['nome']);
        $types .= 's';
    }
    if (array_key_exists('slug', $payload)) {
        $fields[] = 'slug = ?';
        $params[] = to_string_or_null($payload['slug']);
        $types .= 's';
    }
    if (array_key_exists('ativo', $payload)) {
        $fields[] = 'ativo = ?';
        $params[] = (int) ((bool) $payload['ativo']);
        $types .= 'i';
    }

    generic_update_or_422($db, 'd_usuarios', $id, $fields, $types, $params);
}

function update_agencia(mysqli $db, int $id, array $payload): void
{
    $fields = [];
    $params = [];
    $types = '';

    if (array_key_exists('nome', $payload)) {
        $fields[] = 'nome = ?';
        $params[] = to_string_or_null($payload['nome']);
        $types .= 's';
    }
    if (array_key_exists('codigo', $payload)) {
        $fields[] = 'codigo = ?';
        $params[] = to_string_or_null($payload['codigo']);
        $types .= 's';
    }
    if (array_key_exists('cidade', $payload)) {
        $fields[] = 'cidade = ?';
        $params[] = to_string_or_null($payload['cidade']);
        $types .= 's';
    }
    if (array_key_exists('uf', $payload)) {
        $uf = to_string_or_null($payload['uf']);
        $fields[] = 'uf = ?';
        $params[] = $uf !== null ? strtoupper($uf) : null;
        $types .= 's';
    }
    if (array_key_exists('ativo', $payload)) {
        $fields[] = 'ativo = ?';
        $params[] = (int) ((bool) $payload['ativo']);
        $types .= 'i';
    }

    generic_update_or_422($db, 'd_agencias', $id, $fields, $types, $params);
}

function update_simple_nome(mysqli $db, int $id, array $payload, string $table): void
{
    $fields = [];
    $params = [];
    $types = '';

    if (array_key_exists('nome', $payload)) {
        $fields[] = 'nome = ?';
        $params[] = to_string_or_null($payload['nome']);
        $types .= 's';
    }
    if (array_key_exists('ativo', $payload)) {
        $fields[] = 'ativo = ?';
        $params[] = (int) ((bool) $payload['ativo']);
        $types .= 'i';
    }

    generic_update_or_422($db, $table, $id, $fields, $types, $params);
}

function update_status(mysqli $db, int $id, array $payload): void
{
    $fields = [];
    $params = [];
    $types = '';

    if (array_key_exists('nome', $payload)) {
        $fields[] = 'nome = ?';
        $params[] = to_string_or_null($payload['nome']);
        $types .= 's';
    }
    if (array_key_exists('ordem', $payload)) {
        $fields[] = 'ordem = ?';
        $params[] = to_int_or_null($payload['ordem'] ?? 0) ?? 0;
        $types .= 'i';
    }
    if (array_key_exists('ativo', $payload)) {
        $fields[] = 'ativo = ?';
        $params[] = (int) ((bool) $payload['ativo']);
        $types .= 'i';
    }

    generic_update_or_422($db, 'd_status_demanda', $id, $fields, $types, $params);
}

function update_tipo_compromisso(mysqli $db, int $id, array $payload): void
{
    $fields = [];
    $params = [];
    $types = '';

    if (array_key_exists('nome', $payload)) {
        $fields[] = 'nome = ?';
        $params[] = to_string_or_null($payload['nome']);
        $types .= 's';
    }
    if (array_key_exists('cor_padrao', $payload)) {
        $fields[] = 'cor_padrao = ?';
        $params[] = to_string_or_null($payload['cor_padrao']);
        $types .= 's';
    }
    if (array_key_exists('ativo', $payload)) {
        $fields[] = 'ativo = ?';
        $params[] = (int) ((bool) $payload['ativo']);
        $types .= 'i';
    }

    generic_update_or_422($db, 'd_tipos_compromisso', $id, $fields, $types, $params);
}

function generic_update_or_422(mysqli $db, string $table, int $id, array $fields, string $types, array $params): void
{
    if (count($fields) === 0) {
        json_error('Nenhum campo valido para atualizacao.', 422);
    }

    $params[] = $id;
    $types .= 'i';

    $sql = 'UPDATE ' . $table . ' SET ' . implode(', ', $fields) . ' WHERE id = ?';
    db_execute($db, $sql, $types, $params);

    $row = db_query_one($db, 'SELECT * FROM ' . $table . ' WHERE id = ?', 'i', [$id]);
    if (!$row) {
        json_error('Registro nao encontrado.', 404);
    }

    json_response(['sucesso' => true, 'dados' => $row]);
}
