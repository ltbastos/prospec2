﻿<?php

require_once __DIR__ . '/../lib/http.php';
require_once __DIR__ . '/../lib/db.php';

init_api();

try {
    $db = db_connect();
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($method === 'GET') {
        handle_get($db);
    }
    if ($method === 'POST') {
        handle_post($db);
    }
    if ($method === 'PUT') {
        handle_put($db);
    }
    if ($method === 'DELETE') {
        handle_delete($db);
    }

    json_error('Metodo nao permitido.', 405);
} catch (Throwable $e) {
    json_error('Erro interno no servidor.', 500, ['detalhe' => $e->getMessage()]);
}

function handle_get(mysqli $db): void
{
    $id = to_int_or_null($_GET['id'] ?? null);

    if ($id !== null && $id > 0) {
        $interacao = get_interacao($db, $id);
        if (!$interacao) {
            json_error('Interacao nao encontrada.', 404);
        }

        $interacao['contatos'] = get_interacao_contatos($db, $id);
        json_response(['interacao' => $interacao]);
    }

    $filters = build_list_filters($_GET);
    $whereSql = $filters['where_sql'];
    $types = $filters['types'];
    $params = $filters['params'];

    $limit = to_int_or_null($_GET['limit'] ?? 50) ?? 50;
    $limit = max(1, min(200, $limit));

    $offset = to_int_or_null($_GET['offset'] ?? 0) ?? 0;
    $offset = max(0, $offset);

    $sql = '
        SELECT
            i.id,
            i.usuario_id,
            u.nome AS usuario_nome,
            i.tipo_interacao_id,
            ti.nome AS tipo_interacao,
            i.agencia_id,
            a.nome AS agencia_nome,
            a.cidade AS agencia_cidade,
            a.uf AS agencia_uf,
            i.diretoria,
            i.regional,
            i.nome_contato,
            i.subsecao_contato,
            i.assunto,
            i.descricao,
            i.demandas,
            i.area_responsavel_id,
            ar.nome AS area_responsavel,
            i.status_demanda_id,
            sd.nome AS status_demanda,
            i.tags,
            i.data_contato,
            i.criado_em,
            i.atualizado_em,
            (SELECT COUNT(*) FROM f_interacoes_contatos c WHERE c.interacao_id = i.id) AS total_contatos
        FROM f_interacoes i
        JOIN d_usuarios u ON u.id = i.usuario_id
        JOIN d_tipos_interacao ti ON ti.id = i.tipo_interacao_id
        LEFT JOIN d_agencias a ON a.id = i.agencia_id
        LEFT JOIN d_areas_responsaveis ar ON ar.id = i.area_responsavel_id
        LEFT JOIN d_status_demanda sd ON sd.id = i.status_demanda_id
        WHERE 1=1 ' . $whereSql . '
        ORDER BY COALESCE(i.data_contato, i.criado_em) DESC, i.id DESC
        LIMIT ? OFFSET ?
    ';

    $listTypes = $types . 'ii';
    $listParams = array_merge($params, [$limit, $offset]);

    $interacoes = db_query_all($db, $sql, $listTypes, $listParams);

    $countSql = 'SELECT COUNT(*) AS total FROM f_interacoes i WHERE 1=1 ' . $whereSql;
    $countRow = db_query_one($db, $countSql, $types, $params);

    json_response([
        'interacoes' => $interacoes,
        'total' => (int) ($countRow['total'] ?? 0),
        'limit' => $limit,
        'offset' => $offset,
    ]);
}

function build_list_filters(array $source): array
{
    $where = [];
    $types = '';
    $params = [];

    $usuarioId = to_int_or_null($source['usuario_id'] ?? null);
    if ($usuarioId !== null && $usuarioId > 0) {
        $where[] = ' AND i.usuario_id = ?';
        $types .= 'i';
        $params[] = $usuarioId;
    }

    $tipoId = to_int_or_null($source['tipo_interacao_id'] ?? null);
    if ($tipoId !== null && $tipoId > 0) {
        $where[] = ' AND i.tipo_interacao_id = ?';
        $types .= 'i';
        $params[] = $tipoId;
    }

    $agenciaId = to_int_or_null($source['agencia_id'] ?? null);
    if ($agenciaId !== null && $agenciaId > 0) {
        $where[] = ' AND i.agencia_id = ?';
        $types .= 'i';
        $params[] = $agenciaId;
    }

    $statusId = to_int_or_null($source['status_demanda_id'] ?? null);
    if ($statusId !== null && $statusId > 0) {
        $where[] = ' AND i.status_demanda_id = ?';
        $types .= 'i';
        $params[] = $statusId;
    }

    $inicio = to_string_or_null($source['data_inicio'] ?? null);
    if ($inicio !== null) {
        $where[] = ' AND DATE(i.data_contato) >= ?';
        $types .= 's';
        $params[] = $inicio;
    }

    $fim = to_string_or_null($source['data_fim'] ?? null);
    if ($fim !== null) {
        $where[] = ' AND DATE(i.data_contato) <= ?';
        $types .= 's';
        $params[] = $fim;
    }

    $busca = to_string_or_null($source['q'] ?? null);
    if ($busca !== null) {
        $like = '%' . $busca . '%';
        $where[] = ' AND (i.assunto LIKE ? OR i.descricao LIKE ? OR i.nome_contato LIKE ? OR i.tags LIKE ?)';
        $types .= 'ssss';
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
    }

    return [
        'where_sql' => implode('', $where),
        'types' => $types,
        'params' => $params,
    ];
}

function handle_post(mysqli $db): void
{
    $payload = json_input();
    require_fields($payload, ['usuario_id', 'tipo_interacao_id', 'assunto', 'descricao']);

    $usuarioId = to_int_or_null($payload['usuario_id']);
    $tipoId = to_int_or_null($payload['tipo_interacao_id']);
    $assunto = to_string_or_null($payload['assunto']);
    $descricao = to_string_or_null($payload['descricao']);

    if ($usuarioId === null || $usuarioId <= 0 || $tipoId === null || $tipoId <= 0 || $assunto === null || $descricao === null) {
        json_error('Campos obrigatorios invalidos para criar interacao.', 422);
    }

    $agenciaId = to_int_or_null($payload['agencia_id'] ?? null);
    $diretoria = to_string_or_null($payload['diretoria'] ?? null);
    $regional = to_string_or_null($payload['regional'] ?? null);
    $nomeContato = to_string_or_null($payload['nome_contato'] ?? null);
    $subsecaoContato = to_string_or_null($payload['subsecao_contato'] ?? null);
    $demandas = to_string_or_null($payload['demandas'] ?? null);
    $areaId = to_int_or_null($payload['area_responsavel_id'] ?? null);
    $statusId = to_int_or_null($payload['status_demanda_id'] ?? null);
    $tags = to_string_or_null($payload['tags'] ?? null);
    $dataContato = parse_datetime_or_null($payload['data_contato'] ?? null);

    $contatos = [];
    if (array_key_exists('contatos', $payload)) {
        if (!is_array($payload['contatos'])) {
            json_error('contatos deve ser um array.', 422);
        }
        $contatos = $payload['contatos'];
    }

    $types = implode('', ['i', 'i', 'i', 's', 's', 's', 's', 's', 's', 's', 'i', 'i', 's', 's']);
    $params = [
        $usuarioId,
        $tipoId,
        $agenciaId,
        $diretoria,
        $regional,
        $nomeContato,
        $subsecaoContato,
        $assunto,
        $descricao,
        $demandas,
        $areaId,
        $statusId,
        $tags,
        $dataContato,
    ];

    $db->begin_transaction();
    try {
        $res = db_execute(
            $db,
            'INSERT INTO f_interacoes (usuario_id, tipo_interacao_id, agencia_id, diretoria, regional, nome_contato, subsecao_contato, assunto, descricao, demandas, area_responsavel_id, status_demanda_id, tags, data_contato) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            $types,
            $params
        );

        $interacaoId = (int) $res['insert_id'];
        replace_contatos($db, $interacaoId, $contatos);

        $db->commit();

        $interacao = get_interacao($db, $interacaoId);
        $interacao['contatos'] = get_interacao_contatos($db, $interacaoId);

        json_response(['sucesso' => true, 'interacao' => $interacao], 201);
    } catch (Throwable $e) {
        $db->rollback();
        throw $e;
    }
}

function handle_put(mysqli $db): void
{
    $payload = json_input();
    require_fields($payload, ['id']);

    $id = to_int_or_null($payload['id']);
    if ($id === null || $id <= 0) {
        json_error('ID de interacao invalido.', 422);
    }

    if (!get_interacao($db, $id)) {
        json_error('Interacao nao encontrada.', 404);
    }

    $fields = [];
    $types = '';
    $params = [];

    $map = [
        'usuario_id' => ['usuario_id', 'i'],
        'tipo_interacao_id' => ['tipo_interacao_id', 'i'],
        'agencia_id' => ['agencia_id', 'i'],
        'diretoria' => ['diretoria', 's'],
        'regional' => ['regional', 's'],
        'nome_contato' => ['nome_contato', 's'],
        'subsecao_contato' => ['subsecao_contato', 's'],
        'assunto' => ['assunto', 's'],
        'descricao' => ['descricao', 's'],
        'demandas' => ['demandas', 's'],
        'area_responsavel_id' => ['area_responsavel_id', 'i'],
        'status_demanda_id' => ['status_demanda_id', 'i'],
        'tags' => ['tags', 's'],
        'data_contato' => ['data_contato', 's'],
    ];

    foreach ($map as $inputKey => [$column, $type]) {
        if (!array_key_exists($inputKey, $payload)) {
            continue;
        }

        $value = $payload[$inputKey];

        if (in_array($inputKey, ['diretoria', 'regional', 'nome_contato', 'subsecao_contato', 'assunto', 'descricao', 'demandas', 'tags'], true)) {
            $value = to_string_or_null($value);
            if (in_array($inputKey, ['assunto', 'descricao'], true) && $value === null) {
                json_error($inputKey . ' nao pode ser vazio.', 422);
            }
        } elseif ($inputKey === 'data_contato') {
            $value = parse_datetime_or_null($value);
        } else {
            $value = to_int_or_null($value);
            if (in_array($inputKey, ['usuario_id', 'tipo_interacao_id'], true) && ($value === null || $value <= 0)) {
                json_error('Campo invalido para ' . $inputKey, 422);
            }
        }

        $fields[] = $column . ' = ?';
        $types .= $type;
        $params[] = $value;
    }

    $hasContatos = array_key_exists('contatos', $payload);
    if (count($fields) === 0 && !$hasContatos) {
        json_error('Nenhum campo para atualizar.', 422);
    }

    $db->begin_transaction();
    try {
        if (count($fields) > 0) {
            $params[] = $id;
            $types .= 'i';
            $sql = 'UPDATE f_interacoes SET ' . implode(', ', $fields) . ' WHERE id = ?';
            db_execute($db, $sql, $types, $params);
        }

        if ($hasContatos) {
            if (!is_array($payload['contatos'])) {
                json_error('contatos deve ser um array.', 422);
            }
            replace_contatos($db, $id, $payload['contatos']);
        }

        $db->commit();

        $interacao = get_interacao($db, $id);
        $interacao['contatos'] = get_interacao_contatos($db, $id);

        json_response(['sucesso' => true, 'interacao' => $interacao]);
    } catch (Throwable $e) {
        $db->rollback();
        throw $e;
    }
}

function handle_delete(mysqli $db): void
{
    $payload = json_input();
    $id = to_int_or_null($payload['id'] ?? ($_GET['id'] ?? null));

    if ($id === null || $id <= 0) {
        json_error('ID de interacao invalido para exclusao.', 422);
    }

    $res = db_execute($db, 'DELETE FROM f_interacoes WHERE id = ?', 'i', [$id]);
    if ($res['affected_rows'] < 1) {
        json_error('Interacao nao encontrada para exclusao.', 404);
    }

    json_response(['sucesso' => true, 'id' => $id]);
}

function replace_contatos(mysqli $db, int $interacaoId, array $contatos): void
{
    db_execute($db, 'DELETE FROM f_interacoes_contatos WHERE interacao_id = ?', 'i', [$interacaoId]);

    foreach ($contatos as $c) {
        if (!is_array($c)) {
            continue;
        }

        $nome = to_string_or_null($c['nome'] ?? null);
        if ($nome === null) {
            continue;
        }

        $subsecao = to_string_or_null($c['subsecao'] ?? null);

        db_execute(
            $db,
            'INSERT INTO f_interacoes_contatos (interacao_id, nome, subsecao) VALUES (?, ?, ?)',
            'iss',
            [$interacaoId, $nome, $subsecao]
        );
    }
}

function get_interacao(mysqli $db, int $id): ?array
{
    return db_query_one(
        $db,
        '
        SELECT
            i.id,
            i.usuario_id,
            u.nome AS usuario_nome,
            i.tipo_interacao_id,
            ti.nome AS tipo_interacao,
            i.agencia_id,
            a.nome AS agencia_nome,
            a.cidade AS agencia_cidade,
            a.uf AS agencia_uf,
            i.diretoria,
            i.regional,
            i.nome_contato,
            i.subsecao_contato,
            i.assunto,
            i.descricao,
            i.demandas,
            i.area_responsavel_id,
            ar.nome AS area_responsavel,
            i.status_demanda_id,
            sd.nome AS status_demanda,
            i.tags,
            i.data_contato,
            i.criado_em,
            i.atualizado_em
        FROM f_interacoes i
        JOIN d_usuarios u ON u.id = i.usuario_id
        JOIN d_tipos_interacao ti ON ti.id = i.tipo_interacao_id
        LEFT JOIN d_agencias a ON a.id = i.agencia_id
        LEFT JOIN d_areas_responsaveis ar ON ar.id = i.area_responsavel_id
        LEFT JOIN d_status_demanda sd ON sd.id = i.status_demanda_id
        WHERE i.id = ?
        LIMIT 1
    ',
        'i',
        [$id]
    );
}

function get_interacao_contatos(mysqli $db, int $interacaoId): array
{
    return db_query_all(
        $db,
        'SELECT id, interacao_id, nome, subsecao, criado_em, atualizado_em FROM f_interacoes_contatos WHERE interacao_id = ? ORDER BY id ASC',
        'i',
        [$interacaoId]
    );
}
