﻿-- 02_seed_dashboard_visitas.sql
USE dashboard_visitas;

START TRANSACTION;

-- =========================
-- DADOS INICIAIS DE DIMENSAO
-- =========================

INSERT INTO d_usuarios (nome, slug) VALUES
  ('Ademar', 'ademar'),
  ('Aline', 'aline');

INSERT INTO d_status_demanda (nome, ordem) VALUES
  ('Em Andamento', 1),
  ('Nao Iniciado', 2),
  ('Concluido', 3),
  ('Sem Solucao', 4);

INSERT INTO d_tipos_interacao (nome) VALUES
  ('Teams'),
  ('Telefone'),
  ('WhatsApp'),
  ('Presencial'),
  ('Email');

INSERT INTO d_tipos_compromisso (nome, cor_padrao) VALUES
  ('Reuniao', '#2563eb'),
  ('Visita', '#10b981'),
  ('Ligacao', '#f59e0b'),
  ('Tarefa', '#7c3aed'),
  ('Outro', '#64748b');

INSERT INTO d_temas_visita (nome) VALUES
  ('Estrategia Comercial'),
  ('Carteira de Clientes'),
  ('Credito e Vencidos'),
  ('Produtos PJ'),
  ('Planejamento Mensal');

INSERT INTO d_areas_responsaveis (nome) VALUES
  ('Comercial'),
  ('Credito'),
  ('Operacoes'),
  ('Produtos'),
  ('Atendimento');

INSERT INTO d_agencias (nome, codigo, cidade, uf) VALUES
  ('Agencia Paulista Centro', 'SP001', 'Sao Paulo', 'SP'),
  ('Agencia Vila Mariana', 'SP014', 'Sao Paulo', 'SP'),
  ('Agencia Copacabana', 'RJ003', 'Rio de Janeiro', 'RJ'),
  ('Agencia Savassi', 'MG011', 'Belo Horizonte', 'MG'),
  ('Agencia Boa Viagem', 'PE007', 'Recife', 'PE');

-- =========================
-- IDS DE REFERENCIA
-- =========================

SET @u_ademar := (SELECT id FROM d_usuarios WHERE slug = 'ademar');
SET @u_aline  := (SELECT id FROM d_usuarios WHERE slug = 'aline');

SET @ag_sp_centro   := (SELECT id FROM d_agencias WHERE codigo = 'SP001');
SET @ag_sp_vila     := (SELECT id FROM d_agencias WHERE codigo = 'SP014');
SET @ag_rj_copa     := (SELECT id FROM d_agencias WHERE codigo = 'RJ003');
SET @ag_mg_savassi  := (SELECT id FROM d_agencias WHERE codigo = 'MG011');

SET @tema_estrategia := (SELECT id FROM d_temas_visita WHERE nome = 'Estrategia Comercial');
SET @tema_carteira   := (SELECT id FROM d_temas_visita WHERE nome = 'Carteira de Clientes');
SET @tema_credito    := (SELECT id FROM d_temas_visita WHERE nome = 'Credito e Vencidos');

SET @tipo_teams      := (SELECT id FROM d_tipos_interacao WHERE nome = 'Teams');
SET @tipo_telefone   := (SELECT id FROM d_tipos_interacao WHERE nome = 'Telefone');
SET @tipo_whatsapp   := (SELECT id FROM d_tipos_interacao WHERE nome = 'WhatsApp');

SET @area_comercial  := (SELECT id FROM d_areas_responsaveis WHERE nome = 'Comercial');
SET @area_credito    := (SELECT id FROM d_areas_responsaveis WHERE nome = 'Credito');

SET @status_andamento := (SELECT id FROM d_status_demanda WHERE nome = 'Em Andamento');
SET @status_concluido := (SELECT id FROM d_status_demanda WHERE nome = 'Concluido');
SET @status_nao_ini   := (SELECT id FROM d_status_demanda WHERE nome = 'Nao Iniciado');

SET @comp_reuniao := (SELECT id FROM d_tipos_compromisso WHERE nome = 'Reuniao');
SET @comp_visita  := (SELECT id FROM d_tipos_compromisso WHERE nome = 'Visita');
SET @comp_tarefa  := (SELECT id FROM d_tipos_compromisso WHERE nome = 'Tarefa');

-- =========================
-- FATOS DE EXEMPLO
-- =========================

INSERT INTO f_visitas (
  usuario_id, agencia_id, tema_visita_id, descricao, demandas,
  area_responsavel_id, status_demanda_id, tags, data_contato
) VALUES (
  @u_ademar, @ag_sp_centro, @tema_estrategia,
  'Reuniao presencial para alinhar metas de carteira PJ do trimestre.',
  'Revisar pipeline e priorizar clientes com potencial de cross-sell.',
  @area_comercial, @status_andamento, 'pj,estrategia,cross-sell',
  DATE_SUB(NOW(), INTERVAL 5 DAY)
);
SET @visita_1 := LAST_INSERT_ID();

INSERT INTO f_visitas_participantes (visita_id, nome, subsecao) VALUES
  (@visita_1, 'Gerente Joao Silva', 'Gerente Agencia'),
  (@visita_1, 'Ana Costa', 'Relacionamento');

INSERT INTO f_visitas (
  usuario_id, agencia_id, tema_visita_id, descricao, demandas,
  area_responsavel_id, status_demanda_id, tags, data_contato
) VALUES (
  @u_aline, @ag_sp_vila, @tema_carteira,
  'Visita de acompanhamento para revisar carteira ativa e inativa.',
  'Separar lista de clientes sem contato ha mais de 60 dias.',
  @area_comercial, @status_nao_ini, 'carteira,priorizacao',
  DATE_SUB(NOW(), INTERVAL 3 DAY)
);
SET @visita_2 := LAST_INSERT_ID();

INSERT INTO f_visitas_participantes (visita_id, nome, subsecao) VALUES
  (@visita_2, 'Carlos Lima', 'Assistente');

INSERT INTO f_visitas (
  usuario_id, agencia_id, tema_visita_id, descricao, demandas,
  area_responsavel_id, status_demanda_id, tags, data_contato
) VALUES (
  @u_ademar, @ag_rj_copa, @tema_credito,
  'Discussao sobre esteira de credito e gestao de vencidos.',
  'Consolidar relacao de clientes com atraso acima de 30 dias.',
  @area_credito, @status_concluido, 'credito,vencidos,acao',
  DATE_SUB(NOW(), INTERVAL 1 DAY)
);
SET @visita_3 := LAST_INSERT_ID();

INSERT INTO f_interacoes (
  usuario_id, tipo_interacao_id, agencia_id, diretoria, regional,
  nome_contato, subsecao_contato, assunto, descricao, demandas,
  area_responsavel_id, status_demanda_id, tags, data_contato
) VALUES
(
  @u_ademar, @tipo_teams, @ag_sp_centro, 'Diretoria Comercial', 'Regional SP',
  'Mariana Freitas', 'Diretor', 'Produtividade',
  'Alinhamento semanal de indicadores de produtividade da equipe.',
  'Atualizar painel com metas semanais por gerente.',
  @area_comercial, @status_andamento, 'indicadores,produtividade',
  DATE_SUB(NOW(), INTERVAL 4 DAY)
),
(
  @u_aline, @tipo_telefone, @ag_mg_savassi, 'Diretoria Credito', 'Regional MG',
  'Pedro Nogueira', 'Superintendente', 'Gestao de Vencidos',
  'Contato para validar estrategia de recuperacao de carteira vencida.',
  'Definir criterio unico para priorizacao de cobranca.',
  @area_credito, @status_andamento, 'cobranca,carteira',
  DATE_SUB(NOW(), INTERVAL 2 DAY)
),
(
  @u_aline, @tipo_whatsapp, @ag_sp_vila, 'Diretoria Comercial', 'Regional SP',
  'Renata Souza', 'Gerente de Relacionamento', 'Base de Clientes',
  'Troca rapida sobre lista de oportunidades de novos clientes PJ.',
  'Enviar relacao de top 20 empresas sem oferta ativa.',
  @area_comercial, @status_nao_ini, 'oportunidade,base',
  DATE_SUB(NOW(), INTERVAL 1 DAY)
);

SET @interacao_1 := (SELECT id FROM f_interacoes WHERE nome_contato = 'Mariana Freitas' ORDER BY id DESC LIMIT 1);
SET @interacao_2 := (SELECT id FROM f_interacoes WHERE nome_contato = 'Pedro Nogueira' ORDER BY id DESC LIMIT 1);

INSERT INTO f_interacoes_contatos (interacao_id, nome, subsecao) VALUES
  (@interacao_1, 'Mariana Freitas', 'Diretor'),
  (@interacao_1, 'Felipe Gomes', 'Team Leader'),
  (@interacao_2, 'Pedro Nogueira', 'Superintendente');

INSERT INTO f_compromissos (
  usuario_id, tipo_compromisso_id, titulo, descricao, data_inicio, data_fim, cor
) VALUES
(
  @u_ademar, @comp_reuniao, 'Rito Comercial Semanal',
  'Revisao de pipeline e distribuicao de metas.',
  DATE_ADD(CURDATE(), INTERVAL 9 HOUR),
  DATE_ADD(CURDATE(), INTERVAL 10 HOUR),
  '#2563eb'
),
(
  @u_aline, @comp_visita, 'Visita Agencia Vila Mariana',
  'Acompanhamento de carteira PJ e novas ofertas.',
  DATE_ADD(CURDATE(), INTERVAL 14 HOUR),
  DATE_ADD(CURDATE(), INTERVAL 16 HOUR),
  '#10b981'
),
(
  @u_aline, @comp_tarefa, 'Consolidar pauta mensal',
  'Montar pauta de prioridades para a proxima reuniao regional.',
  DATE_ADD(DATE_ADD(CURDATE(), INTERVAL 1 DAY), INTERVAL 8 HOUR),
  DATE_ADD(DATE_ADD(CURDATE(), INTERVAL 1 DAY), INTERVAL 9 HOUR),
  '#7c3aed'
);

COMMIT;
