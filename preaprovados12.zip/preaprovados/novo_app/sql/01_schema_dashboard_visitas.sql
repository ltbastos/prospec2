﻿-- 01_schema_dashboard_visitas.sql
-- Executar no MySQL/MariaDB (XAMPP)

DROP DATABASE IF EXISTS dashboard_visitas;
CREATE DATABASE dashboard_visitas CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dashboard_visitas;

-- =========================
-- DIMENSOES
-- =========================

CREATE TABLE d_usuarios (
  id INT NOT NULL AUTO_INCREMENT,
  nome VARCHAR(120) NOT NULL,
  slug VARCHAR(60) NOT NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_usuarios_nome (nome),
  UNIQUE KEY uk_usuarios_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE d_agencias (
  id INT NOT NULL AUTO_INCREMENT,
  nome VARCHAR(180) NOT NULL,
  codigo VARCHAR(30) DEFAULT NULL,
  cidade VARCHAR(120) DEFAULT NULL,
  uf CHAR(2) DEFAULT NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_agencias_nome_codigo (nome, codigo),
  KEY idx_agencias_uf_cidade (uf, cidade)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE d_temas_visita (
  id INT NOT NULL AUTO_INCREMENT,
  nome VARCHAR(180) NOT NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_temas_visita_nome (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE d_tipos_interacao (
  id INT NOT NULL AUTO_INCREMENT,
  nome VARCHAR(120) NOT NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_tipos_interacao_nome (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE d_areas_responsaveis (
  id INT NOT NULL AUTO_INCREMENT,
  nome VARCHAR(150) NOT NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_areas_responsaveis_nome (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE d_status_demanda (
  id INT NOT NULL AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  ordem INT NOT NULL DEFAULT 0,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_status_demanda_nome (nome),
  KEY idx_status_demanda_ordem (ordem)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE d_tipos_compromisso (
  id INT NOT NULL AUTO_INCREMENT,
  nome VARCHAR(80) NOT NULL,
  cor_padrao VARCHAR(20) NOT NULL DEFAULT '#2563eb',
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_tipos_compromisso_nome (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================
-- FATOS
-- =========================

CREATE TABLE f_visitas (
  id BIGINT NOT NULL AUTO_INCREMENT,
  usuario_id INT NOT NULL,
  agencia_id INT NOT NULL,
  tema_visita_id INT NOT NULL,
  descricao TEXT NOT NULL,
  demandas TEXT DEFAULT NULL,
  area_responsavel_id INT DEFAULT NULL,
  status_demanda_id INT DEFAULT NULL,
  tags VARCHAR(500) DEFAULT NULL,
  data_contato DATETIME DEFAULT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_visitas_usuario_data (usuario_id, data_contato),
  KEY idx_visitas_agencia (agencia_id),
  KEY idx_visitas_tema (tema_visita_id),
  KEY idx_visitas_status (status_demanda_id),
  CONSTRAINT fk_visitas_usuario FOREIGN KEY (usuario_id) REFERENCES d_usuarios (id),
  CONSTRAINT fk_visitas_agencia FOREIGN KEY (agencia_id) REFERENCES d_agencias (id),
  CONSTRAINT fk_visitas_tema FOREIGN KEY (tema_visita_id) REFERENCES d_temas_visita (id),
  CONSTRAINT fk_visitas_area FOREIGN KEY (area_responsavel_id) REFERENCES d_areas_responsaveis (id),
  CONSTRAINT fk_visitas_status FOREIGN KEY (status_demanda_id) REFERENCES d_status_demanda (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE f_visitas_participantes (
  id BIGINT NOT NULL AUTO_INCREMENT,
  visita_id BIGINT NOT NULL,
  nome VARCHAR(150) NOT NULL,
  subsecao VARCHAR(120) DEFAULT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_visita_participantes_visita (visita_id),
  CONSTRAINT fk_visita_participantes_visita FOREIGN KEY (visita_id) REFERENCES f_visitas (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE f_interacoes (
  id BIGINT NOT NULL AUTO_INCREMENT,
  usuario_id INT NOT NULL,
  tipo_interacao_id INT NOT NULL,
  agencia_id INT DEFAULT NULL,
  diretoria VARCHAR(180) DEFAULT NULL,
  regional VARCHAR(180) DEFAULT NULL,
  nome_contato VARCHAR(150) DEFAULT NULL,
  subsecao_contato VARCHAR(120) DEFAULT NULL,
  assunto VARCHAR(180) NOT NULL,
  descricao TEXT NOT NULL,
  demandas TEXT DEFAULT NULL,
  area_responsavel_id INT DEFAULT NULL,
  status_demanda_id INT DEFAULT NULL,
  tags VARCHAR(500) DEFAULT NULL,
  data_contato DATETIME DEFAULT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_interacoes_usuario_data (usuario_id, data_contato),
  KEY idx_interacoes_tipo (tipo_interacao_id),
  KEY idx_interacoes_agencia (agencia_id),
  KEY idx_interacoes_status (status_demanda_id),
  CONSTRAINT fk_interacoes_usuario FOREIGN KEY (usuario_id) REFERENCES d_usuarios (id),
  CONSTRAINT fk_interacoes_tipo FOREIGN KEY (tipo_interacao_id) REFERENCES d_tipos_interacao (id),
  CONSTRAINT fk_interacoes_agencia FOREIGN KEY (agencia_id) REFERENCES d_agencias (id),
  CONSTRAINT fk_interacoes_area FOREIGN KEY (area_responsavel_id) REFERENCES d_areas_responsaveis (id),
  CONSTRAINT fk_interacoes_status FOREIGN KEY (status_demanda_id) REFERENCES d_status_demanda (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE f_interacoes_contatos (
  id BIGINT NOT NULL AUTO_INCREMENT,
  interacao_id BIGINT NOT NULL,
  nome VARCHAR(150) NOT NULL,
  subsecao VARCHAR(120) DEFAULT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_interacao_contatos_interacao (interacao_id),
  CONSTRAINT fk_interacao_contatos_interacao FOREIGN KEY (interacao_id) REFERENCES f_interacoes (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE f_compromissos (
  id BIGINT NOT NULL AUTO_INCREMENT,
  usuario_id INT NOT NULL,
  tipo_compromisso_id INT NOT NULL,
  titulo VARCHAR(255) NOT NULL,
  descricao TEXT DEFAULT NULL,
  data_inicio DATETIME NOT NULL,
  data_fim DATETIME NOT NULL,
  cor VARCHAR(20) DEFAULT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_compromissos_usuario_inicio (usuario_id, data_inicio),
  KEY idx_compromissos_tipo (tipo_compromisso_id),
  CONSTRAINT fk_compromissos_usuario FOREIGN KEY (usuario_id) REFERENCES d_usuarios (id),
  CONSTRAINT fk_compromissos_tipo FOREIGN KEY (tipo_compromisso_id) REFERENCES d_tipos_compromisso (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
