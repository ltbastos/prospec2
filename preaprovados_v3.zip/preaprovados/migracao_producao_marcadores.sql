-- Migracao para producao
-- Objetivo:
-- 1. Criar d_marcadores
-- 2. Criar f_marcadores
-- 3. Inserir marcadores padrao
-- 4. Migrar dados antigos de f_comentarios para f_marcadores
-- Observacao:
-- - Este script NAO apaga f_comentarios
-- - Pode ser executado com a tabela antiga preservada

CREATE TABLE IF NOT EXISTS d_marcadores (
  id_marcador INT NOT NULL AUTO_INCREMENT,
  marcador VARCHAR(150) NOT NULL,
  PRIMARY KEY (id_marcador),
  UNIQUE KEY uk_d_marcadores_marcador (marcador)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO d_marcadores (id_marcador, marcador) VALUES
  (1, 'Telefone errado'),
  (2, 'Prospectado'),
  (3, 'Rejeitou o produto'),
  (4, 'Tentar depois')
ON DUPLICATE KEY UPDATE
  marcador = VALUES(marcador);

CREATE TABLE IF NOT EXISTS f_marcadores (
  id BIGINT NOT NULL AUTO_INCREMENT,
  id_registro BIGINT NOT NULL,
  cnpj CHAR(14) NOT NULL,
  id_marcador INT DEFAULT NULL,
  nome VARCHAR(200) NOT NULL,
  juncao VARCHAR(255) DEFAULT NULL,
  marcador VARCHAR(150) NOT NULL,
  data DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_f_marcadores_cnpj_data (cnpj, data),
  KEY idx_f_marcadores_registro (id_registro),
  KEY idx_f_marcadores_id_marcador (id_marcador),
  CONSTRAINT fk_f_marcadores_empresa
    FOREIGN KEY (cnpj) REFERENCES d_empresas (cnpj),
  CONSTRAINT fk_f_marcadores_dimensao
    FOREIGN KEY (id_marcador) REFERENCES d_marcadores (id_marcador)
    ON DELETE SET NULL
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Migracao de historico antigo para o novo modelo
-- Cada comentario antigo vira um grupo identificado por id_registro = id antigo
-- Cada marcador marcado vira uma linha em f_marcadores
-- Esta etapa so roda se a tabela f_comentarios existir

SET @tem_f_comentarios = (
  SELECT COUNT(*)
  FROM information_schema.tables
  WHERE table_schema = DATABASE()
    AND table_name = 'f_comentarios'
);

SET @sql_migracao_1 = IF(
  @tem_f_comentarios > 0,
  "
  INSERT INTO f_marcadores (id_registro, cnpj, id_marcador, nome, juncao, marcador, data)
  SELECT
    c.id,
    c.cnpj,
    1,
    c.nome,
    c.juncao,
    'Telefone errado',
    c.data
  FROM f_comentarios c
  WHERE c.telefone_errado = 1
    AND NOT EXISTS (
      SELECT 1
      FROM f_marcadores fm
      WHERE fm.id_registro = c.id
        AND fm.cnpj = c.cnpj
        AND fm.id_marcador = 1
    )
  ",
  "SELECT 'f_comentarios nao existe: migracao legada ignorada' AS info"
);
PREPARE stmt_migracao_1 FROM @sql_migracao_1;
EXECUTE stmt_migracao_1;
DEALLOCATE PREPARE stmt_migracao_1;

SET @sql_migracao_2 = IF(
  @tem_f_comentarios > 0,
  "
  INSERT INTO f_marcadores (id_registro, cnpj, id_marcador, nome, juncao, marcador, data)
  SELECT
    c.id,
    c.cnpj,
    2,
    c.nome,
    c.juncao,
    'Prospectado',
    c.data
  FROM f_comentarios c
  WHERE c.prospectado = 1
    AND NOT EXISTS (
      SELECT 1
      FROM f_marcadores fm
      WHERE fm.id_registro = c.id
        AND fm.cnpj = c.cnpj
        AND fm.id_marcador = 2
    )
  ",
  "SELECT 'f_comentarios nao existe: migracao legada ignorada' AS info"
);
PREPARE stmt_migracao_2 FROM @sql_migracao_2;
EXECUTE stmt_migracao_2;
DEALLOCATE PREPARE stmt_migracao_2;

SET @sql_migracao_3 = IF(
  @tem_f_comentarios > 0,
  "
  INSERT INTO f_marcadores (id_registro, cnpj, id_marcador, nome, juncao, marcador, data)
  SELECT
    c.id,
    c.cnpj,
    3,
    c.nome,
    c.juncao,
    'Rejeitou o produto',
    c.data
  FROM f_comentarios c
  WHERE c.rejeitou_produto = 1
    AND NOT EXISTS (
      SELECT 1
      FROM f_marcadores fm
      WHERE fm.id_registro = c.id
        AND fm.cnpj = c.cnpj
        AND fm.id_marcador = 3
    )
  ",
  "SELECT 'f_comentarios nao existe: migracao legada ignorada' AS info"
);
PREPARE stmt_migracao_3 FROM @sql_migracao_3;
EXECUTE stmt_migracao_3;
DEALLOCATE PREPARE stmt_migracao_3;

SET @sql_migracao_4 = IF(
  @tem_f_comentarios > 0,
  "
  INSERT INTO f_marcadores (id_registro, cnpj, id_marcador, nome, juncao, marcador, data)
  SELECT
    c.id,
    c.cnpj,
    4,
    c.nome,
    c.juncao,
    'Tentar depois',
    c.data
  FROM f_comentarios c
  WHERE c.tentar_depois = 1
    AND NOT EXISTS (
      SELECT 1
      FROM f_marcadores fm
      WHERE fm.id_registro = c.id
        AND fm.cnpj = c.cnpj
        AND fm.id_marcador = 4
    )
  ",
  "SELECT 'f_comentarios nao existe: migracao legada ignorada' AS info"
);
PREPARE stmt_migracao_4 FROM @sql_migracao_4;
EXECUTE stmt_migracao_4;
DEALLOCATE PREPARE stmt_migracao_4;

-- Conferencia opcional apos a migracao
-- SELECT * FROM d_marcadores ORDER BY id_marcador;
-- SELECT * FROM f_marcadores ORDER BY data DESC, id_registro DESC, id;
