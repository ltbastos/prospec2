<?php
/* ============================================================================
   Roda os cenários contra os fluxos simulados e mostra o que cada um decidiu.

     C:\xampp\php\php.exe simulador\rodar.php
     C:\xampp\php\php.exe simulador\rodar.php 5      (só o cenário 5)

   Cada cenário termina com uma verificação: o que era esperado x o que
   aconteceu. Se algo divergir, aparece FALHOU.
   ========================================================================== */

require_once __DIR__ . '/motor.php';

$HOJE = '2026-08-20';

/* ------------------------------------------------------------ o cenário --- */
function estadoInicial($hoje) {
    return array(
        'hoje'   => $hoje,
        'matriz' => json_decode(file_get_contents(__DIR__ . '/../mock/matriz.json'), true),
        'base'   => array(),
        'solicitacoes' => array()
    );
}

function solicitacao($p) {
    $padrao = array(
        'Protocolo' => 'AC-20260820-000001',
        'Destino' => 'eu',
        'SolicitanteEmail' => '', 'SolicitanteNome' => '',
        'Nome' => '', 'Email' => '',
        'Funcional' => '', 'Funcional_L' => '',
        'Cargo' => '', 'CargoDiretorio' => '',
        'Juncao' => '', 'Juncao_Nome' => '', 'Posto' => '', 'Posto_Nome' => '',
        'PerfilSolicitado' => '', 'ValidoAte' => '',
        'EditouCampoDeRegra' => false,
        'Status' => 'Novo', 'Aprovador' => '', 'AprovadorEmail' => '',
        'MotivoReprova' => '', 'DataDecisao' => ''
    );
    $s = array_merge($padrao, $p);
    if ($s['SolicitanteEmail'] === '') { $s['SolicitanteEmail'] = $s['Email']; }
    if ($s['CargoDiretorio'] === '')   { $s['CargoDiretorio'] = $s['Cargo']; }
    if ($s['Funcional'] === '' && $s['Funcional_L'] !== '') {
        $s['Funcional'] = funcionalParaNumero($s['Funcional_L']);
    }
    if ($s['Funcional_L'] === '' && $s['Funcional'] !== '') {
        $s['Funcional_L'] = funcionalParaLetra($s['Funcional']);
    }
    return $s;
}

function enviar(&$estado, $sol) {
    $estado['solicitacoes'][] = $sol;
    return $sol;
}

/* --------------------------------------------------------------- saída ---- */
$FALHAS = 0;

function titulo($n, $texto) {
    echo "\n";
    echo "════ CENARIO $n · $texto\n";
}

function mostrarTrace() {
    foreach (trace() as $t) {
        printf("   %-42s %s\n", $t['acao'], $t['detalhe']);
    }
    limparTrace();
}

function conferir($rotulo, $esperado, $obtido) {
    global $FALHAS;
    $ok = ($esperado === $obtido);
    if (!$ok) { $FALHAS++; }
    printf("   %s %-34s esperado=%-22s obtido=%s\n",
           $ok ? '  ok  ' : 'FALHOU', $rotulo,
           var_export($esperado, true), var_export($obtido, true));
}

function linhaDe($estado, $funcional) {
    $chave = chaveDe(array('funcional' => $funcional));
    foreach ($estado['base'] as $l) { if (chaveDe($l) === $chave) { return $l; } }
    return null;
}

/* =========================================================== os cenários == */
$so = isset($argv[1]) ? (int) $argv[1] : 0;
$rodar = function ($n) use ($so) { return $so === 0 || $so === $n; };

echo "\nSimulador dos fluxos do Portal de Acessos · hoje = $HOJE\n";

/* --- 1 ------------------------------------------------------------------- */
if ($rodar(1)) {
    titulo(1, 'Perfil igual ao do cargo, para si mesmo');
    $e = estadoInicial($HOJE);
    $s = enviar($e, solicitacao(array(
        'Protocolo' => 'AC-1', 'Nome' => 'Luan Bastos', 'Email' => 'luan@x.com.br',
        'Funcional_L' => 'I437643', 'Cargo' => 'Gerente de Contas',
        'Juncao' => '3311', 'Juncao_Nome' => 'Centro Sul', 'Posto' => '1234',
        'PerfilSolicitado' => 'GC')));
    $r = fluxoTriagem($e, $s);
    mostrarTrace();
    conferir('resultado', 'Aprovado', $r);
    conferir('linhas na base', 1, count($e['base']));
    conferir('nivel gravado', 'GC', linhaDe($e, 'I437643')['nivel']);
    conferir('aprovador', '', linhaDe($e, 'I437643')['aprovador']);
}

/* --- 2 ------------------------------------------------------------------- */
if ($rodar(2)) {
    titulo(2, 'Perfil acima do cargo, aprovado no Teams');
    $e = estadoInicial($HOJE);
    $s = enviar($e, solicitacao(array(
        'Protocolo' => 'AC-2', 'Nome' => 'Luan Bastos', 'Email' => 'luan@x.com.br',
        'Funcional_L' => 'I437643', 'Cargo' => 'Gerente de Contas',
        'Juncao' => '3311', 'Posto' => '1234',
        'PerfilSolicitado' => 'AG', 'ValidoAte' => '2026-11-30')));
    $r = fluxoTriagem($e, $s, array('decisao' => 'aprovar',
        'nome' => 'Camila Duarte', 'email' => 'camila@x.com.br', 'motivo' => ''));
    mostrarTrace();
    conferir('resultado', 'Aprovado', $r);
    conferir('perfil gravado', 'AG', linhaDe($e, 'I437643')['nivel']);
    conferir('perfil base guardado', 'GC', linhaDe($e, 'I437643')['nivelBase']);
    conferir('valido ate', '2026-11-30', linhaDe($e, 'I437643')['validoAte']);
    conferir('aprovador', 'Camila Duarte', linhaDe($e, 'I437643')['aprovador']);
}

/* --- 3 ------------------------------------------------------------------- */
if ($rodar(3)) {
    titulo(3, 'Perfil acima do cargo, REPROVADO no Teams');
    $e = estadoInicial($HOJE);
    $s = enviar($e, solicitacao(array(
        'Protocolo' => 'AC-3', 'Nome' => 'Luan Bastos', 'Email' => 'luan@x.com.br',
        'Funcional_L' => 'I437643', 'Cargo' => 'Gerente de Contas',
        'PerfilSolicitado' => 'DP', 'ValidoAte' => '2026-11-30')));
    $r = fluxoTriagem($e, $s, array('decisao' => 'reprovar',
        'nome' => 'Camila Duarte', 'email' => 'camila@x.com.br',
        'motivo' => 'Alcance nao se justifica para a funcao.'));
    mostrarTrace();
    conferir('resultado', 'Reprovado', $r);
    conferir('base intocada', 0, count($e['base']));
    conferir('motivo registrado', 'Alcance nao se justifica para a funcao.',
             $e['solicitacoes'][0]['MotivoReprova']);
}

/* --- 4 ------------------------------------------------------------------- */
if ($rodar(4)) {
    titulo(4, 'Perfil de apoio · escolhe APOIO_AG, base recebe AG');
    $e = estadoInicial($HOJE);
    $s = enviar($e, solicitacao(array(
        'Protocolo' => 'AC-4', 'Nome' => 'Luan Bastos', 'Email' => 'luan@x.com.br',
        'Funcional_L' => 'I437643', 'Cargo' => 'Gerente de Contas',
        'PerfilSolicitado' => 'APOIO_AG', 'ValidoAte' => '2026-10-31')));
    $r = fluxoTriagem($e, $s, array('decisao' => 'aprovar',
        'nome' => 'Paulo Nogueira', 'email' => 'paulo@x.com.br', 'motivo' => ''));
    mostrarTrace();
    conferir('resultado', 'Aprovado', $r);
    conferir('perfil na base (RLS)', 'AG', linhaDe($e, 'I437643')['nivel']);
    conferir('solicitacao guarda o escolhido', 'APOIO_AG',
             $e['solicitacoes'][0]['PerfilSolicitado']);
}

/* --- 5 ------------------------------------------------------------------- */
if ($rodar(5)) {
    titulo(5, 'Mesma pessoa duas vezes, formas diferentes da funcional');
    $e = estadoInicial($HOJE);

    $s1 = enviar($e, solicitacao(array(
        'Protocolo' => 'AC-5a', 'Nome' => 'Luan Bastos', 'Email' => 'luan@x.com.br',
        'Funcional_L' => 'I437643', 'Cargo' => 'Gerente de Contas',
        'PerfilSolicitado' => 'GC')));
    fluxoTriagem($e, $s1);
    mostrarTrace();

    echo "   --- segunda solicitacao, agora com a funcional NUMERICA ---\n";
    $s2 = enviar($e, solicitacao(array(
        'Protocolo' => 'AC-5b', 'Nome' => 'Luan Bastos', 'Email' => 'luan@x.com.br',
        'Funcional' => '9437643', 'Cargo' => 'Gerente de Contas',
        'PerfilSolicitado' => 'AG', 'ValidoAte' => '2026-12-15')));
    fluxoTriagem($e, $s2, array('decisao' => 'aprovar',
        'nome' => 'Camila Duarte', 'email' => 'camila@x.com.br', 'motivo' => ''));
    mostrarTrace();

    conferir('UMA linha na base', 1, count($e['base']));
    conferir('perfil atualizado', 'AG', linhaDe($e, '9437643')['nivel']);
    conferir('perfil base preservado', 'GC', linhaDe($e, '9437643')['nivelBase']);
}

/* --- 6 ------------------------------------------------------------------- */
if ($rodar(6)) {
    titulo(6, 'Perfil certo, mas com campo de regra editado');
    $e = estadoInicial($HOJE);
    $s = enviar($e, solicitacao(array(
        'Protocolo' => 'AC-6', 'Nome' => 'Luan Bastos', 'Email' => 'luan@x.com.br',
        'Funcional_L' => 'I437643',
        'Cargo' => 'Gerente de Agencia', 'CargoDiretorio' => 'Gerente de Contas',
        'PerfilSolicitado' => 'GC', 'EditouCampoDeRegra' => true)));
    $r = fluxoTriagem($e, $s, array('decisao' => 'aprovar',
        'nome' => 'Camila Duarte', 'email' => 'camila@x.com.br', 'motivo' => ''));
    mostrarTrace();
    conferir('nao aprovou sozinho', 'Aprovado', $r);
    conferir('origem manual', 'manual', linhaDe($e, 'I437643')['origem']);
}

/* --- 7 ------------------------------------------------------------------- */
if ($rodar(7)) {
    titulo(7, 'Pedido para outra pessoa');
    $e = estadoInicial($HOJE);
    $s = enviar($e, solicitacao(array(
        'Protocolo' => 'AC-7', 'Destino' => 'outro',
        'SolicitanteEmail' => 'luan@x.com.br',
        'Nome' => 'Ana Ribeiro', 'Email' => 'ana@x.com.br',
        'Funcional_L' => 'B903117', 'Cargo' => 'Assistente', 'CargoDiretorio' => '',
        'PerfilSolicitado' => 'AS')));
    $r = fluxoTriagem($e, $s, array('decisao' => 'aprovar',
        'nome' => 'Paulo Nogueira', 'email' => 'paulo@x.com.br', 'motivo' => ''));
    mostrarTrace();
    conferir('resultado', 'Aprovado', $r);
    conferir('gravou para a Ana', 'ana@x.com.br', linhaDe($e, 'B903117')['email']);
}

/* --- 8 ------------------------------------------------------------------- */
if ($rodar(8)) {
    titulo(8, 'Ninguem decidiu ainda no Teams');
    $e = estadoInicial($HOJE);
    $s = enviar($e, solicitacao(array(
        'Protocolo' => 'AC-8', 'Nome' => 'Luan Bastos', 'Email' => 'luan@x.com.br',
        'Funcional_L' => 'I437643', 'Cargo' => 'Gerente de Contas',
        'PerfilSolicitado' => 'AG', 'ValidoAte' => '2026-11-30')));
    $r = fluxoTriagem($e, $s, null);
    mostrarTrace();
    conferir('fica pendente', 'Pendente', $r);
    conferir('base intocada', 0, count($e['base']));
    conferir('solicitacao segue Novo', 'Novo', $e['solicitacoes'][0]['Status']);
}

/* --- 9 ------------------------------------------------------------------- */
if ($rodar(9)) {
    titulo(9, 'Expiracao · perfil elevado vencido volta ao perfil base');
    $e = estadoInicial($HOJE);

    $s = enviar($e, solicitacao(array(
        'Protocolo' => 'AC-9', 'Nome' => 'Bruno Carvalho', 'Email' => 'bruno@x.com.br',
        'Funcional_L' => 'E552210', 'Cargo' => 'Gerente de Contas',
        'PerfilSolicitado' => 'AG', 'ValidoAte' => '2026-08-10')));
    fluxoTriagem($e, $s, array('decisao' => 'aprovar',
        'nome' => 'Camila Duarte', 'email' => 'camila@x.com.br', 'motivo' => ''));
    limparTrace();

    echo "   (linha criada com AG valido ate 2026-08-10; hoje e $HOJE)\n";
    $n = fluxoExpiracao($e);
    mostrarTrace();

    conferir('expirou 1', 1, $n);
    conferir('voltou para GC', 'GC', linhaDe($e, 'E552210')['nivel']);
    conferir('prazo limpo', '', linhaDe($e, 'E552210')['validoAte']);
    conferir('continua ativo', 'Ativo', linhaDe($e, 'E552210')['status']);
}

/* --- 10 ------------------------------------------------------------------ */
if ($rodar(10)) {
    titulo(10, 'Expiracao nao mexe em perfil permanente');
    $e = estadoInicial($HOJE);
    $s = enviar($e, solicitacao(array(
        'Protocolo' => 'AC-10', 'Nome' => 'Luan Bastos', 'Email' => 'luan@x.com.br',
        'Funcional_L' => 'I437643', 'Cargo' => 'Gerente de Contas',
        'PerfilSolicitado' => 'GC')));
    fluxoTriagem($e, $s);
    limparTrace();

    $n = fluxoExpiracao($e);
    mostrarTrace();
    conferir('nada expirou', 0, $n);
    conferir('perfil intacto', 'GC', linhaDe($e, 'I437643')['nivel']);
}

/* ------------------------------------------------------------- resultado -- */
echo "\n";
echo "─────────────────────────────────────────────────────────────\n";
if ($FALHAS === 0) {
    echo "  Todos os cenarios passaram.\n";
} else {
    echo "  $FALHAS verificacao(oes) FALHOU.\n";
}
echo "─────────────────────────────────────────────────────────────\n\n";
exit($FALHAS === 0 ? 0 : 1);
