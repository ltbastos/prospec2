<?php
/* ============================================================================
   Simulador dos fluxos do Power Automate.

   Cada função aqui é um fluxo, e cada passo tem o MESMO NOME da ação que vai
   existir no Power Automate. O objetivo é validar a lógica antes de montar
   qualquer coisa no tenant: condições, recálculo da regra, gravação sem
   duplicar, expiração.

   O que ISTO valida:
     · as decisões (automática x manual, aprovar x reprovar)
     · o recálculo da regra no servidor
     · uma linha por pessoa, mesmo com a funcional em formas diferentes
     · o retorno ao perfil base quando o prazo vence
     · quais avisos saem em cada caminho

   O que NÃO valida, e só aparece no tenant:
     · o cartão do Teams renderizando
     · o comportamento dos conectores e a latência
     · permissões e licenças

   Compativel com PHP 5.6+.
   ========================================================================== */

require_once __DIR__ . '/../api/comum.php';

/* --------------------------------------------------------------- registro -- */
$GLOBALS['TRACE'] = array();

function passo($acao, $detalhe = '') {
    $GLOBALS['TRACE'][] = array('acao' => $acao, 'detalhe' => $detalhe);
}

function limparTrace() { $GLOBALS['TRACE'] = array(); }

function trace() { return $GLOBALS['TRACE']; }

/* ------------------------------------------------------------ o catalogo -- */
function catalogoPerfis() {
    static $c = null;
    if ($c === null) {
        $c = array();
        foreach (json_decode(file_get_contents(__DIR__ . '/../perfis.json'), true) as $p) {
            $c[$p['codigo']] = $p;
        }
    }
    return $c;
}

function rlsDe($codigo) {
    $c = catalogoPerfis();
    if (!isset($c[$codigo])) { return $codigo; }
    return isset($c[$codigo]['rls']) ? $c[$codigo]['rls'] : $codigo;
}

function ehApoio($codigo) {
    $c = catalogoPerfis();
    return isset($c[$codigo]['exigePrazo']) && $c[$codigo]['exigePrazo'] === true;
}

/* ===========================================================================
   FLUXO 1 · Acessos - Triagem
   Gatilho: quando um item é criado em Solicitacoes.
   =========================================================================== */
function fluxoTriagem(&$estado, $solicitacao, $decisaoTeams = null) {

    passo('Gatilho: quando um item e criado',
          'protocolo ' . $solicitacao['Protocolo'] . ' · ' . $solicitacao['Nome']);

    /* --- 1 · obterMatriz -------------------------------------------------- */
    /* SharePoint · Obter itens em Matriz_Cargo_Nivel
       Filtro: Title eq '<CargoDiretorio>'                                    */
    $cargo = $solicitacao['CargoDiretorio'];
    $achados = array();
    foreach ($estado['matriz'] as $linha) {
        if (isset($linha['ativo']) && $linha['ativo'] === false) { continue; }
        if (normalizar($linha['cargo']) === normalizar($cargo)) { $achados[] = $linha; }
    }
    passo('obterMatriz', $cargo === '' ? '(cargo vazio)' :
          "Title eq '$cargo' -> " . count($achados) . ' item(ns)');

    /* --- 2 · previsto ----------------------------------------------------- */
    $previsto = count($achados) ? $achados[0]['perfil'] : '';
    passo('previsto', $previsto === '' ? '(vazio)' : $previsto);

    /* --- 3 · tipoFinal ---------------------------------------------------- */
    /* Automática só quando as quatro valem: para si mesmo, perfil previsto
       encontrado, perfil pedido igual ao previsto, e nenhum campo de regra
       editado. Perfil de apoio nunca aprova sozinho.                        */
    $pedido    = $solicitacao['PerfilSolicitado'];
    $paraSi    = $solicitacao['Destino'] === 'eu';
    $editou    = $solicitacao['EditouCampoDeRegra'] === true;
    $apoio     = ehApoio($pedido);

    $automatica = $paraSi && !$apoio && !$editou
                  && $previsto !== '' && $pedido === $previsto;
    $tipoFinal  = $automatica ? 'automatica' : 'manual';

    $porque = array();
    if (!$paraSi)              { $porque[] = 'e para outra pessoa'; }
    if ($apoio)                { $porque[] = 'e perfil de apoio'; }
    if ($editou)               { $porque[] = 'editou campo de regra'; }
    if ($previsto === '')      { $porque[] = 'cargo fora do de-para'; }
    elseif ($pedido !== $previsto) { $porque[] = "pediu $pedido, previsto $previsto"; }

    passo('tipoFinal', $tipoFinal . (count($porque) ? '  (' . implode('; ', $porque) . ')' : ''));

    /* --- 4 · Condição ----------------------------------------------------- */
    if ($tipoFinal === 'automatica') {
        passo('Condicao: tipoFinal e igual a automatica', 'SIM -> ramo automatico');
        gravarNaBase($estado, $solicitacao, $previsto, 'automatica', 'sistema', 'sistema');
        fecharSolicitacao($estado, $solicitacao, 'Aprovado', 'sistema', 'sistema', '');
        avisar($solicitacao, 'liberado', '');
        return 'Aprovado';
    }

    passo('Condicao: tipoFinal e igual a automatica', 'NAO -> ramo manual');

    /* --- cardAprovacao ---------------------------------------------------- */
    /* Teams · Postar cartao adaptavel num canal e aguardar uma resposta.
       No simulador a decisão chega pronta, porque é o humano que decide.    */
    if ($decisaoTeams === null) {
        passo('cardAprovacao', 'aguardando decisao no canal do Teams (fluxo pausado)');
        fecharSolicitacao($estado, $solicitacao, 'Novo', '', '', '');
        return 'Pendente';
    }

    passo('cardAprovacao',
          $decisaoTeams['decisao'] . ' por ' . $decisaoTeams['nome'] .
          ($decisaoTeams['motivo'] !== '' ? ' · "' . $decisaoTeams['motivo'] . '"' : ''));

    if ($decisaoTeams['decisao'] === 'aprovar') {
        passo('Condicao: decisao e igual a aprovar', 'SIM');
        gravarNaBase($estado, $solicitacao, $previsto, 'manual',
                     $decisaoTeams['nome'], $decisaoTeams['email']);
        fecharSolicitacao($estado, $solicitacao, 'Aprovado',
                          $decisaoTeams['nome'], $decisaoTeams['email'], '');
        avisar($solicitacao, 'liberado', '');
        return 'Aprovado';
    }

    passo('Condicao: decisao e igual a aprovar', 'NAO -> reprovar');
    fecharSolicitacao($estado, $solicitacao, 'Reprovado',
                      $decisaoTeams['nome'], $decisaoTeams['email'],
                      $decisaoTeams['motivo']);
    avisar($solicitacao, 'reprovado', $decisaoTeams['motivo']);
    return 'Reprovado';
}

/* ---------------------------------------------------------- gravar na base -- */
/* O trecho que os dois ramos compartilham: atualizar-ou-criar pela FUNCIONAL.
   É o que garante uma linha só por pessoa. */
function gravarNaBase(&$estado, $sol, $previsto, $origem, $aprovador, $aprovadorEmail) {

    $chave = chaveDe(array(
        'funcional'  => $sol['Funcional'],
        'funcionalL' => $sol['Funcional_L'],
        'email'      => $sol['Email']
    ));

    $indice = -1;
    foreach ($estado['base'] as $i => $l) {
        if (chaveDe($l) === $chave) { $indice = $i; break; }
    }
    passo('linhaAtual',
          "Funcional eq '" . $sol['Funcional'] . "' -> " .
          ($indice === -1 ? '0 itens (vai criar)' : '1 item (vai atualizar, id ' . $indice . ')'));

    /* O perfil que vai para o RLS pode diferir do escolhido: apoio vira GR/AG. */
    $perfilRls = rlsDe($sol['PerfilSolicitado']);

    $linha = array(
        'email'          => $sol['Email'],
        'nome'           => $sol['Nome'],
        'funcional'      => $sol['Funcional'],
        'funcionalL'     => $sol['Funcional_L'],
        'cargo'          => $sol['Cargo'],
        'nivel'          => $perfilRls,
        'nivelBase'      => $previsto !== '' ? $previsto : $perfilRls,
        'juncao'         => $sol['Juncao'],
        'juncaoNome'     => $sol['Juncao_Nome'],
        'posto'          => $sol['Posto'],
        'postoNome'      => $sol['Posto_Nome'],
        'validoAte'      => $sol['ValidoAte'],
        'protocolo'      => $sol['Protocolo'],
        'solicitante'      => $sol['SolicitanteNome'] !== '' ? $sol['SolicitanteNome'] : $sol['Nome'],
        'solicitanteEmail' => $sol['SolicitanteEmail'],
        'origem'         => $origem,
        'status'         => 'Ativo',
        'aprovador'      => $aprovador === 'sistema' ? '' : $aprovador,
        'aprovadorEmail' => $aprovadorEmail === 'sistema' ? '' : $aprovadorEmail,
        'atualizadoEm'   => $estado['hoje']
    );

    if ($indice === -1) {
        $estado['base'][] = $linha;
        passo('Criar item em Base_Acessos',
              $sol['Nome'] . ' · perfil ' . $perfilRls .
              ($sol['ValidoAte'] !== '' ? ' · valido ate ' . $sol['ValidoAte'] : ' · permanente'));
    } else {
        /* PerfilBase não se perde numa atualização: é para onde a pessoa volta. */
        if ($previsto === '' && isset($estado['base'][$indice]['nivelBase'])) {
            $linha['nivelBase'] = $estado['base'][$indice]['nivelBase'];
        }
        $estado['base'][$indice] = $linha;
        passo('Atualizar item em Base_Acessos',
              $sol['Nome'] . ' · perfil ' . $perfilRls .
              ' · base ' . $linha['nivelBase'] .
              ($sol['ValidoAte'] !== '' ? ' · valido ate ' . $sol['ValidoAte'] : ' · permanente'));
    }
}

function fecharSolicitacao(&$estado, $sol, $status, $aprovador, $email, $motivo) {
    foreach ($estado['solicitacoes'] as $i => $s) {
        if ($s['Protocolo'] !== $sol['Protocolo']) { continue; }
        $estado['solicitacoes'][$i]['Status']         = $status;
        $estado['solicitacoes'][$i]['Aprovador']      = $aprovador === 'sistema' ? 'sistema' : $aprovador;
        $estado['solicitacoes'][$i]['AprovadorEmail'] = $email;
        $estado['solicitacoes'][$i]['MotivoReprova']  = $motivo;
        $estado['solicitacoes'][$i]['DataDecisao']    = $status === 'Novo' ? '' : $estado['hoje'];
        break;
    }
    if ($status !== 'Novo') {
        passo('Atualizar item em Solicitacoes', 'Status = ' . $status);
    }
}

function avisar($sol, $tipo, $motivo) {
    $para = $sol['Email'];
    $mais = ($sol['Destino'] === 'outro' && $sol['SolicitanteEmail'] !== $sol['Email'])
        ? ' + ' . $sol['SolicitanteEmail'] . ' (quem pediu)' : '';

    if ($tipo === 'liberado') {
        passo('Enviar um email (V2)', "para $para$mais · acesso liberado");
        passo('Postar mensagem no Teams', "para $para$mais");
    } else {
        passo('Enviar um email (V2)', "para $para$mais · reprovado: $motivo");
        passo('Postar mensagem no Teams', "para $para$mais · reprovado");
    }
}

/* ===========================================================================
   FLUXO 2 · Acessos - Expiração
   Gatilho: recorrência diária.
   =========================================================================== */
function fluxoExpiracao(&$estado) {

    passo('Gatilho: recorrencia diaria', 'hoje ' . $estado['hoje']);

    $ativos = array();
    foreach ($estado['base'] as $i => $l) {
        if (normalizar(valor($l, 'status')) === 'ativo') { $ativos[$i] = $l; }
    }
    passo('ativos', "StatusAcesso eq 'Ativo' -> " . count($ativos) . ' item(ns)');

    $venceram = 0;
    foreach ($ativos as $i => $l) {
        $ate = trim(valor($l, 'validoAte'));

        /* Condição: ValidoAte preenchido E menor que hoje */
        if ($ate === '' || $ate >= $estado['hoje']) { continue; }

        $venceram++;
        $de   = $l['nivel'];
        $para = valor($l, 'nivelBase') !== '' ? $l['nivelBase'] : $l['nivel'];

        $estado['base'][$i]['nivel']        = $para;
        $estado['base'][$i]['validoAte']    = '';
        $estado['base'][$i]['origem']       = 'expiracao';
        $estado['base'][$i]['atualizadoEm'] = $estado['hoje'];

        passo('Atualizar item em Base_Acessos',
              $l['nome'] . ' · venceu em ' . $ate . ' · ' . $de . ' -> ' . $para);
        passo('Enviar um email (V2)', 'para ' . $l['email'] . ' · perfil elevado venceu');
        passo('Postar mensagem no Teams', 'para ' . $l['email']);
    }

    if ($venceram === 0) { passo('Aplicar a cada', 'nenhum perfil venceu hoje'); }
    return $venceram;
}

/* ===========================================================================
   FLUXO 3 · Acessos - Exportar base
   Gatilho: recorrência de hora em hora. Gera o arquivo que a tela lê.
   =========================================================================== */
function fluxoExportarBase(&$estado) {
    passo('Gatilho: recorrencia de hora em hora', '');
    passo('Obter itens em Base_Acessos', count($estado['base']) . ' linha(s)');

    $destino = __DIR__ . '/estado/base-exportada.json';
    file_put_contents($destino, json_encode($estado['base'],
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));

    passo('Criar arquivo', 'base.json com ' . count($estado['base']) . ' linha(s)');
    return $destino;
}
