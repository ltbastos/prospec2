# Portal de Acessos (PJ, MIS e DEO) — montagem no ambiente do trabalho

Guia de ponta a ponta. Siga na ordem: cada passo depende do anterior.

## Antes de tudo: rodando no PC pessoal

Com `MODO: 'mock'` em `src/config.js`, o projeto roda sozinho, sem nada da Microsoft:
copie a pasta para `C:\xampp\htdocs\acessos`, ligue o Apache e abra
`http://localhost/acessos/`. A tela carrega o perfil fictício de `mock/perfil.json` e valida
contra `mock/matriz.json`. Os envios viram arquivos em `data/`.

Para testar sem o XAMPP, o servidor embutido do PHP também serve:
`C:\xampp\php\php.exe -S 127.0.0.1:8099 -t .`

| URL | Mostra |
|---|---|
| `/` | o formulário |
| `/?debug=1` | o diagnóstico do perfil |
| `/?ok=1&protocolo=X&tipo=manual&nome=Ana&perfil=AG&ate=2026-11-30` | a tela de sucesso |

Trocar o cargo em `mock/perfil.json` muda onde a linha de limite aparece na escada — é a
forma mais rápida de ver a regra funcionando.

---

## As quatro etapas

O formulário é uma sequência, e cada tela tem um trabalho só:

| # | Etapa | O que acontece |
|---|---|---|
| 1 | **Para quem** | para mim ou para outra pessoa |
| 2 | **Os dados** | pré-preenchidos pelo diretório (ou em branco, se for para outra pessoa) |
| 3 | **Nivel de acesso** | a escada dos 12 níveis; divergiu → popup, motivo e prazo |
| 4 | **Resumo** | tudo junto, com "Editar" em cada bloco, e Submeter ou Cancelar |

## A situação de cada pessoa

Toda pessoa está em um de três estados, e a tela mostra o dela no cabeçalho:

| Situação | Quando |
|---|---|
| **Aprovado** | já está na `Base_Acessos` com acesso ativo |
| **Pendente** | tem solicitação em `Solicitacoes` esperando a governança |
| **Sem Acesso** | não está na base e não tem nada esperando |

⚠️ **Quem já está na base tem os dados vindos DELA, não do diretório.** É o que vale hoje —
e alterar algo atualiza a mesma linha. A chave de unicidade é a **funcional**: nunca existem
duas linhas para a mesma pessoa. Só cai para o e-mail quando a funcional está em branco.

## Junção e Posto: número e nome separados

O RLS compara **número**, então as colunas que ele lê guardam só isso. O nome mora ao lado,
para leitura:

| Coluna | Conteúdo | Exemplo |
|---|---|---|
| `Juncao` | só o número — **é o que o RLS compara** | `3311` |
| `Juncao_Nome` | o nome, para leitura | `Junção Centro Sul` |
| `Posto` | só o número — **é o que o RLS compara** | `1234` |
| `Posto_Nome` | o nome, para leitura | `Ag. Paulista` |

O diretório entrega os dois juntos num campo só (`3311 · Junção Centro Sul`,
`Ag. 1234 · Paulista`). A página separa sozinha ao carregar: os dígitos vão para o número, o
resto vira o nome. Nos campos de número a tela **só aceita dígitos** — digitar `ABC77x9`
deixa `779`.

Só o **número** conta como campo de regra: corrigir o nome não manda a solicitação para a
governança, corrigir o número manda.

## Níveis de apoio

Duas op\u00e7\u00f5es existem s\u00f3 na tela e n\u00e3o t\u00eam c\u00f3digo pr\u00f3prio no RLS:

| A pessoa escolhe | Vai para a base como | Alcance |
|---|---|---|
| **Apoio Regional** (`APOIO_GR`) | `GR` | o mesmo de GR |
| **Apoio Ag\u00eancia** (`APOIO_AG`) | `AG` | o mesmo de AG |

S\u00e3o para quem \u00e9 de outro perfil e est\u00e1 apoiando a regional ou a ag\u00eancia por um per\u00edodo.
O RLS n\u00e3o precisa saber disso \u2014 ele continua vendo s\u00f3 `GR` ou `AG`.

O que muda em rela\u00e7\u00e3o aos demais perfis:

- **Nunca aprovam sozinhos.** Apoio \u00e9 sempre decis\u00e3o da governan\u00e7a.
- **Sempre exigem data de t\u00e9rmino**, mesmo quando o alcance n\u00e3o sobe em rela\u00e7\u00e3o ao cargo.
  Apoio \u00e9 tempor\u00e1rio por defini\u00e7\u00e3o; sem prazo viraria promo\u00e7\u00e3o silenciosa.
- **A solicita\u00e7\u00e3o guarda os dois c\u00f3digos.** `NivelSolicitado` fica `APOIO_AG` (a auditoria
  precisa saber que foi apoio) e a `Base_Acessos` recebe `AG` (o RLS precisa do c\u00f3digo).

No Power App, grave `Param("perfilRls")` na `Base_Acessos` e `Param("perfil")` na
`Solicitacoes`. Para criar outros perfis assim, basta um `rls` e um `exigePrazo` no
`perfis.json` \u2014 nada mais precisa mudar.

## As duas funcionais

A mesma pessoa tem a funcional escrita de dois jeitos, e as duas colunas convivem na base:

| Coluna | Forma | Exemplo |
|---|---|---|
| `Funcional` | numérica | `9437643` |
| `Funcional_L` | com letra | `I437643` |

A primeira posição troca de letra para dígito pela ordem do alfabeto: **A=1, B=2, C=3 … I=9**.
O resto do código nunca muda. Vai só até o 9 porque a funcional tem largura fixa — trocar a
letra por dois dígitos mudaria o tamanho. Se um dia aparecerem letras acima de `I`, o lugar
de resolver é a constante `LETRAS` em `src/funcional.js` e `FUNCIONAL_LETRAS` em
`api/comum.php`.

O que isso muda na prática:

- **Preencher uma preenche a outra.** Digite em qualquer um dos dois campos e o par se
  ajusta sozinho — ninguém digita duas vezes nem deixa as duas em desacordo.
- **A busca aceita as duas.** Procurar por `I437643` ou por `9437643` acha a mesma pessoa.
- **A unicidade compara pela forma numérica.** É o que impede `I437643` e `9437643` de
  virarem duas linhas na base para a mesma pessoa.

No Power App, mande as duas na URL e grave as duas na `Base_Acessos`. Se o diretório só
tiver uma delas, a página completa a outra ao carregar.

Por isso a `Base_Acessos` também guarda o **cargo**: sem ele a tela teria que voltar ao
diretório para uma informação que a base já deveria conhecer.

## A regra

Cada cargo tem **um** nível previsto. A aprovação é automática só quando **as três** valem:
o pedido é para si mesmo, o nível escolhido é o previsto para o cargo, e nenhum campo de
regra (cargo, junção, posto) foi editado. Qualquer outra combinação vai para a governança.
Pedir um perfil **acima** do previsto ainda exige data de término, de no máximo 6 meses.

Os doze níveis oferecidos na tela, do mais amplo para o mais restrito:

| Código | Sigla | Rank | Alcance |
|---|---|---|---|
| `DP` | DP | 6 | tudo, de todos, sem restrição |
| `DR` | DR | 5 | todas as regionais e agências da diretoria |
| `GR` | GR | 4 | todas as agências e times da regional |
| `GEC` | GEC | 4 | a carteira executiva da regional |
| `AG` | AG | 3 | a agência inteira, com todos os times |
| `GG` | GG | 2 | o time — os GC, PA e AS ligados a você |
| `TL` | TL | 2 | idem, Team Leader |
| `GC` | GC | 1 | a carteira de relacionamento |
| `PA` | PA | 1 | o posto de atendimento |
| `AS` | AS | 1 | a carteira de atendimento |

`GR`/`GEC` dividem o rank 4, `GG`/`TL` dividem o rank 2, e `GC`/`PA`/`AS` dividem o rank 1. Trocar entre perfis de mesmo
rank não é elevação: é mudança lateral, vai para a governança mas não exige data. Se na
prática um deles for maior que o outro, mude o `rank` em `perfis.json` — a tela e o PHP
passam a tratar como elevação sozinhos.

A `Direcao` gravada em cada solicitação diz qual caminho foi:

| Direção | Quando |
|---|---|
| `igual` | perfil do cargo, para si, sem edição — o único que aprova sozinho |
| `acima` | perfil de rank maior que o do cargo — exige data de término |
| `abaixo` | perfil de rank menor |
| `lateral` | outro perfil do mesmo rank |
| `campo-editado` | perfil certo, mas cargo/junção/posto foi corrigido na tela |
| `desconhecido` | o cargo não está no de-para |
| `terceiro` | pedido para outra pessoa |
| `apoio` | nível de apoio \u2014 sempre manual e sempre com prazo |

⚠️ **O `codigo` é o texto que vai parar na base que o RLS lê.** Ele precisa ser exatamente a
string que o filtro do RLS compara. Se algum código no seu RLS for diferente do que está em
`perfis.json`, é lá que se ajusta — nada mais precisa mudar.

---

## O mapa

```
①  Usuário clica no link do Power App
    POWER APP · tela Entrada
    lê o perfil Microsoft 365 + o nível previsto para o cargo, no SharePoint
                    │  Launch("http://SERVIDOR/acessos/?nome=...&previsto=GC")
                    ▼
②  XAMPP · o formulário
    4 etapas: para quem · os dados · o perfil · o resumo
                    │  redireciona com o que foi escolhido
                    ▼
③  POWER APP · tela Retorno
    RELÊ o perfil do usuário logado  ← a identidade verdadeira nasce aqui
    grava em Solicitacoes (Status "Novo")
                    │  Launch("http://SERVIDOR/acessos/?ok=1&protocolo=...")
                    ▼
④  XAMPP · tela de sucesso        ⑤  POWER AUTOMATE · fluxo Triagem
                                      recalcula a regra e decide
                                      auto   → grava em Base_Acessos + avisos
                                      manual → card no Teams → decide → idem
                                  ⑥  POWER AUTOMATE · fluxo Expiração (diário)
                                      devolve perfis elevados vencidos ao perfil base
```

**Por que o Power App aparece duas vezes:** ele é o único componente que a Microsoft
autentica. A página roda no Apache do XAMPP — se ela tentasse descobrir "o usuário logado"
pelo servidor, devolveria sempre o dono da máquina que hospeda, igual para todo mundo. Toda
identidade que vai para a base nasce do `User().Email` dentro do Power App, na etapa ③.

**Sobre a primeira vez:** o Power Apps pode pedir consentimento das conexões na primeira
abertura. Por isso a tela Entrada tem um botão visível, e não só um redirecionamento
automático — se a caixa de permissão aparecer, o usuário confirma e clica em Entrar.

---

## Passo 1 — subir a página no XAMPP

1. Copie a pasta inteira do projeto para `C:\xampp\htdocs\acessos`.
2. Abra o painel do XAMPP e ligue o **Apache**. Marque para iniciar junto com o Windows —
   se a máquina reiniciar e o Apache não subir, o portal sai do ar.
3. Descubra o IP da máquina: `ipconfig` → anote o **IPv4** (ex.: `10.20.30.40`).
4. Libere a porta 80 no firewall:
   `netsh advfirewall firewall add rule name="Portal de Acessos" dir=in action=allow protocol=TCP localport=80`
5. De **outro computador** da rede, abra `http://10.20.30.40/acessos/`.
   Tem que aparecer a tela "Abra pelo link oficial" — é o esperado, ainda não há identidade.

---

## Passo 2 — as listas do SharePoint

> **Atalho:** `provisionar/Criar-Listas.ps1` cria as quatro listas com todas as colunas de
> uma vez, e é idempotente. Ver `provisionar/LEIAME.md`. As tabelas abaixo continuam valendo
> como referência do que cada coluna guarda.

Crie no site do time. **Todas as colunas como "Linha única de texto"**, exceto onde indicado.
Texto em vez de Escolha é de propósito: coluna de Escolha exige `{Value: "..."}` no Patch e
`Value` no fluxo, e isso é a origem mais comum de erro nesse tipo de montagem.

### `Base_Acessos` — **a lista que o RLS lê**

É a razão de existir da ferramenta. Tudo o mais é o caminho até preencher esta tabela certo.

| Coluna | Tipo | Conteúdo |
|---|---|---|
| `Title` | texto | **o e-mail** — a chave que o RLS casa com `USERPRINCIPALNAME()` |
| `Nome` | texto | |
| `Nivel` | texto | o perfil que vale **agora** (`GC`, `AG`, …) |
| `NivelBase` | texto | o perfil do cargo — para onde volta quando o elevado vence |
| `Cargo` | texto | o cargo, para a tela não precisar voltar ao diretório |
| `Funcional` | texto | funcional numérica (`9437643`) — **a chave de unicidade** |
| `Funcional_L` | texto | a mesma funcional com letra (`I437643`) |
| `Juncao` `Posto` | texto | **só o número** — as chaves que o RLS usa para filtrar |
| `Juncao_Nome` `Posto_Nome` | texto | o nome, só para leitura |
| `ValidoAte` | data | vazio = permanente; preenchido = nível elevado temporário |
| `Protocolo` | texto | rastreia de qual solicitação veio |
| `Origem` | texto | `automatica` ou `manual` |
| `Solicitante` | texto | **quem pediu** — mesmo quando pediu para outra pessoa |
| `SolicitanteEmail` | texto | o e-mail de quem pediu |
| `Aprovador` | texto | **quem aprovou à mão** — nome de quem decidiu no cartão do Teams |
| `AprovadorEmail` | texto | o e-mail dessa pessoa, para auditoria |
| `StatusAcesso` | texto | `Ativo` ou `Revogado` |
| `AtualizadoEm` | data e hora | |

⚠️ **Uma linha ativa por pessoa.** Os fluxos abaixo atualizam a linha existente em vez de
criar outra. Isso importa porque, com duas linhas ativas, o RLS uniria os dois escopos e a
pessoa enxergaria mais do que deveria. Se o seu RLS espera várias linhas por pessoa, me avise
que o desenho muda.

**Atenção ao valor do e-mail:** o RLS dinâmico do Power BI casa com `USERPRINCIPALNAME()`.
Na maioria dos tenants isso é igual ao e-mail da pessoa, mas quando difere o acesso
simplesmente não funciona, sem erro visível. Se no seu tenant os dois divergirem, grave aqui
o valor do `userPrincipalName` — a coluna continua se chamando e-mail.

Um filtro de RLS lendo esta tabela fica mais ou menos assim (exemplo, adapte ao seu modelo):

```dax
[Title] = USERPRINCIPALNAME()
    && [StatusAcesso] = "Ativo"
    && ( ISBLANK([ValidoAte]) || [ValidoAte] >= TODAY() )
```

A condição da data é um cinto de segurança: mesmo que o fluxo de expiração falhe num dia,
o nível elevado para de valer sozinho.

### `Matriz_Cargo_Nivel` — **o de-para, e ele mora só aqui**

| Coluna | Tipo | Exemplo |
|---|---|---|
| `Title` | texto | `Gerente de Contas` — o cargo, como vem do diretório |
| `Nivel` | texto | `GC` |
| `Ativo` | Sim/Não | padrão `Sim` |

⚠️ **Preencha esta lista só depois do Passo 6.** O texto de `Title` precisa bater com o
`jobTitle` do diretório, e a tela de diagnóstico mostra os valores reais.

### `Solicitacoes` — trilha de tudo que foi pedido

A solicitação tem **duas pessoas**: quem pediu (sempre autenticado pelo Power App) e
quem vai receber o acesso (pode ser outra pessoa). A lista guarda as duas.

| Coluna | Tipo | Conteúdo |
|---|---|---|
| `Title` | texto | o protocolo (`AC-20260819-7F3A21`) |
| `Destino` | texto | `eu` ou `outro` |
| **quem pediu** | | |
| `SolicitanteEmail` `SolicitanteNome` | texto | quem estava logado, vindo do diretório |
| `SolicitanteCargo` | texto | cargo do diretório de quem pediu |
| **quem recebe** | | |
| `Nome` `Email` `Funcional` `Funcional_L` | texto | o que foi confirmado ou digitado na tela |
| `Juncao` `Juncao_Nome` `Cargo` | texto | idem |
| `Posto` `Posto_Nome` | texto | idem |
| `CargoDiretorio` | texto | cargo do diretório do beneficiário — vazio quando `Destino` = `outro` |
| `JuncaoDiretorio` `PostoDiretorio` | texto | idem |
| **o pedido** | | |
| `NivelSolicitado` | texto | `AG` |
| `NivelPrevisto` | texto | `GC` — vazio quando `Destino` = `outro` |
| `Direcao` | texto | `igual`, `acima`, `abaixo`, `lateral`, `campo-editado`, `desconhecido` ou `terceiro` |
| `ValidoAte` | data | obrigatória quando o perfil é elevado; opcional para terceiros |
| `Justificativa` | várias linhas | o motivo |
| `CamposEditados` | texto | lista separada por vírgula |
| `EditouCampoDeRegra` | **Sim/Não** | mexeu em cargo, junção ou posto |
| **a decisão** | | |
| `TipoAprovacao` | texto | `automatica` ou `manual` |
| `Status` | texto | `Novo`, `Aprovado`, `Reprovado` |
| `AprovadorEmail` | texto | quem decidiu (ou `sistema`) |
| `MotivoReprova` | várias linhas | |
| `DataDecisao` | data e hora | |

⚠️ **Solicitação para outra pessoa nunca aprova sozinha.** A página só conhece o cargo de
quem está logado — não há como conferir no diretório o cargo de quem vai receber. Por isso
`Destino = outro` sempre cai na governança, e é lá que se confere se o cargo declarado bate
com o diretório. Se quiser que o fluxo resolva isso sozinho, dá para acrescentar uma ação
**Office 365 Users · Obter perfil do usuário (V2)** pelo e-mail do beneficiário e aplicar a
mesma regra — me avise que eu escrevo esse ramo.

---

## Passo 3 — o Power App

Crie um app **canvas, layout tablet**, chamado `Portal de Acessos - Ponte`.
Adicione as conexões **Office 365 Users** e **SharePoint** (as três listas). Ambas são
conectores padrão — não consomem licença premium.

Crie duas telas em branco: `scrEntrada` e `scrRetorno`.

### `App.OnStart`

```powerfx
Set(gPagina, "http://10.20.30.40/acessos/");
Set(gPerfil, Office365Users.MyProfileV2())
```

### `App.StartScreen`

```powerfx
If(Param("tela") = "retorno", scrRetorno, scrEntrada)
```

### `scrEntrada` — a tela que o usuário quase não vê

Coloque um texto discreto ("Portal de Acessos") e **um botão "Entrar"**. O botão existe para
o caso do consentimento das conexões aparecer na primeira vez — sem ele, o usuário ficaria
preso numa tela que já tentou redirecionar.

`btnEntrar.OnSelect` (e também um `Timer` com `AutoStart` e `Duration: 900`, mesmo código no
`OnTimerEnd`, para quem já consentiu e não precisa clicar em nada):

```powerfx
Set(gPrevisto,
    LookUp(Matriz_Cargo_Nivel,
        Lower(Title) = Lower(Coalesce(gPerfil.jobTitle, "")) && Ativo
    ).Nivel
);

Launch(
    gPagina & "?" &
    "nome="       & EncodeUrl(Coalesce(gPerfil.displayName, "")) &
    "&email="     & EncodeUrl(Coalesce(gPerfil.mail, User().Email)) &
    "&funcional="  & EncodeUrl("") &
    "&juncao="     & EncodeUrl(Coalesce(gPerfil.department, "")) &
    "&cargo="     & EncodeUrl(Coalesce(gPerfil.jobTitle, "")) &
    "&posto="     & EncodeUrl(Coalesce(gPerfil.officeLocation, "")) &
    &
    "&previsto="  & EncodeUrl(Coalesce(gPrevisto, "")),
    {},
    LaunchTarget.Replace
)
```

### `scrRetorno.OnVisible`

```powerfx
// 1 · identidade autoritativa: vem de quem está logado, nunca da URL
Set(gPerfil, Office365Users.MyProfileV2());
Set(gEmail, Coalesce(gPerfil.mail, User().Email));

// 2 · para quem é, e mexeu em algum campo que a regra usa?
Set(gDestino, If(Param("destino") = "outro", "outro", "eu"));
Set(gEditados, Coalesce(Param("edit"), ""));
Set(gEditouRegra,
    "cargo" in gEditados || "juncao" in gEditados || "posto" in gEditados
);

// 3 · o nível previsto — só existe quando o acesso é para o próprio usuário
Set(gPrevisto,
    If(gDestino = "outro",
       "",
       Coalesce(
           LookUp(Matriz_Cargo_Nivel,
               Lower(Title) = Lower(Coalesce(gPerfil.jobTitle, "")) && Ativo
           ).Nivel,
           ""
       )
    )
);
Set(gPedido, Param("perfil"));
Set(gTipo,
    If(gDestino = "eu" && !IsBlank(gPrevisto) && gPedido = gPrevisto && !gEditouRegra,
       "automatica", "manual")
);

// 4 · grava a solicitação — quem pediu e quem recebe, separados
Patch(Solicitacoes, Defaults(Solicitacoes), {
    Title:              Param("protocolo"),
    Destino:            gDestino,

    SolicitanteEmail:   gEmail,
    SolicitanteNome:    gPerfil.displayName,
    SolicitanteCargo:   gPerfil.jobTitle,

    Nome:               Param("nome"),
    Email:              Param("email"),
    Funcional:          Param("funcional"),
    Funcional_L:        Param("funcionalL"),
    Juncao:             Param("juncao"),
    Juncao_Nome:        Param("juncaoNome"),
    Cargo:              Param("cargo"),
    Posto:              Param("posto"),
    Posto_Nome:         Param("postoNome"),

    // Do diretório só temos os dados de quem está logado. Para outra pessoa
    // ficam vazios de propósito — quem confere no diretório é a governança.
    CargoDiretorio:     If(gDestino = "eu", gPerfil.jobTitle, ""),
    JuncaoDiretorio:    If(gDestino = "eu", gPerfil.department, ""),
    PostoDiretorio:     If(gDestino = "eu", gPerfil.officeLocation, ""),

    NivelSolicitado:   gPedido,
    NivelPrevisto:     gPrevisto,
    Direcao:            Param("dir"),
    ValidoAte:          If(IsBlank(Param("ate")), Blank(), DateValue(Param("ate"))),
    Justificativa:      Param("just"),
    CamposEditados:     gEditados,
    EditouCampoDeRegra: gEditouRegra,
    TipoAprovacao:      gTipo,
    Status:             "Novo"
});

// 5 · devolve o usuário para a tela de sucesso da página
Launch(
    gPagina & "?ok=1" &
    "&protocolo=" & EncodeUrl(Param("protocolo")) &
    "&tipo="      & gTipo &
    "&destino="   & gDestino &
    "&nome="      & EncodeUrl(Param("nome")) &
    "&perfil="    & EncodeUrl(gPedido) &
    "&ate="       & EncodeUrl(Coalesce(Param("ate"), "")),
    {},
    LaunchTarget.Replace
)
```

Publique o app e **compartilhe com o grupo do time**. Copie a URL da Web
(app → `...` → Detalhes → URL da Web): é ela que vai no `config.js` e no e-mail de divulgação.

> **Sobre a matrícula:** `Office365Users.MyProfileV2()` **não** devolve `employeeId`. Por isso
> a fórmula manda o campo vazio e o usuário digita. Se a matrícula existir em alguma lista do
> SharePoint, troque `EncodeUrl("")` por um `LookUp` nessa lista. Se não for usar, apague a
> linha `funcional` de `CAMPOS` em `src/config.js` e o campo some da tela.

---

## Passo 3b — a tela `scrBuscar` do Power App

Quando a solicitação é **para outra pessoa**, a página precisa dos dados dela — e ela não
fala com o diretório. Então manda o usuário até o Power App, que busca e devolve.

Crie a tela `scrBuscar` e acrescente a rota em `App.StartScreen`:

```powerfx
Switch(Param("tela"),
    "retorno", scrRetorno,
    "buscar",  scrBuscar,
    scrEntrada
)
```

`scrBuscar.OnVisible` — procura por e-mail ou por funcional e volta na hora:

```powerfx
Set(gTermo, Coalesce(Param("termo"), ""));

// 1 · tenta como e-mail; se falhar, procura pela funcional na lista do RH
Set(gAchado, Office365Users.SearchUserV2({searchTerm: gTermo, top: 1}).value);
Set(gPessoa, First(gAchado));

If(IsBlank(gPessoa) || CountRows(gAchado) = 0,
    Launch(gPagina & "?achou=0&termo=" & EncodeUrl(gTermo), {}, LaunchTarget.Replace),
    Launch(
        gPagina & "?achou=1" &
        "&nome="      & EncodeUrl(Coalesce(gPessoa.DisplayName, "")) &
        "&email="     & EncodeUrl(Coalesce(gPessoa.Mail, "")) &
        "&funcional=" & EncodeUrl("") &
        "&juncao="    & EncodeUrl(Coalesce(gPessoa.Department, "")) &
        "&cargo="     & EncodeUrl(Coalesce(gPessoa.JobTitle, "")) &
        "&posto="     & EncodeUrl(Coalesce(gPessoa.OfficeLocation, "")) &
        "&termo="     & EncodeUrl(gTermo),
        {},
        LaunchTarget.Replace
    )
)
```

`SearchUserV2` procura por nome e por e-mail, **não por funcional**. Se quiserem buscar pela
funcional, acrescente antes um `LookUp` numa lista do SharePoint com o de-para
funcional → e-mail, e use o e-mail encontrado como `searchTerm`.

A página guarda o rascunho do formulário em `sessionStorage` antes de sair e o retoma na
volta, então o usuário não perde o que já tinha preenchido.

> **Alternativa sem ida e volta:** com `MODO_BUSCA: 'local'` em `src/config.js`, a busca
> acontece no próprio XAMPP, em `data/colaboradores.json` ou `data/colaboradores.csv`.
> É instantâneo e não sai da página — em troca, alguém precisa atualizar esse extrato de
> tempos em tempos. O `api/buscar.php` já lê os dois formatos.

---

## Passo 3c — administradores e a base completa

**Quem é administrador** fica numa lista `Portal_Admins` do SharePoint: uma coluna `Title`
com o e-mail de cada um. O Power App consulta e avisa a página. Acrescente ao
`scrEntrada`, junto do `Launch`:

```powerfx
"&adm=" & If(!IsBlank(LookUp(Portal_Admins, Lower(Title) = Lower(User().Email))), "1", "0")
```

**A situação também sai do Power App**, que é quem lê as duas listas. Ainda no `scrEntrada`,
antes do `Launch`:

```powerfx
// a linha da pessoa na base, pela FUNCIONAL quando houver, senão pelo e-mail
Set(gLinha,
    LookUp(Base_Acessos,
        Lower(Title) = Lower(gEmail) && StatusAcesso = "Ativo"
    )
);
Set(gPend,
    LookUp(Solicitacoes,
        Lower(SolicitanteEmail) = Lower(gEmail) && Status = "Novo"
    )
);
Set(gSituacao,
    If(!IsBlank(gPend), "Pendente",
       If(!IsBlank(gLinha), "Aprovado", "Sem Acesso"))
);
```

E acrescente à URL — quando a pessoa já está na base, mande os campos **da linha**, não os
do diretório:

```powerfx
"&situacao="    & EncodeUrl(gSituacao) &
"&naBase="      & If(!IsBlank(gLinha), "1", "0") &
"&perfilAtual=" & EncodeUrl(Coalesce(gLinha.Nivel, "")) &
"&ate="         & EncodeUrl(If(IsBlank(gLinha.ValidoAte), "", Text(gLinha.ValidoAte, "yyyy-mm-dd"))) &
"&protocolo="   & EncodeUrl(Coalesce(gPend.Title, ""))
```

⚠️ **A gravação vira atualizar-ou-criar pela funcional.** No fluxo `Acessos - Triagem`, troque
o filtro da ação `linhaAtual` para procurar primeiro pela funcional:

```
Funcional eq '@{triggerOutputs()?['body/Funcional']}'
```

e só caia no `Title eq '<e-mail>'` quando a funcional vier vazia. É o que garante uma linha só
por pessoa mesmo quando o e-mail muda.

A página só obedece ao que chegou — ela nunca decide sozinha quem vê a base.

**De onde vem a tabela.** A página não lê o SharePoint, então alguém precisa colocar um
extrato ao alcance do Apache. O `api/base.php` procura nesta ordem:

1. `data/base.json`
2. `data/base.csv`
3. `mock/base.json` (o exemplo que já vem no projeto)

Para alimentar o item 1 ou 2, crie um fluxo **`Acessos - Exportar base`**, com recorrência
de hora em hora:

1. SharePoint · *Obter itens* em `Base_Acessos`
2. **Criar arquivo** numa biblioteca do SharePoint, com o conteúdo
   `@{body('Obter_itens')?['value']}` e o nome `base.json`
3. Na máquina do XAMPP, sincronize essa biblioteca pelo cliente do OneDrive e aponte
   `data/base.json` para o arquivo sincronizado (um atalho simbólico resolve:
   `mklink data\base.json "C:\Users\...\OneDrive - Empresa\Base\base.json"`)

Assim a tabela na tela fica no máximo uma hora atrás da lista — e nenhuma credencial
precisa morar na máquina do XAMPP.

**As colunas da tela** são as de `COLUNAS_BASE`, em `src/config.js`. Troque a lista inteira
quando tiver os nomes reais: `chave` é o campo no JSON, `rotulo` é o cabeçalho e `tipo`
escolhe como o valor é desenhado (`texto`, `data`, `perfil` vira etiqueta, `estado` vira
bolinha colorida). Nada mais precisa mudar.

---

## Passo 4 — fluxo `Acessos - Triagem`

Fluxo de nuvem automatizado. Todos os conectores são padrão.

**Gatilho:** SharePoint → *Quando um item é criado* → lista `Solicitacoes`.

> Renomeie cada ação exatamente como indicado. As expressões chamam as ações pelo nome — se
> o nome mudar, a expressão quebra.

### 1 · `obterMatriz` — SharePoint, *Obter itens*
- Lista: `Matriz_Cargo_Nivel`
- Consulta de filtro: `Title eq '@{triggerOutputs()?['body/CargoDiretorio']}'`

### 2 · `previsto` — Compor
```
@if(empty(body('obterMatriz')?['value']), '', first(body('obterMatriz')?['value'])?['Nivel'])
```

### 3 · `tipoFinal` — Compor
```
@if(
  and(
    not(empty(outputs('previsto'))),
    equals(outputs('previsto'), triggerOutputs()?['body/NivelSolicitado']),
    not(equals(triggerOutputs()?['body/EditouCampoDeRegra'], true))
  ),
  'automatica',
  'manual'
)
```

O fluxo recalcula em vez de confiar no `TipoAprovacao` que veio do app. Isso importa porque o
usuário precisa ter permissão de contribuir na lista `Solicitacoes` para o Power App gravar —
ou seja, em tese ele conseguiria criar um item à mão. Recalculando aqui, isso não serve de nada.

### 4 · Condição: `outputs('tipoFinal')` **é igual a** `automatica`

#### ▸ Se sim — aprovação automática
Vá direto para **gravar na base** (seção abaixo), com `Origem` = `automatica` e
`AprovadorEmail` = `sistema`.

#### ▸ Se não — aprovação manual no Teams
1. **Teams · Postar cartão adaptável em um canal e aguardar uma resposta** — canal do time de
   BI, com o JSON da seção seguinte.
2. **Condição:** `@{body('cardAprovacao')?['data']?['decisao']}` é igual a `aprovar`
   - **sim:** grave na base com `Origem` = `manual` e
     `AprovadorEmail` = `@{body('cardAprovacao')?['responder']?['email']}`.
   - **não:** **Atualizar item** em `Solicitacoes` com `Status` = `Reprovado`,
     `MotivoReprova` = `@{body('cardAprovacao')?['data']?['motivo']}`, `AprovadorEmail` e
     `DataDecisao`; depois **e-mail** e **mensagem no Teams** para o solicitante com o motivo.

### Gravar na base — o trecho que os dois ramos compartilham

Como a regra é **uma linha ativa por pessoa**, é atualizar-ou-criar:

1. `linhaAtual` — SharePoint, *Obter itens* em `Base_Acessos`
   Filtro: `Funcional eq '@{triggerOutputs()?['body/Funcional']}'`
2. **Condição:** `@{length(body('linhaAtual')?['value'])}` é maior que `0`
   - **sim** → *Atualizar item*, usando
     `Id` = `@{first(body('linhaAtual')?['value'])?['ID']}`
   - **não** → *Criar item*

   Nos dois casos, os mesmos valores:

   | Coluna | Valor |
   |---|---|
   | `Title` | `Email` |
   | `Email` | `Email` (o do beneficiário) |
   | `Nome` | `Nome` (o do beneficiário) |
   | `Nivel` | `NivelSolicitado` |
   | `NivelBase` | `@{if(empty(outputs('previsto')), triggerOutputs()?['body/NivelSolicitado'], outputs('previsto'))}` |
   | `Juncao` `Posto` | os números declarados na tela |
   | `Juncao_Nome` `Posto_Nome` | os nomes |
   | `ValidoAte` | `ValidoAte` do gatilho (vazio quando não é elevação) |
   | `Protocolo` | `Title` do gatilho |
   | `Origem` | `automatica` ou `manual` |
   | `Solicitante` | `SolicitanteNome` do gatilho |
   | `SolicitanteEmail` | `SolicitanteEmail` do gatilho |
   | `Aprovador` | vazio no ramo automático; no manual, `@{body('cardAprovacao')?['responder']?['displayName']}` |
   | `AprovadorEmail` | idem, com `?['email']` |
   | `StatusAcesso` | `Ativo` |
   | `AtualizadoEm` | `@{utcNow()}` |

3. **Atualizar item** em `Solicitacoes`: `Status` = `Aprovado`, `AprovadorEmail`, `DataDecisao`.
4. **Outlook · Enviar um email (V2)** e **Teams · Postar mensagem em um chat ou canal**
   (Postar como `Bot do Flow` · Postar em `Chat com o bot do Flow` · Destinatário
   `Email`) avisando que o acesso foi liberado — e, quando houver `ValidoAte`, dizendo até
   quando ele vale. Se `Destino` for `outro`, mande também para `SolicitanteEmail`: quem
   pediu precisa saber que o pedido dele foi resolvido.

### O cartão adaptável (renomeie a ação para `cardAprovacao`)

```json
{
  "type": "AdaptiveCard",
  "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
  "version": "1.4",
  "body": [
    {
      "type": "TextBlock",
      "text": "Solicitação de acesso · @{triggerOutputs()?['body/Title']}",
      "weight": "Bolder", "size": "Medium", "wrap": true
    },
    {
      "type": "TextBlock",
      "text": "Nivel @{triggerOutputs()?['body/Direcao']} do previsto para o cargo.",
      "spacing": "None", "isSubtle": true, "wrap": true
    },
    {
      "type": "FactSet",
      "facts": [
        { "title": "Solicitante", "value": "@{triggerOutputs()?['body/SolicitanteNome']}" },
        { "title": "Beneficiário", "value": "@{triggerOutputs()?['body/Nome']} · @{triggerOutputs()?['body/Email']}" },
        { "title": "Cargo (diretório)", "value": "@{triggerOutputs()?['body/CargoDiretorio']}" },
        { "title": "Cargo (declarado)", "value": "@{triggerOutputs()?['body/Cargo']}" },
        { "title": "Junção", "value": "@{triggerOutputs()?['body/Juncao']}" },
        { "title": "Posto", "value": "@{triggerOutputs()?['body/Posto']}" },
        { "title": "Para quem", "value": "@{triggerOutputs()?['body/Destino']}" },
        { "title": "Nivel previsto", "value": "@{outputs('previsto')}" },
        { "title": "Nivel pedido", "value": "@{triggerOutputs()?['body/NivelSolicitado']}" },
        { "title": "Válido até", "value": "@{triggerOutputs()?['body/ValidoAte']}" },
        { "title": "Campos alterados", "value": "@{triggerOutputs()?['body/CamposEditados']}" }
      ]
    },
    { "type": "TextBlock", "text": "Justificativa", "weight": "Bolder", "spacing": "Medium", "wrap": true },
    { "type": "TextBlock", "text": "@{triggerOutputs()?['body/Justificativa']}", "wrap": true },
    {
      "type": "Input.Text", "id": "motivo",
      "placeholder": "Motivo — obrigatório para reprovar", "isMultiline": true
    }
  ],
  "actions": [
    { "type": "Action.Submit", "title": "Aprovar",  "style": "positive",    "data": { "decisao": "aprovar" } },
    { "type": "Action.Submit", "title": "Reprovar", "style": "destructive", "data": { "decisao": "reprovar" } }
  ]
}
```

Qualquer membro do canal pode decidir, e o cartão se atualiza mostrando quem decidiu.
O fluxo fica aguardando por até 30 dias.

---

## Passo 5 — fluxo `Acessos - Expiração`

Sem ele, o nível elevado de 6 meses vira permanente. É o fluxo que fecha a regra.

**Gatilho:** *Recorrência* — 1 vez por dia, 06:00.

1. `ativos` — SharePoint, *Obter itens* em `Base_Acessos`
   Filtro: `StatusAcesso eq 'Ativo'`
2. **Aplicar a cada** `@{body('ativos')?['value']}`
3. **Condição:**
   ```
   @and(
     not(empty(item()?['ValidoAte'])),
     less(item()?['ValidoAte'], utcNow())
   )
   ```
4. **Se sim — devolve a pessoa ao perfil do cargo:** *Atualizar item* em `Base_Acessos` com
   `Nivel` = `@{item()?['NivelBase']}`, `ValidoAte` = vazio, `AtualizadoEm` = `@{utcNow()}`.
   Depois **e-mail** e **Teams** avisando que o nível elevado venceu e o acesso voltou ao
   normal.

> Se preferir avisar antes de vencer, duplique o fluxo trocando a condição para
> `ValidoAte` daqui a 7 dias e mande só o aviso, sem alterar nada.

---

## Passo 6 — ligar a página no Power App

Edite **apenas** `src/config.js`:

```js
MODO: 'powerapps',
POWERAPP_URL: 'https://apps.powerapps.com/play/e/SEU-ENV-ID/a/SEU-APP-ID',
```

Salve. Não precisa reiniciar o Apache.

---

## Passo 7 — descobrir os campos reais do perfil

Faça **antes** de preencher a `Matriz_Cargo_Nivel`.

`Junção` e `Posto` **não existem** com esses nomes no Entra ID. O mapeamento em `MAPA_PERFIL`
é um palpite razoável (`department`, `officeLocation`) — pode estar errado
no seu tenant.

1. Abra o Power App normalmente. Quando a página carregar, acrescente `&debug=1` no fim da URL
   e recarregue.
2. A tela mostra cada campo, de qual propriedade ele veio, o nível previsto que chegou do
   Power App, e o perfil bruto completo embaixo.
3. Algum campo vazio ou trocado? Ajuste `MAPA_PERFIL` em `src/config.js` **e** as linhas
   correspondentes na fórmula `scrEntrada`.
4. **Copie os valores exatos de `jobTitle`** que aparecem ali — é com eles que você preenche a
   coluna `Title` da `Matriz_Cargo_Nivel`. Um acento diferente e a regra não casa.
5. Confira também se `userPrincipalName` é igual ao `mail`. Se for diferente, o RLS depende do
   valor do `userPrincipalName` — e a base já guarda o certo.

---

## Teste ponta a ponta

| # | Faça | Espere |
|---|---|---|
| 1 | Abra o link do Power App | a página abre já preenchida, com seu nome no topo e o degrau do seu cargo marcado `seu cargo` |
| 2 | Envie com o perfil do seu cargo | tela "Tudo certo", `Solicitacoes` com `Status Aprovado`, linha em `Base_Acessos` sem `ValidoAte`, e-mail e Teams recebidos |
| 3 | Escolha um perfil **acima** | popup avisando a elevação, campo de prazo aparece, justificativa vira obrigatória |
| 4 | Tente enviar sem data, e depois com data acima de 6 meses | os dois são recusados com a mensagem certa |
| 5 | Envie com data válida e aprove pelo cartão do Teams | `Base_Acessos` atualiza a **mesma linha** com o nível elevado e o `ValidoAte`, e `NivelBase` guarda o perfil do cargo |
| 6 | Escolha um perfil **abaixo** | popup avisando, sem campo de prazo, vai para aprovação manual |
| 7 | Faça uma e **reprove** com motivo | `Status Reprovado`, `MotivoReprova` preenchido, e-mail e Teams com o motivo, `Base_Acessos` intocada |
| 8 | Edite o campo Cargo e envie o perfil do cargo | vai para aprovação manual mesmo assim — é a proteção contra edição de campo de regra |
| 9 | Rode o fluxo de expiração à mão com uma linha vencida | `Nivel` volta para `NivelBase` e `ValidoAte` fica vazio |
| 10 | Abra `http://SERVIDOR/acessos/` direto | tela "Abra pelo link oficial" |

---

## Limitações conhecidas

- **A máquina do XAMPP é ponto único de falha.** Se ela desliga ou o Apache cai, o formulário
  some. O Power App, os fluxos e o RLS continuam de pé — só não entram solicitações novas.
- **Uma linha ativa por pessoa** em `Base_Acessos`. Se o seu RLS espera várias linhas por
  pessoa (por exemplo uma por junção), o desenho da gravação muda.
- **`Filter Query` do `obterMatriz`** quebra se algum cargo tiver apóstrofo no nome.
- **`GR`/`GEC` e `GC`/`AS` são pares de mesmo rank.** Trocar entre eles é mudança lateral,
  não elevação, então não pede data. Se na prática um for maior que o outro, ajuste o `rank`
  em `perfis.json` — a tela e o PHP passam a tratar como elevação sozinhos.
- **O `data/` do XAMPP** guarda uma cópia de cada envio como trilha local. Não é a base oficial —
  a base é o SharePoint. Limpe a pasta de tempos em tempos.
- Se um dia a máquina ganhar **HTTPS** e você conseguir **registrar um app no Entra ID**, dá para
  eliminar as duas passagens pelo Power App: `MODO: 'msal'` faz a própria página autenticar e ler
  o perfil pelo Graph. O adaptador já está previsto em `src/identity.js`, faltando implementar.
