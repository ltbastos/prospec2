<#
=============================================================================
 Portal de Acessos (PJ, MIS e DEO) — cria as listas do SharePoint

 Roda NO PC DO TRABALHO, logado com a sua conta. Cria as quatro listas com
 todas as colunas, nos tipos certos, e ajusta as visualizações.

 É idempotente: rodar de novo não duplica nada, só completa o que faltar.

 -----------------------------------------------------------------------------
 ANTES DE RODAR (uma vez só)

   Install-Module PnP.PowerShell -Scope CurrentUser

   Se a empresa bloquear a galeria do PowerShell, use o caminho alternativo:
   provisionar/site-script.json, que se aplica pelo centro de administração do
   SharePoint sem instalar nada.

 -----------------------------------------------------------------------------
 COMO RODAR

   .\Criar-Listas.ps1 -Site "https://suaempresa.sharepoint.com/sites/seu-time"

   Abre uma janela de login. Use a conta que vai ser dona das listas.

 -----------------------------------------------------------------------------
 O QUE ELE NÃO FAZ

   Não cria o Power App nem os fluxos: esses são construídos no navegador,
   passo a passo, com as fórmulas que estão no DEPLOY.md. Não existe formato
   de arquivo confiável para gerá-los de fora.
=============================================================================
#>

param(
    [Parameter(Mandatory = $true)]
    [string] $Site,

    # Preenche Portal_Admins com este e-mail. Deixe vazio para não preencher.
    [string] $PrimeiroAdmin = ""
)

$ErrorActionPreference = "Stop"

# ---------------------------------------------------------------- ajudantes --
function Garantir-Lista {
    param([string] $Titulo, [string] $Descricao)

    $existe = Get-PnPList -Identity $Titulo -ErrorAction SilentlyContinue
    if ($existe) {
        Write-Host "  lista '$Titulo' ja existe" -ForegroundColor DarkGray
        return
    }
    New-PnPList -Title $Titulo -Template GenericList -OnQuickLaunch | Out-Null
    Set-PnPList -Identity $Titulo -Description $Descricao | Out-Null
    Write-Host "  lista '$Titulo' criada" -ForegroundColor Green
}

function Garantir-Campo {
    param(
        [string] $Lista,
        [string] $Nome,
        [ValidateSet("Texto", "Longo", "Data", "DataHora", "SimNao")]
        [string] $Tipo = "Texto",
        [string] $Descricao = ""
    )

    $campo = Get-PnPField -List $Lista -Identity $Nome -ErrorAction SilentlyContinue
    if ($campo) { return }

    switch ($Tipo) {
        "Texto"    { $xml = "<Field Type='Text' Name='$Nome' StaticName='$Nome' DisplayName='$Nome' MaxLength='255' />" }
        "Longo"    { $xml = "<Field Type='Note' Name='$Nome' StaticName='$Nome' DisplayName='$Nome' NumLines='6' RichText='FALSE' />" }
        "Data"     { $xml = "<Field Type='DateTime' Name='$Nome' StaticName='$Nome' DisplayName='$Nome' Format='DateOnly' />" }
        "DataHora" { $xml = "<Field Type='DateTime' Name='$Nome' StaticName='$Nome' DisplayName='$Nome' Format='DateTime' />" }
        "SimNao"   { $xml = "<Field Type='Boolean' Name='$Nome' StaticName='$Nome' DisplayName='$Nome'><Default>0</Default></Field>" }
    }

    Add-PnPFieldFromXml -List $Lista -FieldXml $xml | Out-Null
    if ($Descricao) {
        Set-PnPField -List $Lista -Identity $Nome -Values @{ Description = $Descricao } | Out-Null
    }
    Write-Host "    + $Nome ($Tipo)" -ForegroundColor DarkCyan
}

function Renomear-Title {
    param([string] $Lista, [string] $Novo, [string] $Descricao = "")
    Set-PnPField -List $Lista -Identity "Title" -Values @{
        Title       = $Novo
        Description = $Descricao
    } | Out-Null
    Write-Host "    + Title renomeado para '$Novo'" -ForegroundColor DarkCyan
}

function Definir-Visualizacao {
    param([string] $Lista, [string[]] $Campos)
    try {
        Set-PnPView -List $Lista -Identity "All Items" -Fields $Campos | Out-Null
    } catch {
        Write-Host "    (nao consegui ajustar a visualizacao de '$Lista': $($_.Exception.Message))" -ForegroundColor Yellow
    }
}

# ------------------------------------------------------------------ conectar --
Write-Host ""
Write-Host "Portal de Acessos - provisionamento das listas" -ForegroundColor White
Write-Host "Site: $Site"
Write-Host ""

Connect-PnPOnline -Url $Site -Interactive
Write-Host "Conectado." -ForegroundColor Green
Write-Host ""

# =========================================================== 1 · Base_Acessos =
# A lista que o RLS le. Uma linha por pessoa, chaveada pela funcional.
Write-Host "1/4  Base_Acessos" -ForegroundColor White
Garantir-Lista "Base_Acessos" "Base de acessos aos dashboards. E a tabela que o RLS le."
Renomear-Title "Base_Acessos" "Email" "O e-mail que o RLS compara com USERPRINCIPALNAME(). Se no tenant o UPN diferir do e-mail, grave aqui o UPN."

Garantir-Campo "Base_Acessos" "Nome"           "Texto"
Garantir-Campo "Base_Acessos" "Funcional"      "Texto"    "Funcional numerica (9437643). E a chave de unicidade."
Garantir-Campo "Base_Acessos" "Funcional_L"    "Texto"    "A mesma funcional com letra (I437643)."
Garantir-Campo "Base_Acessos" "Cargo"          "Texto"
Garantir-Campo "Base_Acessos" "Nivel"         "Texto"    "O nível que vale agora: DP, DR, GR, GEC, AG, GG, TL, GC, PA ou AS."
Garantir-Campo "Base_Acessos" "NivelBase"     "Texto"    "O nível do cargo. Para onde volta quando um nível temporario vence."
Garantir-Campo "Base_Acessos" "Juncao"         "Texto"    "SO O NUMERO. E o que o RLS compara."
Garantir-Campo "Base_Acessos" "Juncao_Nome"    "Texto"    "O nome da juncao, so para leitura."
Garantir-Campo "Base_Acessos" "Posto"          "Texto"    "SO O NUMERO. E o que o RLS compara."
Garantir-Campo "Base_Acessos" "Posto_Nome"     "Texto"    "O nome do posto, so para leitura."
Garantir-Campo "Base_Acessos" "ValidoAte"      "Data"     "Vazio = permanente. Preenchido = perfil temporario."
Garantir-Campo "Base_Acessos" "Protocolo"      "Texto"
Garantir-Campo "Base_Acessos" "Origem"         "Texto"    "automatica ou manual."
Garantir-Campo "Base_Acessos" "StatusAcesso"   "Texto"    "Ativo ou Revogado."
Garantir-Campo "Base_Acessos" "Solicitante"      "Texto"    "Quem pediu, mesmo quando pediu para outra pessoa."
Garantir-Campo "Base_Acessos" "SolicitanteEmail" "Texto"
Garantir-Campo "Base_Acessos" "Aprovador"      "Texto"    "Quem aprovou a mao, vindo do cartao do Teams."
Garantir-Campo "Base_Acessos" "AprovadorEmail" "Texto"
Garantir-Campo "Base_Acessos" "AtualizadoEm"   "DataHora"

Definir-Visualizacao "Base_Acessos" @("Title","Nome","Funcional","Nivel","NivelBase","Juncao","Posto","ValidoAte","StatusAcesso","Solicitante","Aprovador")

# ==================================================== 2 · Matriz_Cargo_Nivel =
# O de-para cargo -> perfil. Mora so aqui.
Write-Host ""
Write-Host "2/4  Matriz_Cargo_Nivel" -ForegroundColor White
Garantir-Lista "Matriz_Cargo_Nivel" "De-para entre o cargo do diretorio e o nível de acesso previsto."
Renomear-Title "Matriz_Cargo_Nivel" "Cargo" "O cargo exatamente como vem do diretorio (jobTitle). Confira em ?debug=1."

Garantir-Campo "Matriz_Cargo_Nivel" "Nivel" "Texto"  "DP, DR, GR, GEC, AG, GG, TL, GC, PA ou AS."
Garantir-Campo "Matriz_Cargo_Nivel" "Ativo"  "SimNao"

Definir-Visualizacao "Matriz_Cargo_Nivel" @("Title","Nivel","Ativo")

# ========================================================== 3 · Solicitacoes =
# A trilha de auditoria. Guarda quem pediu e quem recebe, separados.
Write-Host ""
Write-Host "3/4  Solicitacoes" -ForegroundColor White
Garantir-Lista "Solicitacoes" "Trilha de todas as solicitacoes de acesso."
Renomear-Title "Solicitacoes" "Protocolo" "Ex.: AC-20260820-7F3A21"

Garantir-Campo "Solicitacoes" "Destino"            "Texto"    "eu ou outro."
Garantir-Campo "Solicitacoes" "SolicitanteEmail"   "Texto"    "Quem estava logado. A identidade verdadeira."
Garantir-Campo "Solicitacoes" "SolicitanteNome"    "Texto"
Garantir-Campo "Solicitacoes" "SolicitanteCargo"   "Texto"
Garantir-Campo "Solicitacoes" "Nome"               "Texto"    "Quem vai receber o acesso."
Garantir-Campo "Solicitacoes" "Email"              "Texto"
Garantir-Campo "Solicitacoes" "Funcional"          "Texto"
Garantir-Campo "Solicitacoes" "Funcional_L"        "Texto"
Garantir-Campo "Solicitacoes" "Cargo"              "Texto"
Garantir-Campo "Solicitacoes" "Juncao"             "Texto"
Garantir-Campo "Solicitacoes" "Juncao_Nome"        "Texto"
Garantir-Campo "Solicitacoes" "Posto"              "Texto"
Garantir-Campo "Solicitacoes" "Posto_Nome"         "Texto"
Garantir-Campo "Solicitacoes" "CargoDiretorio"     "Texto"    "O cargo lido do diretorio. E ele que a regra usa."
Garantir-Campo "Solicitacoes" "JuncaoDiretorio"    "Texto"
Garantir-Campo "Solicitacoes" "PostoDiretorio"     "Texto"
Garantir-Campo "Solicitacoes" "NivelSolicitado"   "Texto"    "O que a pessoa escolheu, incluindo APOIO_GR e APOIO_AG."
Garantir-Campo "Solicitacoes" "NivelRls"          "Texto"    "O codigo que vai para a base. Apoio vira GR ou AG."
Garantir-Campo "Solicitacoes" "NivelPrevisto"     "Texto"    "O perfil do cargo, pelo de-para."
Garantir-Campo "Solicitacoes" "Direcao"            "Texto"    "igual, acima, abaixo, lateral, apoio, campo-editado, desconhecido ou terceiro."
Garantir-Campo "Solicitacoes" "ValidoAte"          "Data"
Garantir-Campo "Solicitacoes" "Justificativa"      "Longo"
Garantir-Campo "Solicitacoes" "CamposEditados"     "Texto"
Garantir-Campo "Solicitacoes" "EditouCampoDeRegra" "SimNao"   "Mexeu em cargo, juncao ou posto."
Garantir-Campo "Solicitacoes" "TipoAprovacao"      "Texto"    "automatica ou manual."
Garantir-Campo "Solicitacoes" "Status"             "Texto"    "Novo, Aprovado ou Reprovado."
Garantir-Campo "Solicitacoes" "Aprovador"          "Texto"
Garantir-Campo "Solicitacoes" "AprovadorEmail"     "Texto"
Garantir-Campo "Solicitacoes" "MotivoReprova"      "Longo"
Garantir-Campo "Solicitacoes" "DataDecisao"        "DataHora"

Definir-Visualizacao "Solicitacoes" @("Title","Status","Destino","Nome","NivelSolicitado","NivelPrevisto","Direcao","ValidoAte","Aprovador","Created")

# ========================================================== 4 · Portal_Admins =
# Quem enxerga a base completa na tela.
Write-Host ""
Write-Host "4/4  Portal_Admins" -ForegroundColor White
Garantir-Lista "Portal_Admins" "Quem pode ver a base completa no Portal de Acessos."
Renomear-Title "Portal_Admins" "Email" "O e-mail de quem e administrador do portal."
Garantir-Campo "Portal_Admins" "Nome" "Texto"
Definir-Visualizacao "Portal_Admins" @("Title","Nome")

if ($PrimeiroAdmin -ne "") {
    $ja = Get-PnPListItem -List "Portal_Admins" -Query "<View><Query><Where><Eq><FieldRef Name='Title'/><Value Type='Text'>$PrimeiroAdmin</Value></Eq></Where></Query></View>"
    if (-not $ja) {
        Add-PnPListItem -List "Portal_Admins" -Values @{ Title = $PrimeiroAdmin } | Out-Null
        Write-Host "    + $PrimeiroAdmin adicionado como administrador" -ForegroundColor Green
    }
}

# ------------------------------------------------------------------ resumo ---
Write-Host ""
Write-Host "Pronto." -ForegroundColor Green
Write-Host ""
Write-Host "O que fazer agora:" -ForegroundColor White
Write-Host "  1. Abra a pagina com ?debug=1 e confira os campos do diretorio."
Write-Host "  2. So entao preencha a Matriz_Cargo_Nivel com os cargos reais."
Write-Host "  3. Monte o Power App e os fluxos com o passo a passo do DEPLOY.md."
Write-Host ""
Write-Host "Permissoes: quem usa o portal precisa de Contribuir em Solicitacoes." -ForegroundColor Yellow
Write-Host "Nas outras tres, Ler basta - so os fluxos escrevem nelas." -ForegroundColor Yellow
Write-Host ""

Disconnect-PnPOnline
