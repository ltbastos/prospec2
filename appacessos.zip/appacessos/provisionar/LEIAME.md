# Provisionar as listas do SharePoint

Duas formas de criar as quatro listas com todas as colunas de uma vez. Escolha uma.

## Opção A — PowerShell (recomendada)

Precisa instalar um módulo, uma vez só:

```powershell
Install-Module PnP.PowerShell -Scope CurrentUser
```

Depois:

```powershell
.\Criar-Listas.ps1 -Site "https://suaempresa.sharepoint.com/sites/seu-time" -PrimeiroAdmin "voce@empresa.com.br"
```

Abre uma janela de login. É **idempotente**: rodar de novo não duplica nada, só completa o
que faltar. Serve também para corrigir uma lista que ficou incompleta.

## Opção B — Site script (sem instalar nada)

Se a empresa bloquear a galeria do PowerShell. Um administrador do SharePoint roda:

```powershell
Connect-SPOService -Url https://suaempresa-admin.sharepoint.com

$script = Get-Content .\site-script.json -Raw
$s = Add-SPOSiteScript -Title "Portal de Acessos" -Content $script
Add-SPOSiteDesign -Title "Portal de Acessos" -WebTemplate 64 -SiteScripts $s.Id
```

Depois é só aplicar o design ao site do time. O site script não renomeia a coluna `Title`
nem ajusta as visualizações — dá para fazer isso na interface em dois minutos:

| Lista | `Title` vira |
|---|---|
| `Base_Acessos` | E-mail |
| `Matriz_Cargo_Nivel` | Cargo |
| `Solicitacoes` | Protocolo |
| `Portal_Admins` | E-mail |

---

## O que continua sendo manual

O **Power App** e os **três fluxos** são construídos no navegador, com as fórmulas e as ações
do [DEPLOY.md](../DEPLOY.md). Não existe formato de arquivo confiável para gerá-los de fora:
solução exportada do Power Platform é um pacote versionado que quebra entre ambientes, e
gerá-lo à mão daria mais trabalho de depurar do que montar clicando.

As **conexões** (Office 365 Users, SharePoint, Teams, Outlook) você autoriza na primeira vez
que abrir cada um — é um clique em "Permitir", não um arquivo.

## Depois de rodar

1. Ajuste as permissões: quem usa o portal precisa de **Contribuir** em `Solicitacoes`.
   Nas outras três, **Ler** basta.
2. Abra a página com `?debug=1` e confira o mapeamento dos campos do diretório.
3. Só então preencha a `Matriz_Cargo_Nivel` com os cargos reais.
