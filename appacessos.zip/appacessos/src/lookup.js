/* ============================================================================
   Adaptador de BUSCA — encontra a pessoa quando a solicitação é para outro.

   A página não fala com o diretório da Microsoft: ela roda no Apache do XAMPP
   e não tem credencial nenhuma. Então existem três caminhos, e o que vale é o
   MODO_BUSCA em src/config.js.
   ========================================================================== */
(function () {
  'use strict';

  var CFG = window.PORTAL_CONFIG;

  function normalizar(s) {
    return String(s || '')
      .normalize('NFD').replace(new RegExp('[\\u0300-\\u036f]', 'g'), '')
      .toLowerCase().trim();
  }

  /* Encontra por e-mail OU por funcional — nas duas formas dela, com letra e
     com número, porque quem digita usa a que tem na mão. */
  function achar(lista, termo) {
    var alvo = normalizar(termo);
    if (!alvo) return null;

    var alvoFunc = window.Funcional.canonica(termo);

    var achado = null;
    (lista || []).forEach(function (p) {
      if (achado) return;
      if (normalizar(p.email) === alvo) { achado = p; return; }
      if (alvoFunc && (window.Funcional.canonica(p.funcional) === alvoFunc ||
                       window.Funcional.canonica(p.funcionalL) === alvoFunc)) {
        achado = p;
      }
    });
    if (achado) return achado;

    /* Não achou exato? Tenta pelo começo do e-mail, que é como as pessoas
       costumam digitar (só o nome, sem o domínio). */
    (lista || []).forEach(function (p) {
      if (achado) return;
      if (normalizar(p.email).indexOf(alvo + '@') === 0) achado = p;
    });
    return achado;
  }

  function comCampos(p) {
    var pessoa = {};
    CFG.CAMPOS.forEach(function (c) { pessoa[c.chave] = p[c.chave] || ''; });
    return pessoa;
  }

  window.Lookup = {

    /* Devolve:
         { ok: true,  pessoa: {...} }
         { ok: false, motivo: 'nao-encontrado' | 'erro', detalhe }
         { ok: false, motivo: 'redirecionando' }   -> a tela nem volta

       No modo 'powerapps' a busca é uma ida e volta: a página guarda o estado
       do formulário, manda o usuário para a tela Buscar do Power App (que é
       quem consegue consultar o diretório) e a pessoa volta pela URL. */
    buscar: function (termo, estadoParaGuardar) {
      var modo = CFG.MODO_BUSCA;

      if (modo === 'mock' || modo === 'local') {
        var url = modo === 'mock'
          ? CFG.BUSCA_ARQUIVO
          : 'api/buscar.php?termo=' + encodeURIComponent(termo);

        return fetch(url, { cache: 'no-store' })
          .then(function (r) { return r.json(); })
          .then(function (d) {
            /* O PHP já devolve a pessoa; o arquivo mock devolve a lista toda. */
            var p = Array.isArray(d) ? achar(d, termo) : (d && d.pessoa);
            return p ? { ok: true, pessoa: comCampos(p) }
                     : { ok: false, motivo: 'nao-encontrado' };
          })
          .catch(function (e) {
            return { ok: false, motivo: 'erro', detalhe: e.message };
          });
      }

      if (modo === 'powerapps') {
        try {
          sessionStorage.setItem('portal.rascunho',
                                 JSON.stringify(estadoParaGuardar || {}));
        } catch (e) { /* navegador sem sessionStorage: segue sem guardar */ }

        var sep = CFG.POWERAPP_URL.indexOf('?') === -1 ? '?' : '&';
        window.location.href = CFG.POWERAPP_URL + sep +
                               'tela=buscar&termo=' + encodeURIComponent(termo);
        return Promise.resolve({ ok: false, motivo: 'redirecionando' });
      }

      return Promise.resolve({
        ok: false, motivo: 'erro',
        detalhe: 'MODO_BUSCA desconhecido em src/config.js: ' + modo
      });
    },

    /* Lê o resultado que o Power App devolveu na URL: ?achou=1&nome=...
       Devolve null quando não é uma volta de busca. */
    daVolta: function (q) {
      if (q.get('achou') === null) return null;

      if (q.get('achou') !== '1') {
        return { ok: false, motivo: 'nao-encontrado', termo: q.get('termo') || '' };
      }

      var p = {};
      CFG.CAMPOS.forEach(function (c) { p[c.chave] = q.get(c.chave) || ''; });
      return { ok: true, pessoa: p };
    },

    /* Situação de quem está logado: Aprovado, Pendente ou Sem Acesso.

       Quando a pessoa JÁ ESTÁ na base, vem junto a linha dela — e é dela que
       o formulário se preenche, não mais do diretório. O que aparece na tela
       passa a ser o que vale hoje, e uma alteração atualiza a mesma linha.

       Em produção quem responde isso é o Power App (que lê as duas listas do
       SharePoint) mandando &situacao= e os campos da linha na URL. */
    situacao: function (pessoa, q) {
      if (CFG.MODO === 'powerapps') {
        var s = q && q.get('situacao');
        if (!s) return Promise.resolve({ ok: true, situacao: 'Sem Acesso', linha: null });

        var linha = null;
        if (q.get('naBase') === '1') {
          linha = { funcional: q.get('funcional') || '' };
          CFG.CAMPOS.forEach(function (c) { linha[c.chave] = q.get(c.chave) || ''; });
          linha.nivel = q.get('nivelAtual') || '';
          linha.validoAte = q.get('ate') || '';
        }
        return Promise.resolve({
          ok: true, situacao: s, linha: linha, protocolo: q.get('protocolo') || ''
        });
      }

      var url = CFG.SITUACAO_URL +
                '?funcional=' + encodeURIComponent(pessoa.funcional || '') +
                '&email=' + encodeURIComponent(pessoa.email || '');

      return fetch(url, { cache: 'no-store' })
        .then(function (r) { return r.json(); })
        .catch(function () { return { ok: true, situacao: 'Sem Acesso', linha: null }; });
    },

    /* Recupera o rascunho guardado antes da ida ao Power App. */
    rascunho: function () {
      try {
        var s = sessionStorage.getItem('portal.rascunho');
        sessionStorage.removeItem('portal.rascunho');
        return s ? JSON.parse(s) : null;
      } catch (e) { return null; }
    }
  };
})();
