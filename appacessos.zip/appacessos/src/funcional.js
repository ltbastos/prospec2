/* ============================================================================
   A funcional tem duas formas, e elas são a MESMA pessoa:

       com letra   I437643
       com número  9437643

   A primeira posição troca de letra para dígito pela ordem do alfabeto:
   A=1, B=2, C=3 … I=9. O resto do código nunca muda.

   Isso importa por um motivo só: se as duas formas circulassem soltas, a
   mesma pessoa poderia virar duas linhas na base. Toda comparação passa pela
   forma NUMÉRICA, que é a canônica.

   O mesmo par de funções existe em api/comum.php, para o servidor decidir
   igual à tela.
   ========================================================================== */
(function () {
  'use strict';

  /* A=1 … I=9. Só vai até o 9 porque a funcional tem largura fixa: trocar a
     letra por dois dígitos mudaria o tamanho do código. Se algum dia
     aparecerem letras acima de I, é aqui que se resolve. */
  var LETRAS = 'ABCDEFGHI';

  function limpar(f) {
    return String(f || '').trim().toUpperCase();
  }

  window.Funcional = {

    /* I437643 -> 9437643. Já numérica, devolve como está. */
    paraNumero: function (f) {
      var v = limpar(f);
      if (!v) return '';
      var i = LETRAS.indexOf(v.charAt(0));
      return i === -1 ? v : String(i + 1) + v.slice(1);
    },

    /* 9437643 -> I437643. Já com letra, devolve como está. */
    paraLetra: function (f) {
      var v = limpar(f);
      if (!v) return '';
      var d = parseInt(v.charAt(0), 10);
      if (isNaN(d) || d < 1 || d > LETRAS.length) return v;
      return LETRAS.charAt(d - 1) + v.slice(1);
    },

    /* A forma que vale para comparar duas funcionais. */
    canonica: function (f) {
      return window.Funcional.paraNumero(f);
    },

    /* As duas formas se referem à mesma pessoa? */
    mesma: function (a, b) {
      var x = window.Funcional.canonica(a);
      var y = window.Funcional.canonica(b);
      return x !== '' && x === y;
    }
  };
})();
