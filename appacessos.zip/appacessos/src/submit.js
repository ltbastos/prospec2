/* ============================================================================
   Adaptador de SAIDA - leva a solicitacao para onde ela precisa chegar.
   ========================================================================== */
(function () {
  'use strict';

  var CFG = window.PORTAL_CONFIG;

  /* Grava uma copia local em data/. Serve de trilha para depurar no XAMPP.
     Nunca derruba o envio: se o PHP falhar, seguimos em frente. */
  function registrarLocal(payload) {
    return fetch('api/submit.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
      .then(function (r) { return r.json(); })
      .catch(function () { return null; });
  }

  /* Monta a query string do retorno. Um parametro por campo porque o Power Fx
     le a URL com Param() e nao sabe decodificar base64. */
  function queryDoRetorno(payload, protocolo) {
    var partes = [
      'tela=retorno',
      'protocolo=' + encodeURIComponent(protocolo || ''),
      'destino='   + encodeURIComponent(payload.destino || 'eu'),
      'perfil='    + encodeURIComponent(payload.perfilSolicitado || ''),
      'perfilRls=' + encodeURIComponent(payload.perfilRls || payload.perfilSolicitado || ''),
      'previsto='  + encodeURIComponent(payload.perfilPrevisto || ''),
      'dir='       + encodeURIComponent(payload.direcao || ''),
      'ate='       + encodeURIComponent(payload.validoAte || ''),
      'just='      + encodeURIComponent(payload.justificativa || ''),
      'edit='      + encodeURIComponent((payload.camposEditados || []).join(','))
    ];
    Object.keys(payload.perfil || {}).forEach(function (k) {
      partes.push(k + '=' + encodeURIComponent(payload.perfil[k] || ''));
    });
    return partes.join('&');
  }

  window.Submit = {

    /* Devolve { ok: true, protocolo } ou { ok: false, erro } */
    enviar: function (payload) {
      var modo = CFG.MODO;

      if (modo === 'mock') {
        return registrarLocal(payload).then(function (r) {
          if (r && r.ok) return { ok: true, protocolo: r.protocolo };
          return { ok: false, erro: (r && r.erro) || 'O PHP nao respondeu. O Apache esta no ar?' };
        });
      }

      if (modo === 'powerapps') {
        /* Devolve o controle ao Power App, que le o payload, RELE o perfil do
           usuario logado e grava no SharePoint. O que vai na URL e so o que o
           usuario digitou - a identidade verdadeira quem define e o Power App. */
        return registrarLocal(payload).then(function (r) {
          var protocolo = (r && r.protocolo) || '';
          var sep = CFG.POWERAPP_URL.indexOf('?') === -1 ? '?' : '&';
          window.location.href = CFG.POWERAPP_URL + sep +
                                 queryDoRetorno(payload, protocolo);
          return { ok: true, protocolo: protocolo, redirecionando: true };
        });
      }

      if (modo === 'http') {
        if (!CFG.FLOW_URL) {
          return Promise.resolve({ ok: false, erro: 'FLOW_URL vazio em src/config.js.' });
        }
        return fetch(CFG.FLOW_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        })
          .then(function (r) { return r.json(); })
          .then(function (r) { return { ok: true, protocolo: r.protocolo || '' }; })
          .catch(function (e) { return { ok: false, erro: e.message }; });
      }

      return Promise.resolve({ ok: false, erro: 'MODO desconhecido: ' + modo });
    }
  };
})();
