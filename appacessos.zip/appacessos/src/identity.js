/* ============================================================================
   Adaptador de ENTRADA - descobre quem e o usuario.
   Trocar de ambiente = trocar PORTAL_CONFIG.MODO. Nada aqui precisa mudar.
   ========================================================================== */
(function () {
  'use strict';

  var CFG = window.PORTAL_CONFIG;

  /* Le os parametros que o Power App colocou na URL:
       ?nome=...&email=...&cargo=...&juncao=...&posto=...&segmento=...

     Um parametro por campo, de proposito: o Power Fx nao tem funcao para
     codificar nem decodificar base64, entao um payload empacotado obrigaria
     a gambiarras dos dois lados. Assim o Power App monta a URL com EncodeUrl()
     e le de volta com Param(), que e o caminho suportado. */
  function daUrl() {
    var q = new URLSearchParams(window.location.search);
    var bruto = {};
    var achou = false;

    CFG.CAMPOS.forEach(function (c) {
      var v = q.get(c.chave);
      if (v !== null) { bruto[c.chave] = v; achou = true; }
    });
    if (!achou) return null;

    var perfil = {};
    CFG.CAMPOS.forEach(function (c) { perfil[c.chave] = bruto[c.chave] || ''; });
    if (!perfil.email) return null;

    /* O Power App tambem manda o perfil previsto para o cargo, lido direto da
       lista Matriz_Cargo_Perfil. Assim o de-para mora num lugar so - o
       SharePoint - e a tela nunca avisa uma coisa e o fluxo decide outra.
       Vem pelo cargo do DIRETORIO, nao pelo que o usuario digita na tela. */
    return {
      perfil: perfil,
      bruto: bruto,
      perfilPrevisto: q.get('previsto') || '',
      /* Quem e administrador quem decide e o Power App, consultando a lista
         Portal_Admins do SharePoint. A pagina so obedece ao que chegou. */
      adm: q.get('adm') === '1'
    };
  }

  function buscarJson(url) {
    return fetch(url, { cache: 'no-store' }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status + ' em ' + url);
      return r.json();
    });
  }

  window.Identity = {

    /* Resolve a identidade. Sempre devolve:
         { ok: true,  perfil: {...}, bruto: {...} }
         { ok: false, motivo: 'sem-identidade' | 'nao-implementado', detalhe }  */
    resolver: function () {
      var modo = CFG.MODO;

      if (modo === 'mock') {
        return buscarJson(CFG.PERFIL_MOCK_URL).then(function (d) {
          var perfil = {};
          CFG.CAMPOS.forEach(function (c) { perfil[c.chave] = d[c.chave] || ''; });
          return { ok: true, perfil: perfil, bruto: d._bruto || d, adm: CFG.ADM_MOCK === true };
        }).catch(function (e) {
          return { ok: false, motivo: 'sem-identidade', detalhe: e.message };
        });
      }

      if (modo === 'powerapps') {
        var d = daUrl();
        return Promise.resolve(
          d ? { ok: true, perfil: d.perfil, bruto: d.bruto,
                perfilPrevisto: d.perfilPrevisto, adm: d.adm }
            : { ok: false, motivo: 'sem-identidade' }
        );
      }

      if (modo === 'msal') {
        /* Caminho de upgrade, ainda nao implementado. Exige HTTPS na maquina
           e um registro de aplicativo no Entra ID. Ver DEPLOY.md. */
        return Promise.resolve({
          ok: false, motivo: 'nao-implementado',
          detalhe: 'O modo msal exige HTTPS e app registrado no Entra ID.'
        });
      }

      return Promise.resolve({
        ok: false, motivo: 'nao-implementado',
        detalhe: 'MODO desconhecido em src/config.js: ' + modo
      });
    }
  };
})();
