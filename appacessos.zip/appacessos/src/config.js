/* ============================================================================
   Portal de Acessos (PJ, MIS e DEO) — configuração
   Este é o ÚNICO arquivo que você precisa editar ao levar para o trabalho.
   Os perfis ficam em perfis.json, porque o PHP também precisa lê-los.
   ========================================================================== */
window.PORTAL_CONFIG = {

  /* --------------------------------------------------------------------------
     MODO: define de onde vem a identidade do usuário e para onde vai o envio.

       'mock'      desenvolvimento local. Lê mock/perfil.json e grava em data/.
       'powerapps' produção. Lê os dados da URL enviada pelo Power App e
                   devolve o envio para o Power App gravar no SharePoint.
       'msal'      upgrade futuro (exige HTTPS na máquina + app no Entra ID).
                   Não implementado.

     Lembre: a página NUNCA descobre quem é o usuário sozinha. Ela roda no
     Apache do XAMPP, então qualquer tentativa de ler "o usuário logado" no
     servidor devolveria sempre o dono da máquina que hospeda. Quem autentica
     é o Power App, e é de lá que a identidade chega.
     ------------------------------------------------------------------------ */
  MODO: 'mock',

  /* Nome da ferramenta. MARCA vai no cabeçalho, MARCA_SUB no chip ao lado. */
  MARCA: 'Portal de Acessos',
  MARCA_SUB: 'PJ · MIS · DEO',

  /* --------------------------------------------------------------------------
     Link do Power App, usado quando MODO = 'powerapps'.
     Copie de: Power Apps > seu app > ... > Detalhes > URL da Web.
     ------------------------------------------------------------------------ */
  POWERAPP_URL: 'https://apps.powerapps.com/play/e/COLE-O-ENVIRONMENT-ID/a/COLE-O-APP-ID',

  /* Endpoint do fluxo HTTP. Só usado se um dia mudar para MODO 'http'. */
  FLOW_URL: '',

  /* --------------------------------------------------------------------------
     BUSCA de pessoa, usada quando a solicitação é para outra pessoa.

       'mock'      procura em mock/colaboradores.json.
       'powerapps' manda para a tela Buscar do Power App, que consulta o
                   diretório com Office365Users e devolve a pessoa na URL.
       'local'     procura em uma base local servida pelo próprio XAMPP
                   (api/buscar.php lendo BUSCA_ARQUIVO). Útil quando existe
                   um extrato do RH atualizado periodicamente na máquina.
     ------------------------------------------------------------------------ */
  MODO_BUSCA: 'mock',
  BUSCA_ARQUIVO: 'mock/colaboradores.json',

  /* --------------------------------------------------------------------------
     Mapeamento dos campos do perfil Microsoft 365 — a mesma base que alimenta
     o cartão de contato do Outlook.
     ATENÇÃO: Junção e Posto NÃO existem com esses nomes no Entra ID.
     Abra a página com ?debug=1 no trabalho para ver o perfil real e ajustar.
     ------------------------------------------------------------------------ */
  MAPA_PERFIL: {
    nome:      'displayName',
    email:     'mail',
    funcional: 'employeeId',
    funcionalL: '',
    juncao:    'department',
    juncaoNome: '',
    cargo:     'jobTitle',
    posto:     'officeLocation',
    postoNome: ''
  },

  /* --------------------------------------------------------------------------
     Campos do formulário, na ordem em que aparecem.
     span: 1 = meia largura, 2 = largura inteira.
     ------------------------------------------------------------------------ */
  /* Junção e Posto guardam SÓ O NÚMERO: é o que o RLS compara. O nome mora
     num campo separado, para leitura — mexer nele não altera a regra. */
  CAMPOS: [
    { chave: 'nome',       rotulo: 'Nome completo',     span: 2, tipo: 'text',  icone: 'i-user',      obrigatorio: true },
    { chave: 'email',      rotulo: 'E-mail',            span: 2, tipo: 'email', icone: 'i-mail',      obrigatorio: true },
    { chave: 'funcional',  rotulo: 'Funcional',         span: 1, tipo: 'text',  icone: 'i-hash'      },
    { chave: 'funcionalL', rotulo: 'Funcional (letra)', span: 1, tipo: 'text',  icone: 'i-hash'      },
    { chave: 'cargo',      rotulo: 'Cargo',             span: 2, tipo: 'text',  icone: 'i-briefcase', obrigatorio: true },
    { chave: 'juncao',     rotulo: 'Junção',            span: 1, tipo: 'text',  icone: 'i-bank',      soNumero: true, obrigatorio: true },
    { chave: 'juncaoNome', rotulo: 'Nome da junção',    span: 1, tipo: 'text',  icone: 'i-bank'      },
    { chave: 'posto',      rotulo: 'Posto',             span: 1, tipo: 'text',  icone: 'i-pin',       soNumero: true },
    { chave: 'postoNome',  rotulo: 'Nome do posto',     span: 1, tipo: 'text',  icone: 'i-pin'       }
  ],

  /* Campos que a regra usa. Mexer em qualquer um deles joga a solicitação
     para aprovação manual, mesmo que o nível escolhido bata com o cargo. */
  CAMPOS_DE_REGRA: ['cargo', 'juncao', 'posto'],

  /* Nome do time que analisa as solicitações manuais. Aparece nos avisos. */
  TIME_APROVADOR: 'time de governança de acessos',

  /* Catálogo de perfis, do mais amplo para o mais restrito.
     Compartilhado com o api/submit.php — não duplique esta lista. */
  PERFIS_URL: 'perfis.json',

  /* De-para Cargo -> Nível. Em produção o Power App lê a lista do SharePoint
     e manda o nível esperado na URL; este arquivo é o espelho local. */
  MATRIZ_URL: 'mock/matriz.json',

  /* Perfil fictício usado quando MODO = 'mock'. */
  PERFIL_MOCK_URL: 'mock/perfil.json',

  /* Quantos caracteres a justificativa precisa ter quando o nível diverge. */
  MIN_JUSTIFICATIVA: 20,

  /* Prazo máximo de um nível elevado, em meses. Vale também no PHP. */
  MAX_MESES_ELEVACAO: 6,

  /* --------------------------------------------------------------------------
     BASE COMPLETA — a visão de administrador.

     Quem é administrador NÃO se decide aqui: em produção o Power App consulta
     a lista Portal_Admins do SharePoint e manda &adm=1 na URL. ADM_MOCK só
     existe para você ver a tela no desenvolvimento local.

     COLUNAS: troque por completo quando tiver os nomes reais da tabela.
       chave    = nome do campo no JSON que api/base.php devolve
       rotulo   = o que aparece no cabeçalho
       tipo     = 'texto' | 'data' | 'perfil' | 'estado'
       busca    = entra na busca livre da tela
     ------------------------------------------------------------------------ */
  ADM_MOCK: true,
  BASE_URL: 'api/base.php',
  SITUACAO_URL: 'api/situacao.php',

  /* Últimas solicitações do usuário, mostradas na primeira etapa. */
  MINHAS_URL: 'api/minhas.php',
  MINHAS_QUANTAS: 4,

  COLUNAS_BASE: [
    { chave: 'situacao',     rotulo: 'Situação',    tipo: 'situacao', busca: false },
    { chave: 'nome',         rotulo: 'Nome',        tipo: 'texto',    busca: true  },
    { chave: 'funcional',    rotulo: 'Funcional',   tipo: 'texto',    busca: true  },
    { chave: 'funcionalL',   rotulo: 'Func. letra', tipo: 'texto',    busca: true,  secundaria: true },
    { chave: 'email',        rotulo: 'E-mail',      tipo: 'texto',    busca: true  },
    { chave: 'nivel',        rotulo: 'Nível',       tipo: 'perfil',   busca: true  },
    { chave: 'juncao',       rotulo: 'Junção',      tipo: 'texto',    busca: true  },
    { chave: 'juncaoNome',   rotulo: 'Nome junção', tipo: 'texto',    busca: true,  secundaria: true },
    { chave: 'posto',        rotulo: 'Posto',       tipo: 'texto',    busca: true  },
    { chave: 'postoNome',    rotulo: 'Nome posto',  tipo: 'texto',    busca: true,  secundaria: true },
    { chave: 'validoAte',    rotulo: 'Válido até',  tipo: 'data',     busca: false },
    { chave: 'origem',       rotulo: 'Origem',      tipo: 'texto',    busca: false, secundaria: true },
    { chave: 'solicitante',  rotulo: 'Solicitante', tipo: 'pessoa',   busca: true  },
    { chave: 'aprovador',    rotulo: 'Aprovador',   tipo: 'pessoa',   busca: true, vazio: 'sistema' }
  ],

  /* As três situações possíveis. Elas descrevem a PESSOA, não a linha:
       Aprovado   já está na base de acessos
       Pendente   tem solicitação esperando a governança
       Sem Acesso não está na base e não tem nada esperando           */
  SITUACOES: [
    { v: 'Aprovado',   icone: 'i-check-circle', cor: 'ok'    },
    { v: 'Pendente',   icone: 'i-clock',        cor: 'aviso' },
    { v: 'Sem Acesso', icone: 'i-x',            cor: 'neutro' },
    { v: 'Reprovado',  icone: 'i-x',            cor: 'erro'   }
  ],

  /* Quantas linhas a tela carrega por vez. */
  BASE_PAGINA: 25
};
