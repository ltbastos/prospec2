<?php
/* ============================================================================
   Portal de Acessos — situação de uma pessoa.

     Aprovado   : já está na base de acessos, com acesso ativo.
     Pendente   : tem solicitação aguardando aprovação manual.
     Sem Acesso : não está na base e não tem nada aguardando.

   Quando a pessoa JÁ ESTÁ na base, devolve a linha dela: é dela que a tela
   preenche o formulário, e não mais do diretório. Assim o que aparece é o que
   vale hoje, e uma alteração vira atualização da mesma linha.

   A chave de unicidade é a FUNCIONAL. Só cai para o e-mail quando a
   funcional está em branco.

   Compativel com PHP 5.6+.
   ========================================================================== */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

require __DIR__ . '/comum.php';

$funcional = isset($_GET['funcional']) ? trim($_GET['funcional']) : '';
$email     = isset($_GET['email'])     ? trim($_GET['email'])     : '';

if ($funcional === '' && $email === '') {
    responder(array('ok' => false, 'erro' => 'Informe a funcional ou o e-mail.'), 400);
}

$chave = chaveDe(array('funcional' => $funcional, 'email' => $email));

/* ------------------------------------------------------- já está na base? -- */
$linha = null;
foreach (lerBase() as $l) {
    if (chaveDe($l) !== $chave) { continue; }
    if (normalizar(valor($l, 'status')) === 'revogado') { continue; }
    $linha = $l;
    break;
}

/* ------------------------------------------ tem algo esperando decisão? ---- */
$pendente = null;
foreach (lerPendentes() as $p) {
    if (chaveDe($p['pessoa']) === $chave) { $pendente = $p; break; }
}

if ($pendente !== null) {
    responder(array(
        'ok'        => true,
        'situacao'  => 'Pendente',
        'protocolo' => $pendente['protocolo'],
        'pedidoEm'  => $pendente['recebidoEm'],
        'perfilPedido' => $pendente['perfilPedido'],
        'linha'     => $linha
    ), 200);
}

if ($linha !== null) {
    responder(array('ok' => true, 'situacao' => 'Aprovado', 'linha' => $linha), 200);
}

responder(array('ok' => true, 'situacao' => 'Sem Acesso', 'linha' => null), 200);
