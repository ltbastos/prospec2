<?php
/* ============================================================================
   Portal de Acessos — busca de pessoa numa base local (MODO_BUSCA = 'local').

   Serve para quando existe na máquina do XAMPP um extrato de colaboradores
   atualizado periodicamente. Procura por e-mail ou por funcional, aceitando
   as duas formas dela: com letra (I437643) e com número (9437643).

   Em produção com MODO_BUSCA = 'powerapps' este arquivo nem é chamado: quem
   consulta o diretório é o Power App, que é o único autenticado.

   Compativel com PHP 5.6+.
   ========================================================================== */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

require __DIR__ . '/comum.php';

$termo = isset($_GET['termo']) ? trim($_GET['termo']) : '';
if ($termo === '') {
    responder(array('ok' => false, 'erro' => 'Informe o e-mail ou a funcional.'), 400);
}

/* A mesma ordem de procura da base: o primeiro que existir vence. */
$candidatos = array(
    __DIR__ . '/../data/colaboradores.json',
    __DIR__ . '/../data/colaboradores.csv',
    __DIR__ . '/../mock/colaboradores.json'
);

$pessoas = array();
foreach ($candidatos as $caminho) {
    if (!is_readable($caminho)) { continue; }
    if (substr($caminho, -4) === '.csv') {
        $pessoas = lerCsv($caminho);
    } else {
        $lido = json_decode(file_get_contents($caminho), true);
        $pessoas = is_array($lido) ? $lido : array();
    }
    break;
}

if (!count($pessoas)) {
    responder(array('ok' => false, 'erro' => 'Nenhuma base de colaboradores encontrada.'), 404);
}

$alvo     = normalizar($termo);
$alvoFunc = funcionalCanonica($termo);
$achado   = null;

/* 1 · e-mail exato, ou funcional em qualquer uma das duas formas */
foreach ($pessoas as $p) {
    if (normalizar(valor($p, 'email')) === $alvo) { $achado = $p; break; }

    if ($alvoFunc !== '') {
        if (funcionalCanonica(valor($p, 'funcional'))  === $alvoFunc ||
            funcionalCanonica(valor($p, 'funcionalL')) === $alvoFunc) {
            $achado = $p;
            break;
        }
    }
}

/* 2 · só a parte antes do @, que é como as pessoas costumam digitar */
if ($achado === null) {
    foreach ($pessoas as $p) {
        if (strpos(normalizar(valor($p, 'email')), $alvo . '@') === 0) {
            $achado = $p;
            break;
        }
    }
}

if ($achado === null) {
    responder(array('ok' => false, 'motivo' => 'nao-encontrado', 'termo' => $termo), 200);
}

/* Devolve sempre as duas formas preenchidas, mesmo que a base só tenha uma. */
$f = valor($achado, 'funcional');
if ($f === '') { $f = valor($achado, 'funcionalL'); }
$achado['funcional']  = funcionalParaNumero($f);
$achado['funcionalL'] = funcionalParaLetra($f);

responder(array('ok' => true, 'pessoa' => $achado), 200);
