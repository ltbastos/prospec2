<?php
/* ============================================================================
   Portal de Acessos — funções compartilhadas pelos endpoints.

   A chave de unicidade da base é a FUNCIONAL. Ela é quem garante que nunca
   existam duas linhas para a mesma pessoa. Só cai para o e-mail quando a
   funcional está em branco.

   Compativel com PHP 5.6+.
   ========================================================================== */

if (!function_exists('responder')) {
    function responder($dados, $status) {
        http_response_code($status);
        echo json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}

function normalizar($s) {
    $s = function_exists('mb_strtolower')
        ? mb_strtolower(trim((string) $s), 'UTF-8')
        : strtolower(trim((string) $s));
    $com = array('á','à','ã','â','ä','é','ê','í','î','ó','ô','õ','ö','ú','û','ç');
    $sem = array('a','a','a','a','a','e','e','i','i','o','o','o','o','u','u','c');
    return str_replace($com, $sem, $s);
}

function valor($linha, $chave) {
    return isset($linha[$chave]) ? $linha[$chave] : '';
}

/* Um segredo de servidor, lido de config/segredos.php quando esse arquivo
   existe. Devolve '' quando não existe ou não está preenchido — nenhum
   endpoint depende disso hoje.

   Segredo mora aqui e nunca em src/config.js: aquele arquivo é baixado pelo
   navegador de todo mundo que abre a página. Ver CREDENCIAIS.md. */
function segredo($chave, $padrao = '') {
    static $cofre = null;

    if ($cofre === null) {
        $caminho = __DIR__ . '/../config/segredos.php';
        $cofre = is_readable($caminho) ? include $caminho : array();
        if (!is_array($cofre)) { $cofre = array(); }
    }
    return (isset($cofre[$chave]) && $cofre[$chave] !== '') ? $cofre[$chave] : $padrao;
}

/* --------------------------------------------------------- a funcional ---- */
/* Duas formas, a mesma pessoa: com letra (I437643) e com número (9437643).
   A primeira posição troca pela ordem do alfabeto, A=1 … I=9. Só vai até o 9
   porque a funcional tem largura fixa. Espelha src/funcional.js — se mudar
   aqui, mude lá. */
define('FUNCIONAL_LETRAS', 'ABCDEFGHI');

function funcionalParaNumero($f) {
    $v = strtoupper(trim((string) $f));
    if ($v === '') { return ''; }
    $i = strpos(FUNCIONAL_LETRAS, substr($v, 0, 1));
    return ($i === false) ? $v : ((string) ($i + 1)) . substr($v, 1);
}

function funcionalParaLetra($f) {
    $v = strtoupper(trim((string) $f));
    if ($v === '') { return ''; }
    $d = substr($v, 0, 1);
    if (!ctype_digit($d) || (int) $d < 1 || (int) $d > strlen(FUNCIONAL_LETRAS)) {
        return $v;
    }
    return substr(FUNCIONAL_LETRAS, ((int) $d) - 1, 1) . substr($v, 1);
}

/* A forma que vale para comparar duas funcionais. */
function funcionalCanonica($f) {
    return funcionalParaNumero($f);
}

/* A identidade de uma linha: a funcional na forma canônica — assim I437643 e
   9437643 nunca viram duas pessoas. Só cai no e-mail quando não há funcional. */
function chaveDe($linha) {
    $f = funcionalCanonica(valor($linha, 'funcional'));
    if ($f === '') { $f = funcionalCanonica(valor($linha, 'funcionalL')); }
    if ($f !== '') { return 'f:' . normalizar($f); }

    return 'e:' . normalizar(valor($linha, 'email'));
}

function lerCsv($caminho) {
    $linhas = array();
    $fh = fopen($caminho, 'r');
    if (!$fh) { return $linhas; }

    $primeira = fgets($fh);
    if ($primeira === false) { fclose($fh); return $linhas; }
    $sep = (substr_count($primeira, ';') > substr_count($primeira, ',')) ? ';' : ',';

    $cab = str_getcsv(rtrim($primeira, "\r\n"), $sep);
    foreach ($cab as $i => $c) { $cab[$i] = trim(str_replace("\xEF\xBB\xBF", '', $c)); }

    while (($cols = fgetcsv($fh, 0, $sep)) !== false) {
        if (count($cols) === 1 && trim($cols[0]) === '') { continue; }
        $linha = array();
        foreach ($cab as $i => $nome) { $linha[$nome] = isset($cols[$i]) ? $cols[$i] : ''; }
        $linhas[] = $linha;
    }
    fclose($fh);
    return $linhas;
}

/* A base de acessos. Em produção o item 1 ou 2 é gerado por um fluxo que
   exporta a lista Base_Acessos; o item 3 é o exemplo que vem no projeto. */
function lerBase(&$origem = null) {
    $candidatos = array(
        __DIR__ . '/../data/base.json',
        __DIR__ . '/../data/base.csv',
        __DIR__ . '/../mock/base.json'
    );

    foreach ($candidatos as $caminho) {
        if (!is_readable($caminho)) { continue; }
        $origem = basename(dirname($caminho)) . '/' . basename($caminho);

        if (substr($caminho, -4) === '.csv') { return lerCsv($caminho); }
        $lido = json_decode(file_get_contents($caminho), true);
        return is_array($lido) ? $lido : array();
    }
    $origem = '';
    return array();
}

/* As solicitações que ainda esperam decisão manual.
   No desenvolvimento local elas são os arquivos que api/submit.php grava em
   data/. Em produção quem responde isso é o Power App, lendo a lista
   Solicitacoes com Status "Novo" — a página nem chama este endpoint. */
function lerPendentes() {
    $pasta = __DIR__ . '/../data';
    $saida = array();
    if (!is_dir($pasta)) { return $saida; }

    $arquivos = glob($pasta . '/AC-*.json');
    if (!is_array($arquivos)) { return $saida; }

    rsort($arquivos);

    foreach ($arquivos as $arq) {
        $r = json_decode(file_get_contents($arq), true);
        if (!is_array($r)) { continue; }
        if (valor($r, 'tipoAprovacao') !== 'manual') { continue; }
        if (valor($r, 'decidido') === true || valor($r, 'decidido') === 'true') { continue; }

        $sol = isset($r['solicitacao']) ? $r['solicitacao'] : array();
        $pes = isset($sol['perfil']) && is_array($sol['perfil']) ? $sol['perfil'] : array();

        $saida[] = array(
            'protocolo'    => valor($r, 'protocolo'),
            'recebidoEm'   => valor($r, 'recebidoEm'),
            'perfilPedido' => valor($r, 'perfilPedido'),
            'validoAte'    => valor($r, 'validoAte'),
            'destino'      => valor($r, 'destino'),
            'solicitante'  => isset($sol['solicitante']) && is_array($sol['solicitante'])
                                  ? $sol['solicitante'] : $pes,
            'pessoa'       => $pes
        );
    }
    return $saida;
}
