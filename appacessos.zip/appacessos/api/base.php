<?php
/* ============================================================================
   Portal de Acessos — a base completa, para a visão de administrador.

   A tabela junta duas coisas numa lista só, com UMA linha por funcional:
     · quem está na base de acessos          -> situação "Aprovado"
     · quem tem solicitação esperando análise -> situação "Pendente"

   Quem não está em lugar nenhum tem situação "Sem Acesso" — e por definição
   não aparece aqui, porque não existe registro dele para listar.

   Busca, filtro, ordenação e paginação acontecem no servidor, para a tela
   nunca carregar a base inteira de uma vez.

   Compativel com PHP 5.6+.
   ========================================================================== */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

require __DIR__ . '/comum.php';

/* --------------------------------------------------------------- montar ---- */
$origem = '';
$linhas = lerBase($origem);

if ($origem === '') {
    responder(array(
        'ok'   => false,
        'erro' => 'Nenhuma base encontrada. Esperado data/base.json, data/base.csv ou mock/base.json.'
    ), 404);
}

/* Indexa por funcional para garantir uma linha só por pessoa. */
$porChave = array();
foreach ($linhas as $l) {
    $l['situacao'] = (normalizar(valor($l, 'status')) === 'revogado')
        ? 'Sem Acesso'
        : 'Aprovado';
    $porChave[chaveDe($l)] = $l;
}

/* As pendências entram por cima: quem espera decisão aparece como Pendente,
   mantendo o perfil que vale hoje e mostrando o que foi pedido. */
foreach (lerPendentes() as $p) {
    $chave = chaveDe($p['pessoa']);
    $base  = isset($porChave[$chave]) ? $porChave[$chave] : array();

    $porChave[$chave] = array_merge(
        array(
            'email'        => valor($p['pessoa'], 'email'),
            'nome'         => valor($p['pessoa'], 'nome'),
            'funcional'    => valor($p['pessoa'], 'funcional'),
            'nivel'        => '',
            'nivelBase'    => '',
            'juncao'       => valor($p['pessoa'], 'juncao'),
            'posto'        => valor($p['pessoa'], 'posto'),
            'validoAte'    => '',
            'origem'       => 'manual',
            'solicitante'      => valor($p['solicitante'], 'nome'),
            'solicitanteEmail' => valor($p['solicitante'], 'email'),
            'aprovador'      => '',
            'aprovadorEmail' => '',
            'status'       => '',
            'atualizadoEm' => substr(valor($p, 'recebidoEm'), 0, 10)
        ),
        $base,
        array(
            'situacao'     => 'Pendente',
            'perfilPedido' => valor($p, 'perfilPedido'),
            'protocolo'    => valor($p, 'protocolo')
        )
    );
}

$linhas = array_values($porChave);

/* -------------------------------------------------------------- filtrar ---- */
$busca    = isset($_GET['q'])        ? trim($_GET['q'])        : '';
$situacao = isset($_GET['situacao']) ? trim($_GET['situacao']) : '';
$campos   = isset($_GET['campos'])   ? explode(',', $_GET['campos']) : array();

if ($busca !== '' || $situacao !== '') {
    $alvo = normalizar($busca);
    $filtradas = array();

    foreach ($linhas as $l) {
        if ($situacao !== '' && normalizar(valor($l, 'situacao')) !== normalizar($situacao)) {
            continue;
        }
        if ($alvo === '') { $filtradas[] = $l; continue; }

        $bateu = false;
        foreach ($l as $chave => $v) {
            if (count($campos) && !in_array($chave, $campos, true)) { continue; }
            if (strpos(normalizar($v), $alvo) !== false) { $bateu = true; break; }
        }
        if ($bateu) { $filtradas[] = $l; }
    }
    $linhas = $filtradas;
}

/* ------------------------------------------------------------- ordenar ---- */
$ordem = isset($_GET['ordem']) ? trim($_GET['ordem']) : 'nome';
$desc  = isset($_GET['desc']) && $_GET['desc'] === '1';

usort($linhas, function ($a, $b) use ($ordem, $desc) {
    $va = normalizar(valor($a, $ordem));
    $vb = normalizar(valor($b, $ordem));
    if ($va === $vb) { return 0; }
    $r = ($va < $vb) ? -1 : 1;
    return $desc ? -$r : $r;
});

/* ---------------------------------------------------------- exportar CSV -- */
/* Sai o conjunto FILTRADO inteiro, não só a página carregada na tela — quem
   exporta quer os dados, não o recorte que coube no monitor.

   Duas escolhas que existem por causa do Excel em português:
     · separador ';', senão a planilha joga tudo numa coluna só;
     · BOM no começo, senão os acentos viram caracteres estranhos.          */
if (isset($_GET['formato']) && $_GET['formato'] === 'csv') {

    /* Todas as colunas, não só as visíveis: dá para apagar coluna no Excel,
       não dá para recuperar a que não veio. */
    $colunas = array(
        'situacao'    => 'Situacao',
        'nome'        => 'Nome',
        'funcional'   => 'Funcional',
        'funcionalL'  => 'Funcional_L',
        'email'       => 'Email',
        'cargo'       => 'Cargo',
        'nivel'       => 'Nivel',
        'nivelBase'   => 'Nivel base',
        'juncao'      => 'Juncao',
        'juncaoNome'  => 'Nome da juncao',
        'posto'       => 'Posto',
        'postoNome'   => 'Nome do posto',
        'validoAte'   => 'Valido ate',
        'origem'      => 'Origem',
        'status'      => 'Status do acesso',
        'protocolo'   => 'Protocolo',
        'solicitante' => 'Solicitante',
        'solicitanteEmail' => 'Email do solicitante',
        'aprovador'   => 'Aprovador',
        'aprovadorEmail'   => 'Email do aprovador',
        'atualizadoEm'     => 'Atualizado em'
    );

    $nome = 'base-acessos-' . date('Y-m-d') . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $nome . '"');

    echo "\xEF\xBB\xBF";                       // BOM, para o Excel ler os acentos

    $saida = fopen('php://output', 'w');
    fputcsv($saida, array_values($colunas), ';');

    foreach ($linhas as $l) {
        $linha = array();
        foreach ($colunas as $chave => $rotulo) { $linha[] = valor($l, $chave); }
        fputcsv($saida, $linha, ';');
    }
    fclose($saida);
    exit;
}

/* --------------------------------------------------------------- contar ---- */
$aprovados = 0;
$pendentes = 0;
$temporarios = 0;
foreach ($linhas as $l) {
    $s = valor($l, 'situacao');
    if ($s === 'Aprovado') { $aprovados++; }
    if ($s === 'Pendente') { $pendentes++; }
    if (trim(valor($l, 'validoAte')) !== '') { $temporarios++; }
}

/* ------------------------------------------------------------- paginar ---- */
$total  = count($linhas);
$limite = isset($_GET['limite']) ? (int) $_GET['limite'] : 25;
$de     = isset($_GET['de'])     ? (int) $_GET['de']     : 0;

if ($limite < 1)   { $limite = 25; }
if ($limite > 500) { $limite = 500; }
if ($de < 0)       { $de = 0; }

responder(array(
    'ok'          => true,
    'origem'      => $origem,
    'total'       => $total,
    'de'          => $de,
    'limite'      => $limite,
    'aprovados'   => $aprovados,
    'pendentes'   => $pendentes,
    'temporarios' => $temporarios,
    'linhas'      => array_slice($linhas, $de, $limite)
), 200);
