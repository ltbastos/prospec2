<?php
/* ============================================================================
   Portal de Acessos - recebe a solicitacao.

   Papel deste arquivo:
     1. conferir o formato do que chegou;
     2. RECALCULAR a regra no servidor - nunca confiar na tela:
          perfil pedido == perfil previsto  -> automatica
          qualquer outro                    -> manual
          perfil pedido ACIMA do previsto   -> manual + data de termino
     3. gerar o protocolo;
     4. gravar uma copia em data/ como trilha de auditoria local.

   Em producao quem grava no SharePoint e dispara as notificacoes e o Power App
   junto com o fluxo do Power Automate. Este PHP continua util como registro
   local para depurar o que a tela enviou.

   Compativel com PHP 5.6+ (o XAMPP da maquina pode ser antigo).
   ========================================================================== */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

define('MAX_MESES_ELEVACAO', 6);
define('MIN_JUSTIFICATIVA', 20);

function responder($dados, $status) {
    http_response_code($status);
    echo json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function lerJson($caminho, $vazio) {
    if (!is_readable($caminho)) { return $vazio; }
    $lido = json_decode(file_get_contents($caminho), true);
    return is_array($lido) ? $lido : $vazio;
}

function normalizar($s) {
    $s = function_exists('mb_strtolower')
        ? mb_strtolower(trim((string) $s), 'UTF-8')
        : strtolower(trim((string) $s));
    $com = array('á','à','ã','â','ä','é','ê','í','î','ó','ô','õ','ö','ú','û','ç');
    $sem = array('a','a','a','a','a','e','e','i','i','o','o','o','o','u','u','c');
    return str_replace($com, $sem, $s);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    responder(array('ok' => false, 'erro' => 'Use POST.'), 405);
}

$dados = json_decode(file_get_contents('php://input'), true);

if (!is_array($dados) || !isset($dados['perfil']) || !is_array($dados['perfil'])) {
    responder(array('ok' => false, 'erro' => 'Corpo da requisicao invalido.'), 400);
}

$campos    = $dados['perfil'];
$email     = isset($campos['email']) ? trim($campos['email']) : '';
$pedido    = isset($dados['perfilSolicitado']) ? trim($dados['perfilSolicitado']) : '';

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    responder(array('ok' => false, 'erro' => 'E-mail ausente ou invalido.'), 400);
}
if ($pedido === '') {
    responder(array('ok' => false, 'erro' => 'Nenhum perfil foi escolhido.'), 400);
}

/* ------------------------------- o catalogo, o mesmo que a tela usa -------- */
$perfis = lerJson(__DIR__ . '/../perfis.json', array());
if (!count($perfis)) {
    responder(array('ok' => false, 'erro' => 'Nao consegui ler perfis.json.'), 500);
}

$ranks  = array();
$rls    = array();
$apoios = array();
foreach ($perfis as $p) {
    $ranks[$p['codigo']]  = (int) $p['rank'];
    /* O que a tela oferece e o que o RLS lê podem diferir: "Apoio Regional"
       é uma opcao da tela que vira GR na base. */
    $rls[$p['codigo']]    = isset($p['rls']) ? $p['rls'] : $p['codigo'];
    $apoios[$p['codigo']] = isset($p['exigePrazo']) && $p['exigePrazo'] === true;
}

if (!isset($ranks[$pedido])) {
    responder(array('ok' => false, 'erro' => 'Perfil desconhecido: ' . $pedido), 400);
}

$pedidoRls = $rls[$pedido];
$ehApoio   = $apoios[$pedido];

/* Alguns niveis trazem a juncao junto: DP e sempre a 4000, que e a juncao que
   enxerga tudo. A tela ja ajusta, mas o servidor forca de novo - senao bastaria
   um POST direto para pedir DP com outra juncao e furar a regra. */
$juncaoForcada = '';
foreach ($perfis as $p) {
    if ($p['codigo'] !== $pedido || !isset($p['juncaoFixa'])) { continue; }
    $juncaoForcada = $p['juncaoFixa'];
    $campos['juncao'] = $p['juncaoFixa'];
    $campos['juncaoNome'] = isset($p['juncaoFixaNome']) ? $p['juncaoFixaNome'] : '';
    $dados['perfil'] = $campos;
    break;
}

/* A juncao ampla (4000) enxerga tudo, entao so existe para os niveis que
   declaram suportar isso - hoje DP e DR. Com qualquer outro nivel ela seria
   acesso total pela porta dos fundos, sem ninguem perceber.

   DR nao e forcado a ela: ha diretor que ve so a propria diretoria. */
$juncaoAtual = isset($campos['juncao']) ? trim($campos['juncao']) : '';
$permitidos  = array();
foreach ($perfis as $p) {
    if (isset($p['juncaoAmpla']) && $p['juncaoAmpla'] === $juncaoAtual) {
        $permitidos[] = $p['sigla'];
        if ($p['codigo'] === $pedido) { $permitidos = array(); break; }
    }
}
if (count($permitidos)) {
    responder(array(
        'ok'   => false,
        'erro' => 'A juncao ' . $juncaoAtual . ' so existe para ' .
                  implode(' e ', $permitidos) . '. Corrija a juncao ou escolha um desses niveis.'
    ), 422);
}

/* ------------------------------------------- o perfil previsto do cargo ---- */
/* O de-para local so vale no modo mock. Em producao o perfil previsto vem do
   Power App, que leu a lista do SharePoint pelo cargo do diretorio. */
$previsto = isset($dados['perfilPrevisto']) ? trim($dados['perfilPrevisto']) : '';

if ($previsto === '') {
    $cargo = isset($campos['cargo']) ? $campos['cargo'] : '';
    foreach (lerJson(__DIR__ . '/../mock/matriz.json', array()) as $linha) {
        if (isset($linha['ativo']) && $linha['ativo'] === false) { continue; }
        if (normalizar($linha['cargo']) === normalizar($cargo)) {
            $previsto = $linha['perfil'];
            break;
        }
    }
}

/* --------------------------------------------------- a decisao, aqui ------- */
/* Solicitacao para outra pessoa nunca aprova sozinha: a pagina so conhece o
   cargo de quem esta logado, entao nao ha como conferir o cargo do
   beneficiario no diretorio. Quem confere e a governanca. */
$destino = (isset($dados['destino']) && $dados['destino'] === 'outro') ? 'outro' : 'eu';

/* Mexer num campo que a regra usa tambem derruba a aprovacao automatica. */
$camposDeRegra = array('cargo', 'juncao', 'posto');
$editouRegra = false;
$anterior = isset($dados['perfilOriginal']) && is_array($dados['perfilOriginal'])
    ? $dados['perfilOriginal'] : array();
foreach ($camposDeRegra as $c) {
    $agora = isset($campos[$c]) ? $campos[$c] : '';
    $antes = isset($anterior[$c]) ? $anterior[$c] : '';
    if ($agora !== $antes) { $editouRegra = true; break; }
}

$conhecido  = ($destino === 'eu' && $previsto !== '' && isset($ranks[$previsto]));
$elevacao   = ($conhecido && $ranks[$pedido] > $ranks[$previsto]);
$divergente = ($destino === 'outro' || $ehApoio || !$conhecido || $pedido !== $previsto || $editouRegra);

if ($destino === 'outro')                    { $direcao = 'terceiro'; }
elseif ($ehApoio)                            { $direcao = 'apoio'; }
elseif (!$conhecido)                         { $direcao = 'desconhecido'; }
elseif ($pedido === $previsto && $editouRegra) { $direcao = 'campo-editado'; }
elseif ($pedido === $previsto)               { $direcao = 'igual'; }
elseif ($elevacao)                           { $direcao = 'acima'; }
elseif ($ranks[$pedido] < $ranks[$previsto]) { $direcao = 'abaixo'; }
else                                         { $direcao = 'lateral'; }

$tipoAprovacao = $divergente ? 'manual' : 'automatica';

/* ---------------------------------------------- justificativa e prazo ------ */
$justificativa = isset($dados['justificativa']) ? trim($dados['justificativa']) : '';
$tamanho = function_exists('mb_strlen')
    ? mb_strlen($justificativa, 'UTF-8')
    : strlen($justificativa);

if ($divergente && $tamanho < MIN_JUSTIFICATIVA) {
    responder(array(
        'ok'   => false,
        'erro' => 'Este perfil exige uma justificativa de pelo menos ' .
                  MIN_JUSTIFICATIVA . ' caracteres.'
    ), 422);
}

$validoAte = isset($dados['validoAte']) ? trim($dados['validoAte']) : '';

$minimo = date('Y-m-d', mktime(0, 0, 0, (int) date('n'), (int) date('j') + 1, (int) date('Y')));
$maximo = date('Y-m-d', mktime(0, 0, 0, (int) date('n') + MAX_MESES_ELEVACAO, (int) date('j'), (int) date('Y')));

/* Perfil acima do previsto exige prazo. Para outra pessoa o prazo e opcional,
   porque o acesso pode ser permanente - mas se vier, vale o mesmo teto. */
/* Apoio e temporario por definicao: prazo obrigatorio mesmo sem elevacao. */
if (($elevacao || $ehApoio) && $validoAte === '') {
    responder(array(
        'ok'   => false,
        'erro' => $ehApoio
            ? 'Perfil de apoio exige data de termino.'
            : 'Um perfil acima do previsto exige data de termino.'
    ), 422);
}
if ($validoAte !== '' && ($validoAte < $minimo || $validoAte > $maximo)) {
    responder(array(
        'ok'   => false,
        'erro' => 'A data de termino precisa ficar entre ' . $minimo .
                  ' e ' . $maximo . ' (maximo de ' . MAX_MESES_ELEVACAO . ' meses).'
    ), 422);
}
if (!$elevacao && !$ehApoio && $destino === 'eu') { $validoAte = ''; }

/* ------------------------------------------------------------- protocolo -- */
if (function_exists('random_bytes')) {
    $sufixo = strtoupper(bin2hex(random_bytes(3)));
} else {
    $sufixo = strtoupper(substr(md5(uniqid('', true)), 0, 6));
}
$protocolo = 'AC-' . date('Ymd') . '-' . $sufixo;

/* ----------------------------------------------------------------- trilha -- */
$registro = array(
    'protocolo'      => $protocolo,
    'recebidoEm'     => date('c'),
    'ip'             => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '',
    'destino'        => $destino,
    'editouRegra'    => $editouRegra,
    'perfilPrevisto' => $previsto,
    'perfilPedido'   => $pedido,
    'perfilRls'      => $pedidoRls,
    'juncaoForcada'  => $juncaoForcada,
    'apoio'          => $ehApoio,
    'direcao'        => $direcao,
    'elevacao'       => $elevacao,
    'validoAte'      => $validoAte,
    'tipoAprovacao'  => $tipoAprovacao,
    'solicitacao'    => $dados
);

$pasta = __DIR__ . '/../data';
if (!is_dir($pasta)) { @mkdir($pasta, 0775, true); }

$flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
if (defined('JSON_PRETTY_PRINT')) { $flags = $flags | JSON_PRETTY_PRINT; }

if (@file_put_contents($pasta . '/' . $protocolo . '.json', json_encode($registro, $flags)) === false) {
    responder(array(
        'ok'   => false,
        'erro' => 'Nao consegui gravar em data/. Confira a permissao da pasta.'
    ), 500);
}

responder(array(
    'ok'            => true,
    'protocolo'     => $protocolo,
    'perfilRls'     => $pedidoRls,
    'tipoAprovacao' => $tipoAprovacao,
    'direcao'       => $direcao,
    'elevacao'      => $elevacao,
    'validoAte'     => $validoAte
), 200);
