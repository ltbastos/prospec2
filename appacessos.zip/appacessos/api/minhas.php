<?php
/* ============================================================================
   Portal de Acessos — as últimas solicitações de quem está logado.

   De onde lê, nesta ordem:
     1. data/solicitacoes.json  — o extrato da lista Solicitacoes, gerado pelo
                                  mesmo fluxo que exporta a base.
     2. data/AC-*.json          — a trilha local que api/submit.php grava no
                                  desenvolvimento.

   Filtra pela FUNCIONAL (nas duas formas) e, na falta dela, pelo e-mail —
   a mesma chave que o resto do sistema usa.

   Compativel com PHP 5.6+.
   ========================================================================== */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

require __DIR__ . '/comum.php';

$funcional = isset($_GET['funcional']) ? trim($_GET['funcional']) : '';
$email     = isset($_GET['email'])     ? trim($_GET['email'])     : '';
$limite    = isset($_GET['limite'])    ? (int) $_GET['limite']    : 5;

if ($limite < 1)  { $limite = 5; }
if ($limite > 50) { $limite = 50; }

if ($funcional === '' && $email === '') {
    responder(array('ok' => false, 'erro' => 'Informe a funcional ou o e-mail.'), 400);
}

$minhaChave = chaveDe(array('funcional' => $funcional, 'email' => $email));

/* --------------------------------------------------------------- extrato -- */
/* O extrato da lista Solicitacoes tem uma linha por solicitação, com o Status
   já decidido. É a fonte boa: sabe se foi aprovado ou reprovado. */
function lerExtrato() {
    $caminho = __DIR__ . '/../data/solicitacoes.json';
    if (!is_readable($caminho)) { return null; }
    $lido = json_decode(file_get_contents($caminho), true);
    return is_array($lido) ? $lido : null;
}

/* ------------------------------------------------------- trilha local ----- */
/* Os arquivos que api/submit.php grava. Não têm decisão registrada, então o
   que dá para dizer é: automática já valeu, manual está esperando. */
function lerTrilha() {
    $saida = array();
    $arquivos = glob(__DIR__ . '/../data/AC-*.json');
    if (!is_array($arquivos)) { return $saida; }

    foreach ($arquivos as $arq) {
        $r = json_decode(file_get_contents($arq), true);
        if (!is_array($r)) { continue; }

        $sol = isset($r['solicitacao']) ? $r['solicitacao'] : array();
        $pes = isset($sol['perfil']) && is_array($sol['perfil']) ? $sol['perfil'] : array();

        /* Quem PEDIU vem do bloco 'solicitante', que a tela manda junto. Sem
           ele, quem pediu para outra pessoa nunca veria o proprio pedido. */
        $qpediu = isset($sol['solicitante']) && is_array($sol['solicitante'])
            ? $sol['solicitante'] : $pes;

        $saida[] = array(
            'Protocolo'        => valor($r, 'protocolo'),
            'Created'          => valor($r, 'recebidoEm'),
            'PerfilSolicitado' => valor($r, 'perfilPedido'),
            'PerfilRls'        => valor($r, 'perfilRls'),
            'Direcao'          => valor($r, 'direcao'),
            'ValidoAte'        => valor($r, 'validoAte'),
            'Destino'          => valor($r, 'destino'),
            'Nome'             => valor($pes, 'nome'),
            'Email'            => valor($pes, 'email'),
            'Funcional'        => valor($pes, 'funcional'),
            'Funcional_L'      => valor($pes, 'funcionalL'),
            'SolicitanteEmail'     => valor($qpediu, 'email'),
            'SolicitanteFuncional' => valor($qpediu, 'funcional'),
            /* Sem decisão registrada: automática já valeu, manual espera. */
            'Status' => valor($r, 'tipoAprovacao') === 'automatica' ? 'Aprovado' : 'Novo'
        );
    }
    return $saida;
}

$extrato = lerExtrato();
$origem  = 'data/solicitacoes.json';
if ($extrato === null) { $extrato = lerTrilha(); $origem = 'data/AC-*.json'; }

/* ---------------------------------------------------------------- filtrar -- */
/* Aparecem as solicitações em que a pessoa é o SOLICITANTE — inclusive as que
   ela abriu para outra pessoa, que também são dela para acompanhar. */
$minhas = array();
foreach ($extrato as $s) {
    $doSolicitante = chaveDe(array(
        'funcional' => valor($s, 'SolicitanteFuncional'),
        'email'     => valor($s, 'SolicitanteEmail')
    ));
    $doBeneficiario = chaveDe(array(
        'funcional'  => valor($s, 'Funcional'),
        'funcionalL' => valor($s, 'Funcional_L'),
        'email'      => valor($s, 'Email')
    ));

    if ($doSolicitante !== $minhaChave && $doBeneficiario !== $minhaChave) { continue; }
    $minhas[] = $s;
}

/* Mais recente primeiro. */
usort($minhas, function ($a, $b) {
    return strcmp(valor($b, 'Created'), valor($a, 'Created'));
});

$total = count($minhas);
$minhas = array_slice($minhas, 0, $limite);

/* ------------------------------------------------------------- devolver --- */
$linhas = array();
foreach ($minhas as $s) {
    $paraOutro = valor($s, 'Destino') === 'outro'
                 && chaveDe(array('funcional' => valor($s, 'Funcional'),
                                  'email' => valor($s, 'Email'))) !== $minhaChave;

    $linhas[] = array(
        'protocolo'  => valor($s, 'Protocolo'),
        'data'       => substr(valor($s, 'Created'), 0, 10),
        'perfil'     => valor($s, 'PerfilSolicitado'),
        'validoAte'  => valor($s, 'ValidoAte'),
        'status'     => valor($s, 'Status') === 'Novo' ? 'Pendente' : valor($s, 'Status'),
        'paraOutro'  => $paraOutro,
        'paraQuem'   => $paraOutro ? valor($s, 'Nome') : '',
        'motivo'     => valor($s, 'MotivoReprova')
    );
}

responder(array(
    'ok'     => true,
    'origem' => $origem,
    'total'  => $total,
    'linhas' => $linhas
), 200);
