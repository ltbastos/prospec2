<?php
/* ============================================================================
   Portal de Acessos — segredos do servidor.

   COPIE este arquivo para  config/segredos.php  e preencha só o que usar.
   O arquivo copiado nunca deve ser versionado nem sair da máquina.

   No desenho atual NADA aqui é necessário: a página não fala com a Microsoft.
   Este arquivo existe para o dia em que algum caminho precisar de um segredo —
   e para deixar claro onde ele mora, que é aqui e não em src/config.js.

   Por que aqui e não lá: src/config.js é baixado pelo navegador de todo mundo
   que abre a página. Qualquer pessoa lê o conteúdo dele digitando a URL. Esta
   pasta tem um .htaccess que o Apache respeita, e o PHP nunca devolve o código
   fonte — o valor só existe dentro do servidor.

   Compativel com PHP 5.6+.
   ========================================================================== */

return array(

    /* ------------------------------------------------------------------------
       URL do gatilho "Quando uma solicitação HTTP é recebida" do Power Automate.

       ISSO É UMA SENHA: a assinatura vai na própria URL, então quem tiver o
       endereço dispara o fluxo. Se vazar, regenere no Power Automate — a URL
       antiga para de valer na hora.

       Só é usada se algum dia o envio deixar de passar pelo Power App. Exige
       licença Premium.
       -------------------------------------------------------------------- */
    'FLOW_URL' => '',

    /* ------------------------------------------------------------------------
       Registro de aplicativo no Entra ID — só no caminho 'msal', que exige
       HTTPS na máquina.

       CLIENT_ID e TENANT_ID não são segredos: aparecem no navegador de qualquer
       jeito. Estão aqui só para ficarem no mesmo lugar.

       CLIENT_SECRET é segredo de verdade — e no fluxo do navegador (PKCE) ele
       NÃO é necessário. Se você se pegar preenchendo isto para a página
       funcionar, o desenho está errado: um segredo de aplicativo numa máquina
       de rede local é acesso ao tenant para quem alcançar a pasta.
       -------------------------------------------------------------------- */
    'ENTRA_CLIENT_ID'     => '',
    'ENTRA_TENANT_ID'     => '',
    'ENTRA_CLIENT_SECRET' => '',

    /* ------------------------------------------------------------------------
       Um segredo compartilhado, caso um dia a página precise assinar o que
       manda ao Power App. Hoje não precisa: a etapa de Retorno relê o perfil
       do usuário logado e ignora o que veio pela URL.
       -------------------------------------------------------------------- */
    'ASSINATURA' => ''
);
