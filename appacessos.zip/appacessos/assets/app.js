/* ============================================================================
   Portal de Acessos - lógica da tela.

   Quatro etapas: para quem → dados → perfil → resumo.

   A regra: cada cargo tem um nível previsto. Pedir exatamente esse perfil,
   para si mesmo e sem mexer em campo de regra, aprova sozinho. Qualquer outra
   combinação vai para o time de governança de acessos. Pedir um perfil ACIMA
   do previsto ainda exige data de término, de no máximo 6 meses.
   ========================================================================== */
(function () {
  'use strict';

  var CFG = window.PORTAL_CONFIG;

  var ETAPAS = [
    { n: 1, titulo: 'Para quem',        icone: 'i-users'  },
    { n: 2, titulo: 'Os dados',         icone: 'i-user'   },
    { n: 3, titulo: 'Nível de acesso', icone: 'i-shield' },
    { n: 4, titulo: 'Resumo',           icone: 'i-list'   }
  ];

  var estado = {
    etapa: 1,
    destino: 'eu',     // 'eu' ou 'outro'
    solicitante: {},   // quem está logado — sempre vem do Power App
    original: {},      // dados que preencheram o formulário na largada
    valores: {},       // o que está na tela agora
    bruto: {},
    perfis: [],
    matriz: [],
    perfilDaUrl: '',
    selecionado: null,
    juncaoAntes: null,  // junção real, guardada quando o nível força outra
    tocouPerfil: false
  };

  var $ = function (id) { return document.getElementById(id); };

  /* Um icone do sprite de index.html. */
  function ic(nome, tam) {
    return '<svg class="ic' + (tam ? ' ic--' + tam : '') +
           '" aria-hidden="true"><use href="#' + nome + '"/></svg>';
  }

  function mostrar(nome) {
    ['load', 'form', 'done', 'gate', 'debug', 'base'].forEach(function (v) {
      $('view-' + v).setAttribute('data-on', v === nome ? '1' : '0');
    });
    $('view-load').setAttribute('aria-busy', nome === 'load' ? 'true' : 'false');

    /* A base precisa de largura; o formulário precisa de linha curta. */
    var shell = document.querySelector('.shell');
    if (nome === 'base') { shell.classList.add('shell--largo'); }
    else { shell.classList.remove('shell--largo'); }
  }

  function texto(s) {
    var d = document.createElement('div');
    d.textContent = s == null ? '' : String(s);
    return d.innerHTML;
  }

  function normalizar(s) {
    return String(s || '')
      .normalize('NFD').replace(new RegExp('[\\u0300-\\u036f]', 'g'), '')
      .toLowerCase().trim();
  }

  function primeiroNome(nome) {
    return String(nome || '').trim().split(/\s+/)[0] || '';
  }

  /* Iniciais para o avatar do cabeçalho: primeiro e último nome. */
  function iniciais(nome) {
    var p = String(nome || '').trim().split(/\s+/).filter(Boolean);
    if (!p.length) return '?';
    var a = p[0].charAt(0);
    var b = p.length > 1 ? p[p.length - 1].charAt(0) : '';
    return (a + b).toUpperCase();
  }

  function emailValido(v) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v || '').trim());
  }

  function soDigitos(v) {
    return String(v || '').replace(/\D+/g, '');
  }

  /* O diretório entrega junção e posto num campo só, misturando número e nome
     ("3311 · Junção Centro Sul", "Ag. 1234 · Paulista"). O RLS compara pelo
     NÚMERO, então aqui a gente separa: dígitos de um lado, o resto do outro. */
  function separarCodigo(v) {
    var s = String(v || '').trim();
    var m = s.match(/\d+/);
    if (!m) return { numero: '', nome: s };
    return {
      numero: m[0],
      nome: s.replace(m[0], '').replace(/[·\-–—:.]/g, ' ')
              .replace(/\s+/g, ' ').trim()
    };
  }

  /* Garante que uma pessoa vinda de qualquer fonte chegue no formato da tela:
     as duas funcionais preenchidas e junção/posto já separados. */
  function normalizarPessoa(p) {
    var r = {};
    CFG.CAMPOS.forEach(function (c) { r[c.chave] = p[c.chave] || ''; });

    var f = r.funcional || r.funcionalL;
    r.funcional  = window.Funcional.paraNumero(f);
    r.funcionalL = window.Funcional.paraLetra(f);

    ['juncao', 'posto'].forEach(function (chave) {
      var nomeChave = chave + 'Nome';
      if (soDigitos(r[chave]) === r[chave] && r[chave] !== '') return;  // já é só número

      var partes = separarCodigo(r[chave]);
      r[chave] = partes.numero;
      if (!r[nomeChave]) r[nomeChave] = partes.nome;
    });

    return r;
  }

  /* ------------------------------------------------------------- datas ---- */
  function dataISO(d) {
    var m = String(d.getMonth() + 1), dia = String(d.getDate());
    if (m.length < 2) m = '0' + m;
    if (dia.length < 2) dia = '0' + dia;
    return d.getFullYear() + '-' + m + '-' + dia;
  }

  function limitesDoPrazo() {
    var h = new Date();
    return {
      min: dataISO(new Date(h.getFullYear(), h.getMonth(), h.getDate() + 1)),
      max: dataISO(new Date(h.getFullYear(),
                            h.getMonth() + CFG.MAX_MESES_ELEVACAO,
                            h.getDate()))
    };
  }

  function paraBR(iso) {
    var p = String(iso || '').split('-');
    return p.length === 3 ? p[2] + '/' + p[1] + '/' + p[0] : '';
  }

  /* ------------------------------------------------------------ perfis ---- */
  function porCodigo(cod) {
    var achado = null;
    estado.perfis.forEach(function (p) { if (p.codigo === cod) achado = p; });
    return achado;
  }

  function rank(cod) {
    var p = porCodigo(cod);
    return p ? p.rank : null;
  }

  function rotulo(cod) {
    var p = porCodigo(cod);
    return p ? p.sigla + ' · ' + p.nome : (cod || '—');
  }

  /* O que a pessoa escolhe e o que o RLS lê podem ser coisas diferentes.
     "Apoio Regional" é uma opção da tela; na base ela vira GR, que é o código
     que o filtro do RLS compara. A solicitação guarda os dois: o RLS precisa
     do código, e a auditoria precisa saber que foi apoio. */
  function codigoRls(cod) {
    var p = porCodigo(cod);
    return (p && p.rls) ? p.rls : cod;
  }

  function exigePrazo(cod) {
    var p = porCodigo(cod);
    return !!(p && p.exigePrazo);
  }

  /* Alguns níveis trazem a junção junto: DP é sempre a 4000, que é a junção
     que enxerga tudo. Escolher o nível já acerta a junção — o usuário não
     precisa saber esse número, e não faria sentido pedir DP com outra. */
  function juncaoDoNivel(cod) {
    var p = porCodigo(cod);
    return (p && p.juncaoFixa) ? p : null;
  }

  /* A junção 4000 enxerga tudo, então só existe para quem tem nível que
     comporta isso — hoje DP e DR. Com qualquer outro nível ela seria um
     acesso total entrando pela porta dos fundos, sem ninguém perceber. */
  function niveisComJuncao(numero) {
    var lista = [];
    estado.perfis.forEach(function (p) {
      if (p.juncaoAmpla && p.juncaoAmpla === numero) lista.push(p);
    });
    return lista;
  }

  function conflitoDeJuncao() {
    var permitidos = niveisComJuncao(estado.valores.juncao);
    if (!permitidos.length) return null;               // junção comum, tudo bem

    var ok = false;
    permitidos.forEach(function (p) {
      if (p.codigo === estado.selecionado) ok = true;
    });
    if (ok) return null;

    return {
      juncao: estado.valores.juncao,
      siglas: permitidos.map(function (p) { return p.sigla; })
    };
  }

  function aplicarJuncaoDoNivel() {
    var p = juncaoDoNivel(estado.selecionado);

    if (p) {
      /* Guarda a junção de verdade para devolver se a pessoa mudar de ideia. */
      if (estado.juncaoAntes === null) {
        estado.juncaoAntes = {
          juncao: estado.valores.juncao,
          nome: estado.valores.juncaoNome
        };
      }
      estado.valores.juncao = p.juncaoFixa;
      estado.valores.juncaoNome = p.juncaoFixaNome || '';
      return;
    }

    if (estado.juncaoAntes !== null) {
      estado.valores.juncao = estado.juncaoAntes.juncao;
      estado.valores.juncaoNome = estado.juncaoAntes.nome;
      estado.juncaoAntes = null;
    }
  }

  /* O nível previsto para a pessoa.

     Só existe quando a solicitação é para o próprio usuário: aí o Power App já
     mandou o perfil lido da lista do SharePoint, pelo cargo do DIRETÓRIO.
     Para outra pessoa a página não tem como conferir o cargo dela no
     diretório, então não há previsão - e a solicitação vai inteira para a
     governança. */
  function perfilPrevisto() {
    if (estado.destino === 'outro') return null;
    if (estado.perfilDaUrl) return estado.perfilDaUrl;

    var alvo = normalizar(estado.valores.cargo);
    if (!alvo) return null;

    var achado = null;
    estado.matriz.forEach(function (r) {
      if (r.ativo === false) return;
      if (normalizar(r.cargo) === alvo) achado = r.perfil;
    });
    return achado;
  }

  function camposDeRegraEditados() {
    var lista = [];
    (CFG.CAMPOS_DE_REGRA || []).forEach(function (c) {
      if ((estado.valores[c] || '') !== (estado.original[c] || '')) lista.push(c);
    });
    return lista;
  }

  function avaliar() {
    if (estado.destino === 'outro') {
      return { esperado: null, divergente: true, direcao: 'terceiro',
               elevacao: false, prazoObrigatorio: false };
    }

    var esperado = perfilPrevisto();
    var mexeu = camposDeRegraEditados();

    if (!esperado) {
      return { esperado: null, divergente: true, direcao: 'desconhecido',
               elevacao: false, prazoObrigatorio: false, mexeu: mexeu };
    }

    var sel = estado.selecionado;
    if (sel === esperado && !mexeu.length) {
      return { esperado: esperado, divergente: false, direcao: 'igual',
               elevacao: false, prazoObrigatorio: false, mexeu: mexeu };
    }
    if (sel === esperado) {
      return { esperado: esperado, divergente: true, direcao: 'campo-editado',
               elevacao: false, prazoObrigatorio: false, mexeu: mexeu };
    }

    var rs = rank(sel), re = rank(esperado);
    var direcao = rs > re ? 'acima' : (rs < re ? 'abaixo' : 'lateral');
    if (exigePrazo(sel)) direcao = 'apoio';

    return {
      esperado: esperado, divergente: true, direcao: direcao,
      elevacao: rs > re,
      /* Apoio é temporário por definição: sempre pede data, mesmo quando o
         alcance não sobe em relação ao cargo. */
      prazoObrigatorio: rs > re || exigePrazo(sel),
      mexeu: mexeu
    };
  }

  /* ------------------------------------------------------------ etapas ---- */
  function montarPassos() {
    $('passos').innerHTML = ETAPAS.map(function (e) {
      var titulo = (e.n === 2 && estado.destino === 'outro') ? 'Dados da pessoa' : e.titulo;
      var st = e.n === estado.etapa ? 'atual' : (e.n < estado.etapa ? 'feito' : 'futuro');
      return '<span class="passo" data-estado="' + st + '" title="' + texto(titulo) + '">' +
             ic(st === 'feito' ? 'i-check-circle' : e.icone, 'sm') +
             '<span>' + texto(titulo) + '</span></span>';
    }).join('');
  }

  function irPara(n) {
    estado.etapa = n;

    ETAPAS.forEach(function (e) {
      $('etapa-' + e.n).setAttribute('data-on', e.n === n ? '1' : '0');
    });

    if (n === 2) montarCampos();
    if (n === 3) montarLadder();
    if (n === 4) montarResumo();

    montarPassos();

    $('voltar').hidden = n === 1;
    $('avancar').hidden = n === 4;
    $('enviar').hidden = n !== 4;
    $('voltar-txt').textContent = n === 4 ? 'Cancelar' : 'Voltar';

    /* Contexto e histórico acompanham só a primeira etapa: durante o
       preenchimento seriam ruído, e o resumo já mostra o que está sendo
       pedido agora. */
    $('meu-acesso').setAttribute('data-on', n === 1 ? '1' : '0');
    $('minhas').setAttribute('data-on',
      (n === 1 && estado.temHistorico) ? '1' : '0');

    atualizarNota();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function atualizarNota() {
    var nota = $('acoes-nota');

    if (estado.etapa === 1) {
      nota.textContent = 'Você confere e edita tudo nas próximas etapas.';
      return;
    }
    if (estado.etapa === 2) {
      nota.textContent = estado.destino === 'outro'
        ? 'Informe os dados da pessoa que vai receber o acesso.'
        : 'Corrigir cargo, junção ou posto leva a solicitação para a governança.';
      return;
    }

    var a = avaliar();
    nota.textContent = a.divergente
      ? 'Vai para o ' + CFG.TIME_APROVADOR + '.'
      : 'O nível corresponde ao cargo. A aprovação é automática.';
  }

  /* ------------------------------------------------------------ campos ---- */
  function montarCampos() {
    var terceiro = estado.destino === 'outro';

    $('titulo-dados').textContent = terceiro
      ? 'Quem vai receber o acesso?'
      : 'Confira seus dados.';
    $('texto-dados').textContent = terceiro
      ? 'Informe os dados da pessoa. A governança confere tudo no diretório antes de liberar.'
      : 'Se algo estiver errado, corrija aqui mesmo.';

    var alvo = $('campos');
    alvo.innerHTML = '';

    /* De onde o valor veio decide o que o chip diz. Para outra pessoa o valor
       só existe depois da busca no diretório, então "preencha" é o estado
       inicial, e vira "do diretório" assim que a busca acha alguém. */
    var origemTxt = terceiro ? 'do diretório' : 'do perfil';

    CFG.CAMPOS.forEach(function (c) {
      var val = estado.valores[c.chave] || '';
      var doPerfil = (estado.original[c.chave] || '') !== '';

      var wrap = document.createElement('div');
      wrap.className = 'field' + (c.span === 2 ? ' field--wide' : '');
      wrap.setAttribute('data-origem', 'perfil');
      wrap.innerHTML =
        '<div class="field__head">' +
          '<label class="field__label" for="f-' + c.chave + '">' +
            ic(c.icone || 'i-hash', 'sm') + texto(c.rotulo) +
            (c.obrigatorio ? '' : ' <em>(opcional)</em>') +
          '</label>' +
          '<span class="chip">' +
            (doPerfil ? ic('i-check', 'sm') + origemTxt
                      : (terceiro ? 'preencha' : 'em branco')) +
          '</span>' +
        '</div>' +
        '<input class="field__input" id="f-' + c.chave + '" type="' + c.tipo + '" ' +
               'value="' + texto(val).replace(/"/g, '&quot;') + '" ' +
               'autocomplete="off" spellcheck="false">';

      alvo.appendChild(wrap);

      var input = wrap.querySelector('input');
      input.addEventListener('input', function () {
        /* Junção e Posto só aceitam número: é assim que o RLS compara. */
        if (c.soNumero && input.value !== soDigitos(input.value)) {
          var pos = input.selectionStart;
          input.value = soDigitos(input.value);
          try { input.setSelectionRange(pos - 1, pos - 1); } catch (e) {}
        }
        estado.valores[c.chave] = input.value;

        /* As duas funcionais são a mesma coisa escrita de dois jeitos:
           preencher uma preenche a outra, para ninguém digitar duas vezes
           nem deixar as duas em desacordo. */
        if (c.chave === 'funcional' || c.chave === 'funcionalL') {
          var par = c.chave === 'funcional' ? 'funcionalL' : 'funcional';
          var convertido = c.chave === 'funcional'
            ? window.Funcional.paraLetra(input.value)
            : window.Funcional.paraNumero(input.value);

          estado.valores[par] = convertido;
          var campoPar = $('f-' + par);
          if (campoPar) {
            campoPar.value = convertido;
            var wrapPar = campoPar.parentNode;
            var mudouPar = convertido !== (estado.original[par] || '');
            wrapPar.setAttribute('data-origem', mudouPar ? 'editado' : 'perfil');
          }
        }

        var mudou = input.value !== (estado.original[c.chave] || '');
        wrap.setAttribute('data-origem', mudou ? 'editado' : 'perfil');
        wrap.querySelector('.chip').innerHTML =
          mudou ? ic('i-pencil', 'sm') + (terceiro ? 'preenchido' : 'alterado por você')
                : (doPerfil ? ic('i-check', 'sm') + origemTxt
                            : (terceiro ? 'preencha' : 'em branco'));
        atualizarNota();
      });
    });
  }

  /* ---------------------------------------------------------- a escada ---- */
  function montarLadder() {
    var alvo = $('ladder');
    var esperado = perfilPrevisto();

    if (!estado.tocouPerfil) {
      estado.selecionado = esperado ||
                           estado.perfis[estado.perfis.length - 1].codigo;
    }

    alvo.innerHTML = '';

    estado.perfis.forEach(function (p, i) {
      if (esperado && p.codigo === esperado && i > 0) {
        var linha = document.createElement('div');
        linha.className = 'limite';
        linha.innerHTML = ic('i-clock', 'sm') +
                          '<span>acima daqui exige data de término</span>';
        alvo.appendChild(linha);
      }

      var eu = esperado && p.codigo === esperado;
      var passo = document.createElement('label');
      passo.className = 'step';
      passo.setAttribute('data-div', eu ? '0' : '1');
      passo.setAttribute('data-eu', eu ? '1' : '0');
      passo.setAttribute('data-on', p.codigo === estado.selecionado ? '1' : '0');
      passo.innerHTML =
        '<input type="radio" name="perfil" value="' + texto(p.codigo) + '"' +
          (p.codigo === estado.selecionado ? ' checked' : '') + '>' +
        '<span class="step__ic">' + ic(p.icone || 'i-user') + '</span>' +
        '<span class="step__code">' + texto(p.sigla) + '</span>' +
        '<span>' +
          '<span class="step__nome">' + texto(p.nome) +
            (eu ? '<span class="step__tag">' + ic('i-check', 'sm') +
                  'nível do cargo</span>' : '') +
          '</span>' +
          '<span class="step__desc">' + texto(p.descricao) + '</span>' +
        '</span>' +
        '<span class="step__reach" aria-hidden="true"><i style="--w:' +
          Number(p.alcance) + '%"></i></span>';

      passo.querySelector('input').addEventListener('change', function () {
        var eraDivergente = avaliar().divergente;
        estado.tocouPerfil = true;
        estado.selecionado = p.codigo;
        aplicarJuncaoDoNivel();
        montarLadder();

        var a = avaliar();
        if (a.divergente && !(eraDivergente && a.direcao === 'terceiro')) abrirModal(a);
      });

      alvo.appendChild(passo);
    });

    atualizarAviso();
  }

  /* ------------------------------------------------------------- popup ---- */
  var TITULOS = {
    acima:          'Este nível está acima do previsto para o cargo.',
    abaixo:         'Este nível está abaixo do previsto para o cargo.',
    lateral:        'Este nível é diferente do previsto para o cargo.',
    desconhecido:   'Não encontramos o nível previsto para este cargo.',
    'campo-editado': 'Você corrigiu um dado que a regra usa.',
    terceiro:       'Solicitação para outra pessoa.',
    apoio:          'Você está pedindo um nível de apoio.'
  };

  function abrirModal(a) {
    $('modal-titulo').textContent = TITULOS[a.direcao];

    var fim = 'a solicitação vai para o ' + CFG.TIME_APROVADOR + '.';

    if (a.direcao === 'apoio') {
      $('modal-texto').textContent =
        'Nível de apoio é sempre temporário, então ' + fim + ' Diga o motivo e ' +
        'até quando você vai apoiar — no máximo ' + CFG.MAX_MESES_ELEVACAO + ' meses.';
    } else if (a.direcao === 'acima') {
      $('modal-texto').textContent =
        'Como o nível é diferente do previsto para o cargo, ' + fim + ' Você também precisa ' +
        'dizer o motivo e até quando precisa dele — no máximo ' +
        CFG.MAX_MESES_ELEVACAO + ' meses.';
    } else if (a.direcao === 'campo-editado') {
      $('modal-texto').textContent =
        'Mudar ' + a.mexeu.join(', ') + ' altera a base da regra, então ' + fim +
        ' Conte o motivo abaixo.';
    } else if (a.direcao === 'desconhecido') {
      $('modal-texto').textContent =
        'O cargo informado não está no de-para de níveis, então não dá para aprovar ' +
        'sozinho e ' + fim;
    } else {
      $('modal-texto').textContent =
        'Como o nível é diferente do previsto para o cargo, ' + fim + ' Conte o motivo abaixo.';
    }

    var salto = $('modal-salto');
    if (a.esperado) {
      salto.style.display = '';
      salto.innerHTML =
        '<span>' + ic('i-briefcase', 'sm') + 'do cargo</span>' +
        '<b>' + texto(rotulo(a.esperado)) + '</b>' +
        '<span>' + ic('i-right', 'sm') + 'pedido</span>' +
        '<b class="alvo">' + texto(rotulo(estado.selecionado)) + '</b>';
    } else {
      salto.style.display = 'none';
    }

    $('modal-voltar').hidden = !a.esperado || a.direcao === 'campo-editado';

    $('modal').setAttribute('data-on', '1');
    $('modal-seguir').focus();
  }

  function fecharModal(voltando) {
    $('modal').setAttribute('data-on', '0');

    if (voltando) {
      var esperado = perfilPrevisto();
      if (esperado) {
        estado.selecionado = esperado;
        estado.tocouPerfil = false;
        montarLadder();
      }
      return;
    }
    $('justificativa').focus();
  }

  /* ------------------------------------------------------------ o aviso --- */
  function atualizarAviso() {
    var a = avaliar();
    var aviso = $('aviso');

    /* Quando o nível traz a junção junto, avisa — senão a pessoa chega no
       resumo e vê um número que ela não digitou. */
    if (!conflitoDeJuncao()) { $('erro-nivel').setAttribute('data-on', '0'); }

    var fixa = juncaoDoNivel(estado.selecionado);
    $('nota-nivel').setAttribute('data-on', fixa ? '1' : '0');
    if (fixa) {
      $('nota-nivel-txt').innerHTML =
        'Todo <b>' + texto(fixa.sigla) + '</b> usa a junção <b>' +
        texto(fixa.juncaoFixa) + '</b>' +
        (fixa.juncaoFixaNome ? ' · ' + texto(fixa.juncaoFixaNome) : '') +
        ', que é a que enxerga tudo. Já ajustamos para você.';
    }

    $('bloco-motivo').setAttribute('data-on', a.divergente ? '1' : '0');
    $('campo-prazo').setAttribute('data-on', a.elevacao || a.direcao === 'terceiro' ? '1' : '0');

    if (a.elevacao || a.direcao === 'terceiro') {
      var lim = limitesDoPrazo();
      var campo = $('data-fim');
      campo.setAttribute('min', lim.min);
      campo.setAttribute('max', lim.max);
      $('chip-prazo').textContent = a.prazoObrigatorio ? 'obrigatório' : 'se for temporário';
      $('ajuda-prazo').textContent = a.prazoObrigatorio
        ? 'No máximo ' + CFG.MAX_MESES_ELEVACAO + ' meses — até ' + paraBR(lim.max) +
          '. Depois dessa data o nível volta ao do cargo.'
        : 'Deixe em branco se o acesso for permanente. No máximo ' +
          CFG.MAX_MESES_ELEVACAO + ' meses — até ' + paraBR(lim.max) + '.';
    } else {
      $('data-fim').value = '';
      $('erro-prazo').setAttribute('data-on', '0');
    }

    if (!a.divergente) {
      aviso.setAttribute('data-on', '0');
      $('erro-justificativa').setAttribute('data-on', '0');
      atualizarNota();
      return;
    }

    aviso.setAttribute('data-on', '1');
    var fim = 'A solicitação vai para o <b>' + texto(CFG.TIME_APROVADOR) + '</b>.';

    if (a.direcao === 'terceiro') {
      $('aviso-texto').innerHTML =
        'Toda solicitação para outra pessoa passa por análise — a página não consegue ' +
        'conferir o cargo dela no diretório. ' + fim;
    } else if (a.direcao === 'apoio') {
      $('aviso-texto').innerHTML =
        '<b>' + texto(rotulo(estado.selecionado)) + '</b> dá o mesmo alcance de ' +
        '<b>' + texto(codigoRls(estado.selecionado)) + '</b> por um período. ' + fim;
    } else if (a.direcao === 'campo-editado') {
      $('aviso-texto').innerHTML =
        'Você alterou <b>' + texto(a.mexeu.join(', ')) + '</b>, que é a base da regra. ' + fim;
    } else if (a.esperado) {
      $('aviso-texto').innerHTML =
        'O nível previsto para <b>' + texto(estado.valores.cargo) + '</b> é ' +
        '<b>' + texto(rotulo(a.esperado)) + '</b>, e você escolheu ' +
        '<b>' + texto(rotulo(estado.selecionado)) + '</b>. ' + fim;
    } else {
      $('aviso-texto').innerHTML =
        'Não encontramos o cargo <b>' + texto(estado.valores.cargo || '(em branco)') +
        '</b> no de-para de níveis. ' + fim;
    }

    atualizarNota();
  }

  /* ---------------------------------------------------------- o resumo ---- */
  function item(rot, val, wide, marcado) {
    return '<div class="ritem' + (wide ? ' ritem--wide' : '') + '">' +
           '<span class="rrot">' + texto(rot) + '</span>' +
           '<span class="rval">' +
             (val ? (marcado ? '<b>' + texto(val) + '</b>' : texto(val))
                  : '<em>não informado</em>') +
           '</span></div>';
  }

  function bloco(titulo, icone, etapa, linhas) {
    return '<div class="rbloco">' +
             '<div class="rbloco__topo">' +
               '<span class="rbloco__nome">' + ic(icone, 'sm') + texto(titulo) + '</span>' +
               '<button type="button" class="editar" data-etapa="' + etapa + '">' +
                 ic('i-pencil', 'sm') + 'Editar</button>' +
             '</div>' +
             '<div class="rlinhas">' + linhas.join('') + '</div>' +
           '</div>';
  }

  function montarResumo() {
    var a = avaliar();

    $('texto-resumo').textContent = a.divergente
      ? 'Ao submeter, a solicitação segue para o ' + CFG.TIME_APROVADOR +
        '. Você recebe o retorno por e-mail e no Teams.'
      : 'O nível corresponde ao cargo, então a liberação é automática assim que você submeter.';

    var partes = [];

    partes.push(bloco('Para quem', estado.destino === 'eu' ? 'i-user' : 'i-users', 1, [
      item('Destinatário', estado.destino === 'eu' ? 'Para mim' : 'Para outra pessoa', true)
    ]));

    partes.push(bloco(estado.destino === 'eu' ? 'Seus dados' : 'Dados da pessoa',
      'i-list', 2,
      CFG.CAMPOS.map(function (c) {
        var mudou = (estado.valores[c.chave] || '') !== (estado.original[c.chave] || '');
        return item(c.rotulo, estado.valores[c.chave], c.span === 2, mudou);
      })
    ));

    var linhas = [item('Nível pedido', rotulo(estado.selecionado), true, a.divergente)];
    if (a.esperado) linhas.push(item('Nível do cargo', rotulo(a.esperado), true));
    if ($('data-fim').value) linhas.push(item('Válido até', paraBR($('data-fim').value), true));
    if ($('justificativa').value.trim()) {
      linhas.push(item('Motivo', $('justificativa').value.trim(), true));
    }
    partes.push(bloco('Nível de acesso', 'i-shield', 3, linhas));

    $('resumo').innerHTML = partes.join('');

    Array.prototype.forEach.call($('resumo').querySelectorAll('.editar'), function (b) {
      b.addEventListener('click', function () { irPara(Number(b.getAttribute('data-etapa'))); });
    });
  }

  /* --------------------------------------------------------- validação ---- */
  function validarEtapa(n) {
    if (n === 2) {
      var erro = $('erro-campos');
      var faltando = [];
      CFG.CAMPOS.forEach(function (c) {
        if (c.obrigatorio && !String(estado.valores[c.chave] || '').trim()) {
          faltando.push(c.rotulo);
        }
      });
      if (faltando.length) {
        $('erro-campos-txt').textContent = 'Falta preencher: ' + faltando.join(', ') + '.';
        erro.setAttribute('data-on', '1');
        return false;
      }
      if (!emailValido(estado.valores.email)) {
        $('erro-campos-txt').textContent = 'Esse e-mail não parece válido. Confira antes de continuar.';
        erro.setAttribute('data-on', '1');
        return false;
      }
      erro.setAttribute('data-on', '0');
      return true;
    }

    if (n === 3) {
      /* Junção que enxerga tudo com nível que não comporta: barra antes de
         qualquer outra checagem, porque é a que abre acesso indevido. */
      var conflito = conflitoDeJuncao();
      var erroNivel = $('erro-nivel');
      if (conflito) {
        $('erro-nivel-txt').textContent =
          'A junção ' + conflito.juncao + ' só existe para ' +
          conflito.siglas.join(' e ') + '. Corrija a junção na etapa anterior ' +
          'ou escolha um desses níveis.';
        erroNivel.setAttribute('data-on', '1');
        return false;
      }
      erroNivel.setAttribute('data-on', '0');

      var a = avaliar();
      var lim = limitesDoPrazo();
      var ate = $('data-fim').value;
      var erroPrazo = $('erro-prazo');
      var problema = '';

      if (a.prazoObrigatorio && !ate) {
        problema = 'Diga até quando o nível elevado vale.';
      } else if (ate && ate < lim.min) {
        problema = 'A data precisa ser a partir de ' + paraBR(lim.min) + '.';
      } else if (ate && ate > lim.max) {
        problema = 'O prazo máximo é ' + CFG.MAX_MESES_ELEVACAO +
                   ' meses, ou seja, até ' + paraBR(lim.max) + '.';
      }
      if (problema) {
        $('erro-prazo-txt').textContent = problema;
        erroPrazo.setAttribute('data-on', '1');
        $('data-fim').focus();
        return false;
      }
      erroPrazo.setAttribute('data-on', '0');

      var erroJ = $('erro-justificativa');
      var just = $('justificativa').value.trim();
      if (a.divergente && just.length < CFG.MIN_JUSTIFICATIVA) {
        $('erro-justificativa-txt').textContent = 'Explique o motivo em pelo menos ' + CFG.MIN_JUSTIFICATIVA +
                            ' caracteres (faltam ' + (CFG.MIN_JUSTIFICATIVA - just.length) + ').';
        erroJ.setAttribute('data-on', '1');
        $('justificativa').focus();
        return false;
      }
      erroJ.setAttribute('data-on', '0');
      return true;
    }

    return true;
  }

  /* ------------------------------------------------------------- envio ---- */
  function montarPayload() {
    var a = avaliar();
    var editados = [];
    CFG.CAMPOS.forEach(function (c) {
      if ((estado.valores[c.chave] || '') !== (estado.original[c.chave] || '')) {
        editados.push(c.chave);
      }
    });

    return {
      destino: estado.destino,
      solicitante: estado.solicitante,
      perfil: estado.valores,
      perfilOriginal: estado.original,
      camposEditados: editados,
      perfilSolicitado: estado.selecionado,
      perfilRls: codigoRls(estado.selecionado),
      perfilPrevisto: a.esperado,
      direcao: a.direcao,
      elevacao: a.elevacao,
      validoAte: $('data-fim').value || '',
      divergente: a.divergente,
      tipoAprovacao: a.divergente ? 'manual' : 'automatica',
      justificativa: $('justificativa').value.trim(),
      origem: CFG.MODO,
      enviadoEm: new Date().toISOString()
    };
  }

  function concluir(payload, protocolo) {
    var auto = payload.tipoAprovacao === 'automatica';
    var paraOutro = payload.destino === 'outro';

    $('done-selo').setAttribute('data-tipo', auto ? 'auto' : 'manual');
    $('done-selo').querySelector('use')
      .setAttribute('href', auto ? '#i-check-circle' : '#i-clock');
    $('done-mark').textContent = auto ? 'Aprovação automática' : 'Em análise';
    $('done-titulo').textContent = auto ? 'Tudo certo' : 'Recebemos sua solicitação';
    $('done-texto').textContent = auto
      ? 'O nível corresponde ao cargo, então a liberação segue direto para a base. Você recebe a confirmação por e-mail e no Teams.'
      : 'O ' + CFG.TIME_APROVADOR + ' vai analisar no Teams. ' +
        (paraOutro ? 'Você e a pessoa recebem' : 'Você recebe') + ' o retorno por e-mail e no Teams.';

    var linhas = [
      ['i-hash',      'Protocolo', protocolo || '—', true],
      [paraOutro ? 'i-users' : 'i-user', 'Para',
        paraOutro ? payload.perfil.nome + ' (outra pessoa)' : payload.perfil.nome, false],
      ['i-shield',    'Perfil', rotulo(payload.perfilSolicitado), false]
    ];
    if (payload.validoAte) {
      linhas.push(['i-calendar', 'Válido até', paraBR(payload.validoAte), false]);
    }
    linhas.push(['i-clock', 'Enviado em',
                 new Date(payload.enviadoEm).toLocaleString('pt-BR'), false]);

    $('recibo').innerHTML = linhas.map(function (l) {
      return '<div><dt>' + ic(l[0], 'sm') + texto(l[1]) + '</dt>' +
             '<dd' + (l[3] ? ' class="mono"' : '') + '>' + texto(l[2]) + '</dd></div>';
    }).join('');

    mostrar('done');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /* -------------------------------------------------------- diagnóstico --- */
  function montarDebug() {
    var linhas = CFG.CAMPOS.map(function (c) {
      var v = estado.original[c.chave];
      return '<div><dt>' + ic(c.icone || 'i-hash', 'sm') + texto(c.rotulo) +
             ' &larr; ' + texto(CFG.MAPA_PERFIL[c.chave] || '?') + '</dt>' +
             '<dd>' + (v ? texto(v) : '<b>vazio</b>') + '</dd></div>';
    });
    linhas.push('<div><dt>' + ic('i-shield', 'sm') + 'Nível previsto</dt><dd>' +
                (estado.perfilDaUrl
                   ? texto(rotulo(estado.perfilDaUrl)) + ' (veio do Power App)'
                   : '<b>não veio na URL</b>') + '</dd></div>');
    $('debug-mapa').innerHTML = linhas.join('');
    $('debug-bruto').textContent = JSON.stringify(estado.bruto, null, 2);
    mostrar('debug');
  }

  /* Volta do Power App depois de gravar no SharePoint: ?ok=1&protocolo=... */
  function concluirPeloRetorno(q) {
    concluir({
      tipoAprovacao:    q.get('tipo') === 'automatica' ? 'automatica' : 'manual',
      destino:          q.get('destino') || 'eu',
      perfil:           { nome: q.get('nome') || '' },
      perfilSolicitado: q.get('perfil') || '',
      validoAte:        q.get('ate') || '',
      enviadoEm:        new Date().toISOString()
    }, q.get('protocolo'));
  }

  /* --------------------------------------------------- trocar destino ----- */
  function aplicarDestino(valor, manterCampos) {
    estado.destino = valor;
    estado.tocouPerfil = false;
    estado.selecionado = null;

    Array.prototype.forEach.call(document.querySelectorAll('.escolha'), function (el) {
      el.setAttribute('data-on', el.querySelector('input').value === valor ? '1' : '0');
      if (el.querySelector('input').value === valor) el.querySelector('input').checked = true;
    });

    $('busca').setAttribute('data-on', valor === 'outro' ? '1' : '0');
    if (valor === 'eu') {
      $('busca-termo').value = '';
      $('busca-aviso').setAttribute('data-tipo', '');
    }

    if (manterCampos) { atualizarNota(); return; }

    /* Para outra pessoa os campos nascem vazios: os dados do diretório são de
       quem está logado, não de quem vai receber o acesso. */
    estado.original = {};
    CFG.CAMPOS.forEach(function (c) {
      estado.original[c.chave] = valor === 'eu' ? (estado.solicitante[c.chave] || '') : '';
      estado.valores[c.chave] = estado.original[c.chave];
    });

    $('justificativa').value = '';
    $('data-fim').value = '';
    atualizarNota();
  }

  /* ------------------------------------------------- buscar a pessoa ------ */
  /* Achou no diretório? Os campos passam a nascer preenchidos e viram a
     referência do que foi "alterado por você" dali em diante. */
  function aplicarPessoa(bruta) {
    var pessoa = normalizarPessoa(bruta);
    estado.original = {};
    CFG.CAMPOS.forEach(function (c) {
      estado.original[c.chave] = pessoa[c.chave] || '';
      estado.valores[c.chave] = estado.original[c.chave];
    });
    montarCampos();
    atualizarNota();
  }

  function avisoBusca(tipo, msg) {
    $('busca-aviso').setAttribute('data-tipo', tipo);
    $('busca-aviso-txt').textContent = msg;
    $('busca-aviso').querySelector('use')
      .setAttribute('href', tipo === 'ok' ? '#i-check-circle' : '#i-alert');
  }

  function buscarPessoa() {
    var termo = $('busca-termo').value.trim();
    if (!termo) {
      avisoBusca('erro', 'Digite o e-mail ou a funcional da pessoa.');
      $('busca-termo').focus();
      return;
    }

    var botao = $('busca-btn');
    botao.disabled = true;
    $('busca-btn-txt').textContent = 'Buscando…';
    avisoBusca('', '');

    window.Lookup.buscar(termo, {
      destino: 'outro',
      termo: termo
    }).then(function (r) {
      if (r.motivo === 'redirecionando') return;

      botao.disabled = false;
      $('busca-btn-txt').textContent = 'Buscar';

      if (r.ok) {
        aplicarPessoa(r.pessoa);
        avisoBusca('ok', 'Encontramos ' + (r.pessoa.nome || 'a pessoa') +
                         '. Confira os dados antes de continuar.');
        return;
      }
      if (r.motivo === 'nao-encontrado') {
        avisoBusca('erro', 'Não encontramos ninguém com "' + termo +
                           '". Confira o dado ou preencha os campos à mão.');
        return;
      }
      avisoBusca('erro', 'A busca falhou: ' + (r.detalhe || 'motivo desconhecido') + '.');
    });
  }

  /* ---------------------------------------------------------- situação ---- */
  /* Quem já está na base tem os dados vindos DELA, não do diretório: é o que
     vale hoje, e alterar aqui atualiza a mesma linha. A chave é a funcional,
     então nunca nascem duas linhas para a mesma pessoa. */
  function aplicarSituacao(s) {
    estado.situacao = (s && s.situacao) || 'Sem Acesso';
    estado.linhaDaBase = (s && s.linha) || null;
    estado.protocoloPendente = (s && s.protocolo) || '';

    montarMeuAcesso();

    /* Os campos que a base conhece passam a mandar; cargo continua do
       diretório quando a linha não trouxer um. */
    if (estado.linhaDaBase) {
      CFG.CAMPOS.forEach(function (c) {
        var daBase = estado.linhaDaBase[c.chave];

        if (daBase) estado.solicitante[c.chave] = daBase;
      });

      if (estado.linhaDaBase.nivel) {
        estado.selecionado = estado.linhaDaBase.nivel;
        estado.tocouPerfil = true;
      }
    }

    aplicarDestino('eu');
  }

  /* ------------------------------------------------- meu acesso hoje ------ */
  /* O que já vale para quem está logado. É contexto para decidir o que pedir,
     e é onde a situação mora agora — antes ela era um chip na barra, que
     repetia o que a lista de solicitações já dizia. */
  function fato(icone, rot, val, vazio) {
    return '<div class="fato">' +
             '<span class="fato__rot">' + ic(icone, 'sm') + texto(rot) + '</span>' +
             '<span class="fato__val">' +
               (val ? texto(val) : '<em>' + texto(vazio || '—') + '</em>') +
             '</span></div>';
  }

  function montarMeuAcesso() {
    var l = estado.linhaDaBase;

    $('meu-situacao').innerHTML = etiquetaSituacao(estado.situacao);

    if (!l) {
      $('meu-nota').textContent = estado.situacao === 'Pendente'
        ? 'Você ainda não está na base de acessos. Sua solicitação' +
          (estado.protocoloPendente ? ' (' + estado.protocoloPendente + ')' : '') +
          ' está com o ' + CFG.TIME_APROVADOR + '.'
        : 'Você ainda não está na base de acessos aos dashboards. Faça a ' +
          'solicitação acima para entrar.';
      $('meu-fatos').innerHTML = '';
      $('meu-acesso').setAttribute('data-on', estado.etapa === 1 ? '1' : '0');
      return;
    }

    $('meu-nota').textContent = estado.situacao === 'Pendente'
      ? 'Este é o acesso que vale agora. Você tem uma solicitação' +
        (estado.protocoloPendente ? ' (' + estado.protocoloPendente + ')' : '') +
        ' em análise, e ela ainda não mudou nada aqui.'
      : '';

    var fatos = [fato('i-shield', 'Nível atual', rotulo(l.nivel))];

    if (l.validoAte) {
      fatos.push(fato('i-calendar', 'Válido até', paraBR(l.validoAte)));
      if (l.nivelBase && l.nivelBase !== l.nivel) {
        fatos.push(fato('i-left', 'Depois volta para', rotulo(l.nivelBase)));
      }
    } else {
      fatos.push(fato('i-calendar', 'Validade', '', 'permanente'));
    }

    fatos.push(fato('i-bank', 'Junção',
      [l.juncao, l.juncaoNome].filter(Boolean).join(' · ')));
    fatos.push(fato('i-pin', 'Posto',
      [l.posto, l.postoNome].filter(Boolean).join(' · ')));

    if (l.atualizadoEm) {
      fatos.push(fato('i-clock', 'Atualizado em', paraBR(String(l.atualizadoEm).slice(0, 10))));
    }

    $('meu-fatos').innerHTML = fatos.join('');
    $('meu-acesso').setAttribute('data-on', estado.etapa === 1 ? '1' : '0');
  }

  /* --------------------------------------------- minhas solicitações ------ */
  /* Aparece só se a pessoa já pediu alguma coisa. Sem histórico não há bloco:
     um "nenhuma solicitação" ocuparia espaço sem dizer nada. */
  function carregarMinhas() {
    var url = CFG.MINHAS_URL +
              '?funcional=' + encodeURIComponent(estado.solicitante.funcional || '') +
              '&email=' + encodeURIComponent(estado.solicitante.email || '') +
              '&limite=' + (CFG.MINHAS_QUANTAS || 4);

    fetch(url, { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d.ok || !d.linhas.length) { return; }

        $('minhas-lista').innerHTML = d.linhas.map(function (p) {
          var perfil = rotulo(p.perfil);
          var extra = [];
          if (p.paraOutro) extra.push('para ' + p.paraQuem);
          if (p.validoAte) extra.push('até ' + paraBR(p.validoAte));
          if (p.status === 'Reprovado' && p.motivo) extra.push(p.motivo);

          return '<div class="pedido">' +
                   '<span class="pedido__data">' + texto(paraBR(p.data)) + '</span>' +
                   '<span class="pedido__oque"><b>' + texto(perfil) + '</b>' +
                     (extra.length
                        ? '<span class="pedido__extra">' + texto(extra.join(' · ')) + '</span>'
                        : '') +
                   '</span>' +
                   etiquetaSituacao(p.status) +
                 '</div>';
        }).join('');

        $('minhas-conta').textContent = d.total > d.linhas.length
          ? d.linhas.length + ' de ' + d.total
          : '';

        estado.temHistorico = true;
        if (estado.etapa === 1) { $('minhas').setAttribute('data-on', '1'); }
      })
      .catch(function () { /* sem histórico não é erro: o bloco só não aparece */ });
  }

  /* Copy da etapa 1, que muda conforme a pessoa já tem acesso ou não. */
  function textoDaEtapa1() {
    if (estado.situacao === 'Aprovado') {
      return 'Você já tem acesso. Pode alterar o seu nível ou pedir para outra pessoa.';
    }
    if (estado.situacao === 'Pendente') {
      return 'Você tem uma solicitação em análise' +
             (estado.protocoloPendente ? ' (' + estado.protocoloPendente + ')' : '') +
             '. Pode acompanhar ou pedir para outra pessoa.';
    }
    return 'Para quem é este acesso aos dashboards?';
  }

  /* -------------------------------------------------- base completa ------- */
  /* Só para administradores. Quem manda o sinal é o Power App, que consulta a
     lista Portal_Admins - a página apenas obedece. Filtro, ordenação e
     paginação acontecem no PHP, para a tela nunca puxar a base inteira. */
  var base = { q: '', situacao: '', ordem: 'nome', desc: false, de: 0,
               linhas: [], todasColunas: false };

  /* A tabela ganha coluna a cada campo novo. As secundárias ficam atrás de um
     botão para a leitura padrão caber sem rolagem lateral. */
  function colunasVisiveis() {
    return CFG.COLUNAS_BASE.filter(function (c) {
      return base.todasColunas || !c.secundaria;
    });
  }

  function situacaoDef(v) {
    var achada = null;
    (CFG.SITUACOES || []).forEach(function (s) {
      if (normalizar(s.v) === normalizar(v)) achada = s;
    });
    return achada || { v: v || '—', icone: 'i-x', cor: 'neutro' };
  }

  function etiquetaSituacao(v, grande) {
    var d = situacaoDef(v);
    return '<span class="sit' + (grande ? ' sit--grande' : '') +
           '" data-cor="' + d.cor + '">' + ic(d.icone, 'sm') + texto(d.v) + '</span>';
  }

  function celula(col, linha) {
    var v = linha[col.chave];

    if (col.tipo === 'perfil') {
      if (!v) return '<em class="rval"><em>—</em></em>';
      var temp = col.chave === 'perfil' && String(linha.validoAte || '').trim() !== '';
      var p = porCodigo(v);
      return '<span class="pill' + (temp ? ' pill--tempo' : '') + '" title="' +
             texto(p ? p.nome : v) + '">' + texto(p ? p.sigla : v) + '</span>';
    }
    if (col.tipo === 'situacao') { return etiquetaSituacao(v); }

    /* Uma pessoa: mostra o nome e guarda o e-mail no title. Vazio depende da
       coluna — quem aprovou pode ter sido o sistema; quem solicitou, não. */
    if (col.tipo === 'pessoa') {
      if (!v) {
        var vazio = col.vazio || '—';
        if (col.vazio && linha.situacao === 'Pendente') { vazio = 'aguardando'; }
        return '<em style="color:var(--ink-3)">' + texto(vazio) + '</em>';
      }
      return '<span title="' + texto(linha[col.chave + 'Email'] || '') + '">' +
             texto(v) + '</span>';
    }
    if (col.tipo === 'data') {
      return v ? texto(paraBR(v)) : '<em style="color:var(--ink-3)">permanente</em>';
    }
    return texto(v || '—');
  }

  function montarCabBase() {
    $('base-cab').innerHTML = '<tr>' + colunasVisiveis().map(function (c) {
      return '<th data-chave="' + c.chave + '">' + texto(c.rotulo) +
             (base.ordem === c.chave ? (base.desc ? ' ↓' : ' ↑') : '') + '</th>';
    }).join('') + '</tr>';

    Array.prototype.forEach.call($('base-cab').querySelectorAll('th'), function (th) {
      th.addEventListener('click', function () {
        var ch = th.getAttribute('data-chave');
        if (base.ordem === ch) { base.desc = !base.desc; }
        else { base.ordem = ch; base.desc = false; }
        base.de = 0;
        carregarBase(false);
      });
    });
  }

  /* A query dos filtros, compartilhada entre a listagem e a exportação: assim
     o CSV sai com exatamente o que está filtrado na tela. */
  function filtrosDaBase() {
    /* Colunas de pessoa buscam também pelo e-mail, que não tem coluna própria. */
    var buscaveis = [];
    CFG.COLUNAS_BASE.forEach(function (c) {
      if (!c.busca) return;
      buscaveis.push(c.chave);
      if (c.tipo === 'pessoa') buscaveis.push(c.chave + 'Email');
    });

    return 'q=' + encodeURIComponent(base.q) +
           '&situacao=' + encodeURIComponent(base.situacao) +
           '&campos=' + encodeURIComponent(buscaveis.join(',')) +
           '&ordem=' + encodeURIComponent(base.ordem) +
           '&desc=' + (base.desc ? '1' : '0');
  }

  function carregarBase(anexar) {
    var url = CFG.BASE_URL + '?' + filtrosDaBase() +
      '&de=' + base.de +
      '&limite=' + CFG.BASE_PAGINA;

    fetch(url, { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d.ok) {
          $('base-vazio').setAttribute('data-on', '1');
          $('base-vazio-txt').textContent = d.erro || 'Não consegui ler a base.';
          $('base-corpo').innerHTML = '';
          $('base-mais').hidden = true;
          return;
        }

        base.linhas = anexar ? base.linhas.concat(d.linhas) : d.linhas;

        $('base-corpo').innerHTML = base.linhas.map(function (l) {
          return '<tr>' + colunasVisiveis().map(function (c) {
            var longo = c.tipo === 'texto';
            return '<td' + (longo ? ' class="corta" title="' + texto(l[c.chave] || '') + '"' : '') +
                   '>' + celula(c, l) + '</td>';
          }).join('') + '</tr>';
        }).join('');

        $('base-vazio').setAttribute('data-on', base.linhas.length ? '0' : '1');
        $('base-vazio-txt').textContent = base.q || base.situacao
          ? 'Nada encontrado com esse filtro.'
          : 'A base está vazia.';

        $('base-nums').innerHTML =
          '<span><b>' + d.total + '</b> pessoas</span>' +
          '<span><b>' + d.aprovados + '</b> aprovados</span>' +
          '<span><b>' + d.pendentes + '</b> pendentes</span>' +
          '<span><b>' + d.temporarios + '</b> em nível temporário</span>';

        $('base-rodape').textContent =
          'Mostrando ' + base.linhas.length + ' de ' + d.total + ' · fonte: ' + d.origem;

        $('base-mais').hidden = base.linhas.length >= d.total;
        montarCabBase();
      })
      .catch(function (e) {
        $('base-vazio').setAttribute('data-on', '1');
        $('base-vazio-txt').textContent = 'A base não respondeu: ' + e.message;
      });
  }

  function abrirBase() {
    mostrar('base');
    base.de = 0;
    carregarBase(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function montarFiltrosBase() {
    var opcoes = [
      { v: '',           r: 'Todos'      },
      { v: 'Aprovado',   r: 'Aprovados'  },
      { v: 'Pendente',   r: 'Pendentes'  },
      { v: 'Sem Acesso', r: 'Sem acesso' }
    ];
    $('base-filtros').innerHTML = opcoes.map(function (o) {
      return '<button type="button" class="tfiltro" data-v="' + texto(o.v) + '" ' +
             'data-on="' + (base.situacao === o.v ? '1' : '0') + '">' +
             texto(o.r) + '</button>';
    }).join('');

    Array.prototype.forEach.call($('base-filtros').querySelectorAll('.tfiltro'), function (b) {
      b.addEventListener('click', function () {
        base.situacao = b.getAttribute('data-v');
        base.de = 0;
        montarFiltrosBase();
        carregarBase(false);
      });
    });
  }

  /* ------------------------------------------------------------- início --- */
  function init() {
    $('marca').textContent = CFG.MARCA;
    $('gate-link').setAttribute('href', CFG.POWERAPP_URL);

    var q = new URLSearchParams(window.location.search);

    function buscar(url, vazio) {
      return fetch(url, { cache: 'no-store' })
        .then(function (r) { return r.json(); })
        .catch(function () { return vazio; });
    }

    Promise.all([
      window.Identity.resolver(),
      buscar(CFG.PERFIS_URL, []),
      buscar(CFG.MATRIZ_URL, [])
    ]).then(function (r) {
      var id = r[0];
      estado.perfis = r[1] || [];
      estado.matriz = r[2] || [];

      if (!estado.perfis.length) {
        $('gate-nota').textContent = 'Não consegui ler perfis.json.';
        mostrar('gate');
        return;
      }

      if (q.get('ok') === '1') { concluirPeloRetorno(q); return; }

      if (!id.ok) {
        if (id.detalhe) $('gate-nota').textContent = id.detalhe;
        mostrar('gate');
        return;
      }

      estado.solicitante = normalizarPessoa(id.perfil);
      estado.bruto = id.bruto || id.perfil;
      estado.perfilDaUrl = id.perfilPrevisto || '';
      estado.adm = id.adm === true;

      $('ver-base').hidden = !estado.adm;

      if (q.get('debug') === '1') {
        CFG.CAMPOS.forEach(function (c) {
          estado.original[c.chave] = estado.solicitante[c.chave] || '';
        });
        montarDebug();
        return;
      }

      return window.Lookup.situacao(estado.solicitante, q).then(function (s) {
        aplicarSituacao(s);
      });
    }).then(function () {
      if ($('view-gate').getAttribute('data-on') === '1' ||
          $('view-debug').getAttribute('data-on') === '1') { return; }

      $('sub-etapa1').textContent = textoDaEtapa1();

      var nome = primeiroNome(estado.solicitante.nome);
      $('saudacao').textContent = nome ? 'Olá, ' + nome : 'Nova solicitação';
      $('eu-mail').textContent = estado.solicitante.email || '';
      $('eu-ini').textContent = iniciais(estado.solicitante.nome);
      $('eu').hidden = !estado.solicitante.email;

      irPara(1);
      mostrar('form');
      carregarMinhas();

      /* Voltou da tela Buscar do Power App? Retoma de onde parou. */
      var achou = window.Lookup.daVolta(q);
      if (achou) {
        var rascunho = window.Lookup.rascunho() || {};
        aplicarDestino('outro');
        $('busca-termo').value = rascunho.termo || q.get('termo') || '';
        irPara(2);

        if (achou.ok) {
          aplicarPessoa(achou.pessoa);
          avisoBusca('ok', 'Encontramos ' + (achou.pessoa.nome || 'a pessoa') +
                           '. Confira os dados antes de continuar.');
        } else {
          avisoBusca('erro', 'O diretório não encontrou ninguém com "' +
                             (achou.termo || '') + '". Preencha os campos à mão.');
        }
      }
    });

    Array.prototype.forEach.call(document.querySelectorAll('.escolha input'), function (el) {
      el.addEventListener('change', function () { aplicarDestino(el.value); });
    });

    $('busca-btn').addEventListener('click', buscarPessoa);
    $('busca-termo').addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter') { ev.preventDefault(); buscarPessoa(); }
    });

    /* ------------------------------------------------ base completa ------- */
    $('ver-base').addEventListener('click', abrirBase);
    $('base-voltar').addEventListener('click', function () { mostrar('form'); });

    /* O navegador baixa sozinho por causa do Content-Disposition do PHP. */
    $('base-csv').addEventListener('click', function () {
      window.location.href = CFG.BASE_URL + '?formato=csv&' + filtrosDaBase();
    });

    $('base-colunas').addEventListener('click', function () {
      base.todasColunas = !base.todasColunas;
      $('base-colunas').setAttribute('data-on', base.todasColunas ? '1' : '0');
      $('base-colunas').textContent = base.todasColunas
        ? 'Só as principais' : 'Todas as colunas';
      carregarBase(false);
    });
    $('base-mais').addEventListener('click', function () {
      base.de += CFG.BASE_PAGINA;
      carregarBase(true);
    });

    var tempoBusca = null;
    $('base-q').addEventListener('input', function () {
      clearTimeout(tempoBusca);
      tempoBusca = setTimeout(function () {
        base.q = $('base-q').value.trim();
        base.de = 0;
        carregarBase(false);
      }, 220);
    });
    montarFiltrosBase();

    $('avancar').addEventListener('click', function () {
      if (!validarEtapa(estado.etapa)) return;
      irPara(estado.etapa + 1);
    });

    $('voltar').addEventListener('click', function () {
      if (estado.etapa === 4) { irPara(1); return; }   // Cancelar
      irPara(estado.etapa - 1);
    });

    $('modal-seguir').addEventListener('click', function () { fecharModal(false); });
    $('modal-voltar').addEventListener('click', function () { fecharModal(true); });
    $('modal-fundo').addEventListener('click', function () { fecharModal(false); });
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape' && $('modal').getAttribute('data-on') === '1') {
        fecharModal(false);
      }
    });

    $('justificativa').addEventListener('input', function () {
      if ($('erro-justificativa').getAttribute('data-on') === '1') validarEtapa(3);
    });
    $('data-fim').addEventListener('change', function () {
      if ($('erro-prazo').getAttribute('data-on') === '1') validarEtapa(3);
    });

    $('form').addEventListener('submit', function (ev) {
      ev.preventDefault();

      var botao = $('enviar');
      botao.disabled = true;
      $('enviar-txt').textContent = 'Enviando…';

      var payload = montarPayload();
      window.Submit.enviar(payload).then(function (r) {
        if (r.redirecionando) return;
        botao.disabled = false;
        $('enviar-txt').textContent = 'Submeter solicitação';

        if (!r.ok) {
          var erro = $('erro-campos');
          $('erro-campos-txt').textContent = 'Não consegui enviar: ' + r.erro;
          erro.setAttribute('data-on', '1');
          irPara(2);
          return;
        }
        concluir(payload, r.protocolo);
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
