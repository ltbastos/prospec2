# Credenciais e conexões — Portal de Acessos (PJ, MIS e DEO)

Inventário do que precisa ser configurado, onde pegar cada coisa e o que é segredo
de verdade. **Nenhum valor real vai neste arquivo** — ele é a lista, não o cofre.

---

## Primeiro, o mais importante

**A página no XAMPP não usa credencial nenhuma.** Ela não fala com a Microsoft: não tem
token, não tem senha, não tem chave. Quem autentica é o Power App, e a identidade chega até
a página já resolvida.

Isso não é um detalhe — é o que torna aceitável hospedar a ferramenta numa máquina comum da
rede. Se um dia alguém acessar o `htdocs` inteiro, não encontra nada que dê acesso a sistema
nenhum.

⚠️ **Nunca coloque segredo em `src/config.js`.** Esse arquivo é baixado pelo navegador de
todo mundo que abre a página. Qualquer pessoa lê o conteúdo dele digitando a URL. Ele serve
só para identificadores públicos (URL do Power App, nomes de campo, rótulos).

Segredo de servidor vai em `config/segredos.php`, que o Apache não entrega e o navegador
nunca vê. Comece copiando `config/segredos.exemplo.php`.

---

## O que cada componente precisa

### 1 · Power Apps — a ponte de identidade

| O que | Onde pegar | É segredo? |
|---|---|---|
| **Environment ID** e **App ID** | Power Apps → seu app → `...` → Detalhes → URL da Web | Não |
| Conexão **Office 365 Users** | criada ao adicionar o conector no app | Não — é consentimento, não senha |
| Conexão **SharePoint** | idem | Não |

As conexões do Power Platform são autorizações OAuth que cada usuário concede na primeira
abertura do app. Não existe senha para guardar. Se aparecer uma caixa pedindo permissão na
primeira vez, é isso — o usuário confirma e não vê mais.

**Onde colar:** a URL da Web vai em `POWERAPP_URL`, em `src/config.js`. É pública: qualquer
pessoa da empresa já poderia abrir o app, e o que protege é o login da Microsoft, não a URL.

**Licença:** os dois conectores são **padrão**. Nada aqui exige Power Apps Premium.

---

### 2 · SharePoint — as listas

| O que | Onde pegar | É segredo? |
|---|---|---|
| **URL do site** | a barra de endereço do site do time | Não |
| Nomes das listas | você escolhe ao criar | Não |

Listas necessárias:

| Lista | Para quê |
|---|---|
| `Base_Acessos` | a tabela que o RLS lê |
| `Matriz_Cargo_Nivel` | o de-para cargo → nível |
| `Solicitacoes` | a trilha de auditoria |
| `Portal_Admins` | quem enxerga a base completa na tela |

**Permissões:** quem usa o portal precisa de **Contribuir** em `Solicitacoes` — é o Power App
gravando em nome da pessoa. Nas outras três, **Ler** basta; só os fluxos escrevem nelas.

> Por isso o fluxo recalcula a regra em vez de confiar no que o app gravou: com permissão de
> contribuir, alguém poderia criar um item à mão. Recalculando, isso não serve de nada.

---

### 3 · Power Automate — os fluxos

| Conexão | Usada para | É segredo? | Licença |
|---|---|---|---|
| **SharePoint** | ler e gravar nas listas | Não | Padrão |
| **Microsoft Teams** | cartão de aprovação e avisos | Não | Padrão |
| **Office 365 Outlook** | e-mails de confirmação e recusa | Não | Padrão |
| **Office 365 Users** | resolver o beneficiário no diretório | Não | Padrão |

Os fluxos rodam com a conexão de **quem os criou**, não de quem dispara. Vale escolher uma
conta que não vá embora da empresa — se ela sair, os fluxos param. Uma conta de serviço
resolve; um usuário nominal é dívida técnica.

⚠️ **Se um dia usar o gatilho HTTP** (`Quando uma solicitação HTTP é recebida`), a URL gerada
contém uma assinatura e **é uma senha**: quem tem a URL dispara o fluxo. Ela vai em
`config/segredos.php`, nunca em `src/config.js`. Esse gatilho também é conector **Premium** —
o desenho atual não precisa dele.

---

### 4 · Microsoft Teams — o canal de aprovação

| O que | Onde pegar | É segredo? |
|---|---|---|
| **Equipe** e **Canal** | selecionados na própria ação do fluxo | Não |

Nada para copiar: o fluxo lista as equipes e canais aos quais a conta dele tem acesso. Só
garanta que a conta dona do fluxo seja membro do canal da governança.

---

### 5 · Outlook — os avisos

Nenhuma credencial. O fluxo manda e-mail pela conexão Office 365 Outlook da conta dona.

⚠️ **Não configure SMTP no PHP.** Seria a única credencial de verdade na máquina do XAMPP, e
não é necessária: quem manda e-mail é o fluxo. Autenticação básica de SMTP costuma estar
desativada no Microsoft 365 de qualquer forma.

---

### 6 · Power BI — o RLS

| O que | Onde | É segredo? |
|---|---|---|
| Conexão do modelo com `Base_Acessos` | no Power BI Desktop / Service | Não |

A base é lida como qualquer outra fonte SharePoint. Confira que o filtro de RLS compara com
os mesmos códigos de `perfis.json` (`GG`, `TL`, `GC`, …) e que junção e posto chegam **só com
número**.

---

## Só se um dia mudar de caminho

Nada abaixo é usado hoje. Está aqui para quando alguém perguntar "e se…".

### Entra ID — App Registration (modo `msal`)

Só entra em cena se a máquina ganhar **HTTPS** e a página passar a autenticar sozinha,
dispensando o Power App.

| O que | É segredo? |
|---|---|
| **Client ID** (ID do aplicativo) | Não |
| **Tenant ID** | Não |
| **Redirect URI** | Não — mas precisa ser `https`, exceto `localhost` |
| **Client Secret** ou certificado | **SIM** — só necessário em fluxo de servidor, não no `msal` do navegador |

O `msal` do navegador usa PKCE e **não usa segredo**. Se alguém propuser guardar um client
secret na máquina do XAMPP, o desenho está errado: aquele arquivo é lido por todo mundo que
tiver acesso à pasta.

### Extrato de colaboradores (modo de busca `local`)

Um CSV ou JSON em `data/colaboradores.csv`. Não é credencial, mas **é dado pessoal**: nome,
e-mail e funcional de gente de verdade. A pasta `data/` já tem `.htaccess` bloqueando acesso
pela web; confira que ele foi junto na cópia.

---

## Checklist de instalação

- [ ] Criar as quatro listas no SharePoint — rode `provisionar/Criar-Listas.ps1`, que faz isso sozinho
- [ ] Publicar o Power App e copiar a **URL da Web**
- [ ] Colar a URL em `POWERAPP_URL`, em `src/config.js`
- [ ] Trocar `MODO` para `'powerapps'` e `MODO_BUSCA` para `'powerapps'`
- [ ] Ajustar `gPagina` no Power App para o endereço do XAMPP
- [ ] Criar os fluxos com uma conta de serviço, não com um usuário nominal
- [ ] Adicionar essa conta ao canal do Teams da governança
- [ ] Preencher `Portal_Admins` com quem pode ver a base completa
- [ ] Rodar `?debug=1` e conferir o mapeamento dos campos do diretório
- [ ] Só então preencher a `Matriz_Cargo_Nivel` com os cargos reais
- [ ] Copiar `config/segredos.exemplo.php` para `config/segredos.php` **só se precisar**
- [ ] Conferir que `data/.htaccess` e `config/.htaccess` vieram na cópia

## Se algo vazar

| Vazou | O que fazer |
|---|---|
| URL do Power App | nada — o login da Microsoft é que protege |
| URL de gatilho HTTP do fluxo | regenerar no Power Automate; a antiga para de valer |
| Client secret do Entra ID | revogar no portal e gerar outro |
| Conteúdo de `data/` | são dados pessoais: tratar como incidente e avisar quem cuida disso |
