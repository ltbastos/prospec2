<?php
header('Content-Type: application/json; charset=utf-8');

$host = 'localhost';
$db = 'PreAprovados';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$mysqli = new mysqli($host, $user, $pass, $db);

if ($mysqli->connect_errno) {
    http_response_code(500);
    echo json_encode(['erro' => 'Falha na conexao com o banco de dados.']);
    exit;
}

$mysqli->set_charset($charset);

function executarStatement($mysqli, $sql, $types = '', $params = [])
{
    $stmt = $mysqli->prepare($sql);
    if (!$stmt) {
        return [null, $mysqli->error];
    }

    if ($types !== '' && !empty($params)) {
        if (!$stmt->bind_param($types, ...$params)) {
            $erro = $stmt->error;
            $stmt->close();
            return [null, $erro];
        }
    }

    if (!$stmt->execute()) {
        $erro = $stmt->error;
        $stmt->close();
        return [null, $erro];
    }

    return [$stmt, null];
}

function responderErro($mensagem)
{
    http_response_code(500);
    echo json_encode(['erro' => $mensagem]);
    exit;
}

function buscarEmpresasPorCnpj($mysqli, $cnpjs)
{
    if (empty($cnpjs)) {
        return [];
    }

    $placeholders = implode(',', array_fill(0, count($cnpjs), '?'));
    $types = str_repeat('s', count($cnpjs));
    $sql = "SELECT
                cnpj,
                razao_social,
                estado,
                cidade,
                bairro,
                porte,
                cod_cnae,
                cnae
            FROM d_empresas
            WHERE cnpj IN ($placeholders)
            ORDER BY razao_social";

    list($stmt, $erro) = executarStatement($mysqli, $sql, $types, $cnpjs);
    if (!$stmt) {
        responderErro('Erro ao preparar consulta de empresas: ' . $erro);
    }

    $result = $stmt->get_result();
    $empresas = [];

    while ($row = $result->fetch_assoc()) {
        $empresas[$row['cnpj']] = [
            'cnpj' => $row['cnpj'],
            'razao_social' => $row['razao_social'],
            'estado' => $row['estado'],
            'cidade' => $row['cidade'],
            'bairro' => $row['bairro'],
            'porte' => $row['porte'],
            'cod_cnae' => $row['cod_cnae'],
            'cnae' => $row['cnae'],
            'produtos' => []
        ];
    }

    $stmt->close();
    return $empresas;
}

function buscarProdutosPorCnpj($mysqli, &$empresas, $cnpjs, $produto)
{
    if (empty($cnpjs)) {
        return;
    }

    $placeholders = implode(',', array_fill(0, count($cnpjs), '?'));
    $sql = "SELECT
                f.cnpj,
                p.nome AS produto_nome,
                f.valor_pre_aprovado
            FROM f_preAprovados f
            JOIN d_produtos p ON p.id = f.id_produto
            WHERE f.cnpj IN ($placeholders)";

    $types = str_repeat('s', count($cnpjs));
    $params = $cnpjs;

    if ($produto > 0) {
        $sql .= " AND f.id_produto = ?";
        $types .= 'i';
        $params[] = $produto;
    }

    $sql .= " ORDER BY p.ordem, p.nome";

    list($stmt, $erro) = executarStatement($mysqli, $sql, $types, $params);
    if (!$stmt) {
        responderErro('Erro ao preparar consulta de produtos: ' . $erro);
    }

    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $cnpj = $row['cnpj'];
        if (!isset($empresas[$cnpj])) {
            continue;
        }

        $empresas[$cnpj]['produtos'][] = [
            'nome' => $row['produto_nome'],
            'valor' => (float) $row['valor_pre_aprovado']
        ];
    }

    $stmt->close();
}

$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$estado = isset($_GET['estado']) ? trim($_GET['estado']) : '';
$cidade = isset($_GET['cidade']) ? trim($_GET['cidade']) : '';
$bairro = isset($_GET['bairro']) ? trim($_GET['bairro']) : '';
$cnae = isset($_GET['cnae']) ? trim($_GET['cnae']) : '';
$produto = isset($_GET['produto']) ? (int) $_GET['produto'] : 0;
$pagina = isset($_GET['pagina']) ? (int) $_GET['pagina'] : 1;
$porPagina = isset($_GET['por_pagina']) ? (int) $_GET['por_pagina'] : 10;
$incluirResumo = !isset($_GET['incluir_resumo']) || $_GET['incluir_resumo'] !== '0';
$somenteResumo = isset($_GET['somente_resumo']) && $_GET['somente_resumo'] === '1';

$pagina = $pagina > 0 ? $pagina : 1;
$porPagina = $porPagina > 0 ? $porPagina : 10;

if ($somenteResumo) {
    $incluirResumo = true;
}

$condicoesEmpresa = '';
$paramsEmpresa = [];
$typesEmpresa = '';

if ($q !== '') {
    $condicoesEmpresa .= " AND (e.cnpj LIKE ? OR e.razao_social LIKE ?)";
    $like = '%' . $q . '%';
    $paramsEmpresa[] = $like;
    $paramsEmpresa[] = $like;
    $typesEmpresa .= 'ss';
}

if ($estado !== '') {
    $condicoesEmpresa .= " AND e.estado = ?";
    $paramsEmpresa[] = $estado;
    $typesEmpresa .= 's';
}

if ($cidade !== '') {
    $condicoesEmpresa .= " AND e.cidade = ?";
    $paramsEmpresa[] = $cidade;
    $typesEmpresa .= 's';
}

if ($bairro !== '') {
    $condicoesEmpresa .= " AND e.bairro = ?";
    $paramsEmpresa[] = $bairro;
    $typesEmpresa .= 's';
}

if ($cnae !== '') {
    $condicoesEmpresa .= " AND e.cod_cnae = ?";
    $paramsEmpresa[] = $cnae;
    $typesEmpresa .= 's';
}

$condicoesProduto = '';
$paramsProduto = [];
$typesProduto = '';

if ($produto > 0) {
    $condicoesProduto .= " AND f.id_produto = ?";
    $paramsProduto[] = $produto;
    $typesProduto .= 'i';
}

$temFiltrosEmpresa = $condicoesEmpresa !== '';
$paramsCombinados = array_merge($paramsEmpresa, $paramsProduto);
$typesCombinados = $typesEmpresa . $typesProduto;

$total = null;
$totalPaginas = null;
$totaisProdutos = [];

if ($incluirResumo) {
    if ($temFiltrosEmpresa) {
        $countSql = "SELECT COUNT(DISTINCT f.cnpj) AS total
                     FROM f_preAprovados f
                     JOIN d_empresas e ON e.cnpj = f.cnpj
                     WHERE 1=1" . $condicoesEmpresa . $condicoesProduto;

        list($stmtCount, $erroCount) = executarStatement(
            $mysqli,
            $countSql,
            $typesCombinados,
            $paramsCombinados
        );

        if (!$stmtCount) {
            responderErro('Erro ao preparar consulta de contagem: ' . $erroCount);
        }

        $resultCount = $stmtCount->get_result();
        $rowCount = $resultCount->fetch_assoc();
        $total = $rowCount ? (int) $rowCount['total'] : 0;
        $stmtCount->close();

        $graficoSql = "SELECT
                          p.nome,
                          COUNT(DISTINCT f.cnpj) AS quantidade
                       FROM f_preAprovados f
                       JOIN d_empresas e ON e.cnpj = f.cnpj
                       JOIN d_produtos p ON p.id = f.id_produto
                       WHERE 1=1" . $condicoesEmpresa . $condicoesProduto . "
                         AND f.valor_pre_aprovado > 0
                       GROUP BY p.id, p.nome, p.ordem
                       ORDER BY p.ordem, p.nome";

        list($stmtGrafico, $erroGrafico) = executarStatement(
            $mysqli,
            $graficoSql,
            $typesCombinados,
            $paramsCombinados
        );

        if (!$stmtGrafico) {
            responderErro('Erro ao preparar consulta do grafico: ' . $erroGrafico);
        }
    } else {
        $countSql = "SELECT COUNT(DISTINCT f.cnpj) AS total
                     FROM f_preAprovados f
                     WHERE 1=1" . $condicoesProduto;

        list($stmtCount, $erroCount) = executarStatement(
            $mysqli,
            $countSql,
            $typesProduto,
            $paramsProduto
        );

        if (!$stmtCount) {
            responderErro('Erro ao preparar consulta de contagem: ' . $erroCount);
        }

        $resultCount = $stmtCount->get_result();
        $rowCount = $resultCount->fetch_assoc();
        $total = $rowCount ? (int) $rowCount['total'] : 0;
        $stmtCount->close();

        $graficoSql = "SELECT
                          p.nome,
                          COUNT(DISTINCT f.cnpj) AS quantidade
                       FROM f_preAprovados f
                       JOIN d_produtos p ON p.id = f.id_produto
                       WHERE 1=1" . $condicoesProduto . "
                         AND f.valor_pre_aprovado > 0
                       GROUP BY p.id, p.nome, p.ordem
                       ORDER BY p.ordem, p.nome";

        list($stmtGrafico, $erroGrafico) = executarStatement(
            $mysqli,
            $graficoSql,
            $typesProduto,
            $paramsProduto
        );

        if (!$stmtGrafico) {
            responderErro('Erro ao preparar consulta do grafico: ' . $erroGrafico);
        }
    }

    $resultGrafico = $stmtGrafico->get_result();
    while ($row = $resultGrafico->fetch_assoc()) {
        $totaisProdutos[] = [
            'nome' => $row['nome'],
            'quantidade' => (int) $row['quantidade']
        ];
    }

    $stmtGrafico->close();
    $totalPaginas = max(1, (int) ceil($total / $porPagina));
}

if ($somenteResumo) {
    $mysqli->close();

    echo json_encode([
        'empresas' => [],
        'total' => $total,
        'pagina' => $pagina,
        'por_pagina' => $porPagina,
        'total_paginas' => $totalPaginas,
        'totais_produtos' => $totaisProdutos,
        'tem_proxima_pagina' => $totalPaginas !== null ? $pagina < $totalPaginas : false,
        'resumo_incluido' => true
    ]);
    exit;
}

$offset = ($pagina - 1) * $porPagina;
$limiteLista = $incluirResumo ? $porPagina : ($porPagina + 1);

if ($temFiltrosEmpresa) {
    $listaSql = "SELECT DISTINCT f.cnpj
                 FROM f_preAprovados f
                 JOIN d_empresas e ON e.cnpj = f.cnpj
                 WHERE 1=1" . $condicoesEmpresa . $condicoesProduto . "
                 ORDER BY f.cnpj
                 LIMIT ? OFFSET ?";

    $typesLista = $typesCombinados . 'ii';
    $paramsLista = array_merge($paramsCombinados, [$limiteLista, $offset]);
} else {
    $listaSql = "SELECT DISTINCT f.cnpj
                 FROM f_preAprovados f
                 WHERE 1=1" . $condicoesProduto . "
                 ORDER BY f.cnpj
                 LIMIT ? OFFSET ?";

    $typesLista = $typesProduto . 'ii';
    $paramsLista = array_merge($paramsProduto, [$limiteLista, $offset]);
}

list($stmtLista, $erroLista) = executarStatement(
    $mysqli,
    $listaSql,
    $typesLista,
    $paramsLista
);

if (!$stmtLista) {
    responderErro('Erro ao preparar consulta de lista: ' . $erroLista);
}

$resultLista = $stmtLista->get_result();
$cnpjs = [];

while ($row = $resultLista->fetch_assoc()) {
    $cnpjs[] = $row['cnpj'];
}

$stmtLista->close();

$temProximaPagina = false;
if (!$incluirResumo && count($cnpjs) > $porPagina) {
    $temProximaPagina = true;
    array_pop($cnpjs);
}

if ($incluirResumo && $totalPaginas !== null) {
    $temProximaPagina = $pagina < $totalPaginas;
}

$empresas = buscarEmpresasPorCnpj($mysqli, $cnpjs);
buscarProdutosPorCnpj($mysqli, $empresas, array_keys($empresas), $produto);

$mysqli->close();

echo json_encode([
    'empresas' => array_values($empresas),
    'total' => $total,
    'pagina' => $pagina,
    'por_pagina' => $porPagina,
    'total_paginas' => $totalPaginas,
    'totais_produtos' => $totaisProdutos,
    'tem_proxima_pagina' => $temProximaPagina,
    'resumo_incluido' => $incluirResumo
]);
